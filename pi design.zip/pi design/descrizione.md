# LIQUIDITY MANAGEMENT MODULE - PREDICTIVE INTELLIGENCE
## Complete Design Specification

**Document Version**: 1.0  
**Last Updated**: April 2026  
**Status**: Ready for Implementation  
**Target**: Claude Code Implementation

---

## TABLE OF CONTENTS

1. [Context & Foundation](#context--foundation)
2. [Hierarchical Vehicle Structure](#hierarchical-vehicle-structure)
3. [Asset Types & Characteristics](#asset-types--characteristics)
4. [Liquidity Management Tab (New)](#liquidity-management-tab-new)
5. [Strategy Configuration](#strategy-configuration)
6. [Running Forecasts](#running-forecasts)
7. [Forecast Results Pages](#forecast-results-pages)
8. [Comparison View](#comparison-view)
9. [Hierarchical View Integration](#hierarchical-view-integration)
10. [Design Principles & Color Coding](#design-principles--color-coding)
11. [Data Model Requirements](#data-model-requirements)
12. [Implementation Notes](#implementation-notes)

---

## PART 1: CONTEXT & FOUNDATION

### 1.1 Project Overview

- **Product**: Predictive Intelligence (by Cepres)
- **Component**: Liquidity Management Module (nested within Portfolio Detail Page)
- **Design Mode**: Light mode exclusively
- **Target Users**: Portfolio managers, family offices, wealth advisors managing complex hierarchical portfolios
- **Complexity Level**: High (hierarchical vehicles, multiple asset types, constraints, probabilistic distributions)

### 1.2 Purpose

The Liquidity Management Module enables users to:
- Define hierarchical vehicle structures with parent-child relationships
- Configure cash allocation strategies per vehicle (liquidation priority + constraints)
- Set rebalancing rules and targets (annual frequency)
- Run probabilistic forecasts to understand liquidity needs across multiple scenarios
- Visualize cash flows, asset allocation evolution, and risk metrics

### 1.3 Key Principles

**Hierarchical Control**:
- **Bottom-level investments** (Primary Funds, Secondary Funds, Stocks, Bonds, ETFs, Hedge Funds, Cash) are "pass-through" entities. They generate cashflows but do NOT manage liquidity independently.
- **Vehicles** are the liquidity management units. Each vehicle holds assets and can have a strategy.
- When a bottom-level investment distributes cash → flows to parent vehicle
- When a bottom-level investment needs cash (capital call) → requests from parent vehicle, which must provide (recursive up the tree)

**Liquidity Direction**:
- **Upward** (from child to parent): Distributions, Capital Calls
- **Downward** (from parent to child): Contributions, Capital Drawdowns

---

## PART 2: HIERARCHICAL VEHICLE STRUCTURE

### 2.1 Structure Overview

Vehicles are organized in a tree/forest structure:

```
                    Master Portfolio (apex)
                            |
                  ┌─────────┼─────────┐
                  |         |         |
              Vehicle A   Vehicle B   Vehicle C
                  |         |         |
              ┌───┴──┐      |      ┌──┴───┐
              |      |      |      |      |
           Sub-A1  Sub-A2  Sub-B  Sub-C1 Sub-C2
              |      |      |      |      |
         [Investments] [Investments] [Investments]
```

### 2.2 Nodes in Hierarchy

**Top Level**: Master Portfolio (apex, no parent)
- Represents the entire portfolio being managed
- Has a strategy (how it manages its assets and sub-vehicles)

**Middle Levels**: Sub-vehicles/Funds
- Can have parent and child relationships
- Multiple levels of nesting allowed
- Each has its own strategy

**Leaf Level**: Individual Investments
- Primary Funds, Secondary Funds, Stocks, Bonds, ETFs, Hedge Funds, Cash
- Are "pass-through" entities (don't manage liquidity independently)
- Generate projected cashflows (contributions, distributions)

### 2.3 Critical Rule: Leaf Nodes Are Pass-Through

Bottom-level investments:
- Do NOT hold independent cash accounts
- Do NOT make independent allocation decisions
- Generate expected cashflows based on their projections (e.g., "Primary Fund will call 2M in Year 3")
- All cashflows flow to the parent vehicle
- The parent vehicle decides what to do with the cash (hold as cash, invest in other assets, pass to parent)

**Example Scenario**:
- Vehicle A holds a Primary Fund that expects a distribution of $1M in Q3 2025
- The $1M flows to Vehicle A's cash account
- Vehicle A's strategy determines: "Hold 20% as cash, invest 80% in bonds"
- Result: $200K stays as cash, $800K is invested in bonds (or another asset)

### 2.4 Cashflow Semantics

**Upward Flows** (from child to parent vehicle):
- **Distributions** from bottom-level investments → Parent vehicle receives cash (positive for parent, increases parent's liquidity)
- **Capital Calls** from child vehicles → Parent vehicle receives cash (positive for parent)

**Downward Flows** (from parent to child):
- **Contributions** requested by child vehicles → Parent provides cash (negative for parent, decreases parent's liquidity)
- **Capital Drawdowns** from parent to child → Child receives cash (negative for parent)

**Within a Vehicle**:
- **Net Incoming**: Distributions + Capital Calls = positive, increase vehicle value
- **Net Outgoing**: Contributions + Capital Drawdowns = negative, decrease vehicle value
- **Rebalancing**: Annual rebalancing may occur to maintain strategy targets

---

## PART 3: ASSET TYPES & CHARACTERISTICS

### 3.1 Asset Type Overview

Each vehicle can hold positions in 7 asset types with different liquidity profiles:

| Asset Type | Liquidity | Typical Constraints | Time to Liquidate | Notes |
|---|---|---|---|---|
| **Cash** | Fully liquid | None | Instant | Bank account, money market |
| **Bonds** | Highly liquid | Market hours | 1-3 days | Includes coupons at intervals, principal at maturity |
| **Stocks** | Highly liquid | Market hours | 1-3 days | Public market equities |
| **ETFs** | Highly liquid | Market hours | 1-3 days | Exchange-traded funds |
| **Hedge Funds** | Semi-liquid | Redemption frequency, notice period, max % per period, annual cap | 30-90 days | Subject to gates, lockups, constraints |
| **Secondary Funds** | Illiquid | Estimated liquidation timeline (months/years), max % per year | Months/years | Exit from secondary market |
| **Primary Funds** | Very illiquid | Generally not redeemable until fund end | 5-10+ years | Long-term commitments |

### 3.2 Asset-Specific Constraints

#### 3.2.1 Cash
- **Constraints**: None
- **Liquidation**: Instant
- **Notes**: Fully available for rebalancing or capital needs

#### 3.2.2 Bonds

**Automatic Cashflow Projection**:
- System has maturity date + coupon data for each bond
- Auto-calculates coupon payment dates and amounts (e.g., $50K coupon every 6 months)
- Auto-calculates principal return at maturity ($1M nominal)
- These are factored into vehicle's cash projection

**Liquidation**:
- Can liquidate anytime during market hours
- No constraints (unless user adds exclusion list)

#### 3.2.3 Stocks & ETFs

**Liquidation**:
- Can liquidate anytime during market hours
- No inherent constraints

#### 3.2.4 Hedge Funds

**Redemption Constraints** (ANNUAL BASIS):

User specifies for each hedge fund:

1. **Redemption Frequency**: When can you redeem?
   - Monthly
   - Quarterly
   - Semi-annual
   - Annual
   - Gated (no regular schedule, only at special gates)

2. **Notice Period**: How many days' notice required?
   - Example: 30 days, 45 days, 60 days
   - User must file redemption 30 days before the redemption window

3. **Max Redemption % per Period**: What % of position can be redeemed per window?
   - Example: 20% of position per redemption window
   - If position is $1M and max is 20%, can redeem max $200K per window

4. **Annual Redemption Cap**: Maximum amount per calendar year (VARIES BY YEAR)
   - User specifies per-year caps (e.g., 2024: 30%, 2025: 20%, 2026: 25%)
   - Cap can change year-to-year due to gates or fund changes
   - Cap is specified as % of position or absolute $$ amount

**System Calculation**:
- Based on constraints, system calculates "Max redemption available this year: $X"
- Example: "Hedge Fund A position: $1M | Annual cap 2024: 30% = max $300K redemption this year"
- As user liquidates, system tracks remaining cap

**Status Display**:
- "Next redemption window: Q2 2026"
- "Notice period expires: Jan 15, 2026 (30 days before Q2 start)"
- "Remaining annual cap: $150K (already redeemed $150K this year)"

#### 3.2.5 Secondary Funds

**Liquidation Constraints**:
1. **Estimated Liquidation Timeline**: How long to exit?
   - Example: "3 to 5 years total timeline"
   - User specifies range (e.g., "18-24 months", "3-5 years")

2. **Max % per Year**: Maximum % of position that can be exited per year
   - Example: 10% per year
   - If position is $1M, max $100K exit per year

**System Calculation**:
- At current rate, system calculates: "Fully liquidated in X years"
- Example: "$1M position at 10%/year = fully exited in 10 years"

#### 3.2.6 Primary Funds

**Default Status**: "Generally illiquid. Redemption at fund termination only."

**Override Available**:
- User can enable "Allow redemption" for co-investments or special cases
- If enabled, same constraints as Secondary Funds (timeline + max % per year)

---

## PART 4: LIQUIDITY MANAGEMENT TAB (NEW)

### 4.1 Tab Placement

Add new tab to **Portfolio Detail Page**:

```
Portfolio Detail Page Tabs:
├─ Overview
├─ Investments
├─ Liquidity Management (NEW) ← Here
└─ [Other tabs as needed]
```

### 4.2 Main Layout

The Liquidity Management tab is divided into 3 main sections:

```
┌─────────────────────────────────────────────────────────────────┐
│  LIQUIDITY MANAGEMENT                                           │
├──────────────────────┬──────────────────────┬──────────────────┤
│                      │                      │                  │
│  Section A:          │  Section B:          │  Section C:      │
│  Vehicle Hierarchy   │  Strategy Config     │  Forecast Buttons│
│  & Details Panel     │                      │                  │
│  (40% width or       │  (50% width or       │  (Bottom bar)    │
│   expandable)        │   tabbed)            │                  │
│                      │                      │                  │
│  - Tree diagram      │  - Vehicle selector  │  [Run Immediate  │
│  - Click → Details   │  - Strategy editor   │   Forecast]      │
│  - Shows KPIs,       │  - Save/reuse        │                  │
│    cashflows, risks  │                      │  [Run Simulation]│
│                      │                      │                  │
└──────────────────────┴──────────────────────┴──────────────────┘
```

### 4.3 Section A: Vehicle Hierarchy & Details Panel

#### 4.3.1 Vehicle Hierarchy Visualization

- Interactive tree diagram showing all vehicles in the portfolio
- Similar to existing "Universe View", optimized for liquidity context
- Nodes: vehicles (grey circles) with labels
- Edges: parent-child relationships
- Click any vehicle node → Details panel opens (right side or below)

#### 4.3.2 Interactive Details Panel

When user clicks a vehicle node, panel displays all liquidity info for that vehicle:

##### 4.3.2.1 Vehicle Overview
- Vehicle Name (editable)
- Level in hierarchy (e.g., "Level 2 of 4")
- Total Portfolio Value Over Time (mini line chart preview)
- Current Cash Balance (current value + historical sparkline)

##### 4.3.2.2 Current Composition
**Pie Chart**:
- Show % allocation across 7 asset types (by current market value)
- Colors: as per color palette section
- Hover: show $ values

**Table**:
- Asset Type | Current Value ($) | % of Total | P&L (if applicable)
- Sortable, allow drill-down

##### 4.3.2.3 Cashflow Waterfall Table

Show all cashflows in/out for this vehicle for selected time period (month/quarter/year):

| Type | Amount | Date | Source/Destination |
|---|---|---|---|
| Contribution | -$500K | 2025-01-15 | Sub-vehicle A1 |
| Distribution | +$250K | 2025-02-20 | Sub-vehicle A2 |
| Capital Call | +$1M | 2025-03-31 | Parent Vehicle |
| Capital Drawdown | -$300K | 2025-04-15 | Parent Vehicle |
| Rebalancing | Adjust | 2025-12-31 | Internal (stocks → cash) |

Sortable by date, type, amount.

##### 4.3.2.4 Asset-Specific Details (Expandable Sections)

**For Hedge Funds**:
- Fund name, current value
- Redemption window (e.g., "Next redemption: Q2 2026")
- Remaining annual cap (e.g., "Can redeem $500K more this year")
- Status badge: "On Lockup" | "Redemption Available" | "Notice Period Active"
- Days until notice period expires (if applicable)

**For Bonds**:
- Bond name/ISIN, current value
- Coupon payment schedule:
  - Next coupon: $X on Date Y
  - Frequency (semi-annual, annual, etc.)
- Maturity date + expected principal return
- Yield to maturity

**For Stocks/ETFs**:
- Simple list: Name, current value, change %

**For Primary/Secondary Funds**:
- Fund name, current value
- Next expected distribution date (if known)
- Liquidation timeline (if applicable)

---

### 4.4 Section B: Strategy Configuration

#### 4.4.1 Vehicle Selector

- Dropdown: "Select Vehicle to Configure Strategy"
- Autocomplete search by vehicle name
- Once selected, show current strategy + edit option

#### 4.4.2 Strategy Overview

- Current strategy name (Preset or Custom) — read-only
- Last modified date
- Button: "[Edit Strategy]" → opens strategy editor modal

---

## PART 5: STRATEGY CONFIGURATION

### 5.1 Strategy Editor (Modal or Full-Page Form)

Triggered by: Click "[Edit Strategy]" button in Section B

#### 5.1.1 Part 1: Cash Allocation Priority (Liquidation Priority List)

User defines the **order in which assets are liquidated** when the vehicle needs cash.

**UI Pattern**: Ordered list with drag-to-reorder

```
┌─────────────────────────────────────────────┐
│ Liquidation Priority (in order)             │
├─────────────────────────────────────────────┤
│ ☰ 1. Cash       [Constraints...] [Remove]   │
│ ☰ 2. Bonds      [Constraints...] [Remove]   │
│ ☰ 3. Stocks     [Constraints...] [Remove]   │
│ ☰ 4. ETFs       [Constraints...] [Remove]   │
│ ☰ 5. Hedge Funds [Constraints...] [Remove]  │
│ ☰ 6. Secondary  [Constraints...] [Remove]   │
│ ☰ 7. Primary    [Constraints...] [Remove]   │
│                 [+ Add Asset Type]          │
└─────────────────────────────────────────────┘

☐ OR: Use Proportional Liquidation
  [Help text: "Liquidate proportionally from all asset types"]
```

**User Can**:
- Drag items to reorder (determines priority)
- Remove items from list (won't be liquidated in emergencies)
- Add items back via "+ Add Asset Type"
- Click "[Constraints...]" to set per-asset constraints (see 5.1.2 below)

**Proportional Liquidation Option**:
- Checkbox: "Instead of priority order, liquidate proportionally from all asset types"
- If enabled: "Maintain current allocation ratios when liquidating"
- Example: 40% stocks, 30% bonds, 30% cash → need $1M → take $400K stocks + $300K bonds + $300K cash

#### 5.1.2 Constraint Configuration (Per Asset Type)

User clicks "[Constraints...]" next to each asset type to open constraint editor:

**For Cash**:
- Display: "Fully liquid, instant liquidation"
- No configuration needed

**For Bonds**:
- Display: "Highly liquid, market hours"
- Optional checkbox: "Exclude specific bonds from liquidation"
- If checked: list of bonds + checkboxes to select exclusions

**For Stocks**:
- Optional checkbox: "Exclude specific stocks from liquidation"
- If checked: list of stocks + checkboxes

**For ETFs**:
- Optional checkbox: "Exclude specific ETFs from liquidation"
- If checked: list of ETFs + checkboxes

**For Hedge Funds**:

```
Redemption Frequency
├─ ◉ Monthly
├─ ○ Quarterly
├─ ○ Semi-annual
├─ ○ Annual
└─ ○ Gated

Notice Period (days)
├─ Input: [30] days

Max Redemption % per Period
├─ Input: [20] %
├─ Help: "Max 20% of position per redemption window"

Annual Redemption Cap (varies by year?)
├─ ☐ Cap is same every year: [30] %
├─ ☑ Cap varies by year:
│  ├─ Year | Annual Cap (%)
│  ├─ 2024 | [30]
│  ├─ 2025 | [20]
│  ├─ 2026 | [25]
│  └─ [+ Add Year]

Status Display
├─ Based on constraints above:
└─ "Max redemption this year (2025): $X"
```

**For Secondary Funds**:

```
Estimated Liquidation Timeline
├─ From: [3] To: [5] Years
├─ Help: "How long to fully exit position"

Max Liquidation % per Year
├─ Input: [10] %
├─ Status: "At current rate, fully exited in X years"
```

**For Primary Funds**:

```
Liquidation Status
├─ Display: "Generally illiquid. Redemption at fund termination only."

Override: Allow Redemption?
├─ ☐ Allow redemption (e.g., for co-investments)
├─ If checked:
│  ├─ Timeline: [3-5] years
│  └─ Max per year: [10] %
```

---

#### 5.1.3 Part 2: Rebalancing Rules (Annual)

**Rebalancing Trigger**:

```
How to trigger rebalancing?
├─ ◉ Maintain Target Allocation (enforce exact % annually)
├─ ○ Target with Tolerance Band (rebalance if drift > ±X%)
└─ ○ Minimum Cash Reserve (always keep X% cash or cover P[percentile] scenario)
```

**Rebalancing Frequency**:

```
Frequency
├─ Dropdown: [Annually (at year-end)]
├─ Checkbox: "Apply rebalancing on specific date"
│  └─ Input: [Dec 31]
```

*Note: For now, frequency is "annual". Future versions may add quarterly, monthly, on-demand.*

**Target Allocation Specification**:

User specifies target allocation per asset type. Two methods:

**Method A: Fixed %**:

```
Asset Type    | Target % | 
──────────────┼──────────┤
Cash          | [20]     |
Bonds         | [35]     |
Stocks        | [30]     |
ETFs          | [10]     |
Hedge Funds   | [5]      |
Secondary     | [0]      |
Primary       | [0]      |
──────────────┼──────────┤
Total:        | 100%     |
```

**Method B: Scenario-Based (Advanced)**:

```
Target based on Stress Scenario?
├─ ○ No, use fixed %
└─ ◉ Yes, base on stress scenario:
   ├─ Select scenario percentile: [P5 / P10 / P50 / P90 / P95]
   └─ Help: "Maintain [%] cash to sustain [scenario] outcome"
```

**Tolerance Band** (if "Target with Tolerance" selected):

```
Rebalance if any asset drifts by more than
├─ Input: [±5] %
├─ Example: Target cash is 20%, rebalance if <15% or >25%
```

---

#### 5.1.4 Part 3: Save Strategy

```
Save This Strategy
├─ Input: Strategy Name [e.g., "Conservative with Hedge Fund Limits"]
├─ ☑ Make reusable across other vehicles
└─ [Save] [Cancel]
```

Once saved, strategy name appears in dropdown for other vehicles.

---

## PART 6: RUNNING FORECASTS

### 6.1 Action Buttons

At bottom of Liquidity Management tab:

```
┌─────────────────────────────────────┐
│ [Run Immediate Forecast]            │
│ [Run Simulation]                    │
└─────────────────────────────────────┘
```

### 6.2 Immediate Forecast Flow

1. User clicks "[Run Immediate Forecast]"
2. Modal dialog: "Configure Immediate Forecast"
   - Currency: Dropdown [USD] (default)
   - Stress Test: Multiselect from pre-created stress tests, or None
   - Button: "[Run Forecast]"
3. System runs forecast (calculates mean cashflows, balances, allocations)
4. Results page opens (see Part 7.1)

### 6.3 Simulation Flow

1. User clicks "[Run Simulation]"
2. Modal dialog: "Configure Simulation"
   - Simulation Name: Input (required, stored in DB)
   - Stress Test: Multiselect from pre-created stress tests, or None
   - Simulation Depth:
     - ○ Fast (1,000 iterations)
     - ◉ Full (50,000 iterations, default)
   - Currency: Dropdown [USD] (default)
   - Fine-tuning: 
     - ○ No, run simulation immediately
     - ◉ Yes, let me edit portfolio before running
   - Button: "[Run]"

3. **If No Fine-tuning**:
   - System executes simulation
   - Results page opens (see Part 7.2)

4. **If Yes Fine-tuning**:
   - Fine-tuning page opens (same as existing portfolio edit page)
   - User can edit fund data and cashflows
   - User clicks "[Validate Changes]"
   - On success, user clicks "[Run Simulation]"
   - Results page opens

---

## PART 7: FORECAST RESULTS PAGES

### 7.1 Immediate Forecast Results (Mean Only)

**Page Title**: "Liquidity Forecast - [Portfolio Name]"

**Tabbed View**:
- Tab: "All Vehicles" (aggregate view)
- Tab: "[Vehicle Name]" (per-vehicle, one tab per vehicle)

#### 7.1.1 Per-Vehicle Display (in tabs)

**Chart Section: Time Series (Mean)**

Display charts for selected vehicle over forecast period:

**Chart 1: Total Portfolio Value Over Time** (Line Chart)
- X-axis: Time periods (months/quarters/years)
- Y-axis: Portfolio value ($)
- Single line: Mean value at each period
- Tooltip: "Value: $X | Date: Y"
- Use color: Blue (#2196F3)

**Chart 2: Cash Balance Over Time** (Line Chart with zones)
- X-axis: Time periods
- Y-axis: Cash balance ($)
- Line: Actual cash at each period
- Optional shaded zone: If vehicle has "Minimum Cash Reserve", show target zone in light green
- Optional warning zone: If cash < 0, show in light red
- Tooltip: "Cash: $X | Target min: $Y | Available for investment: $Z"
- Use color: Green (#4CAF50) for cash, Red (#F44336) if negative

**Chart 3: Asset Allocation Over Time** (Stacked Area Chart)
- X-axis: Time periods
- Y-axis: Portfolio value ($) or % (toggle option)
- Stacked areas: One per asset type
  - Cash: Green (#4CAF50)
  - Bonds: Purple (#9C27B0)
  - Stocks: Blue (#2196F3)
  - ETFs: Cyan (#00BCD4)
  - Hedge Funds: Orange (#FF9800)
  - Secondary: Warm Grey (#A0A0A0)
  - Primary: Dark Grey (#757575)
- Tooltip on hover: Shows exact values and %

**Chart 4: Capital Flows Over Time** (Grouped Bar Chart)
- X-axis: Time periods
- Y-axis: Amount ($)
- Bars (grouped per period):
  - Contributions (negative, below axis): Blue
  - Distributions (positive, above axis): Green
  - Capital Calls (positive): Teal (#009688)
  - Capital Drawdowns (negative): Orange (#FF9800)
- Tooltip: Show breakdown per category

**Chart 5: Rebalancing Events** (Timeline with markers)
- X-axis: Time periods
- Markers: Show when rebalancing occurred
- Tooltip on hover: "Rebalancing on [date] | Adjusted: [asset A] from 35% to 30%, [asset B] from 15% to 20%"

#### 7.1.2 Summary Section (Cards or KPIs)

Below charts, display key metrics:

- **Current Portfolio Value**: $X
- **Current Cash Balance**: $Y
- **End-of-Period Value**: $Z
- **Minimum Cash During Period**: $A (occurred on date B)
- **Number of Rebalancing Events**: N
- **Strategy Compliance**: "On target" | "Off target by X%"

#### 7.1.3 Detailed Table (Collapsible)

Cashflow breakdown year-by-year or period-by-period:

| Period | Start Value | Contributions | Distributions | Capital Calls | Capital Drawdowns | Rebalancing | End Value |
|---|---|---|---|---|---|---|---|
| 2024 | $10M | -$500K | +$300K | +$1M | -$200K | -$100K | $10.5M |
| 2025 | $10.5M | -$600K | +$400K | +$800K | -$300K | -$50K | $10.75M |
| ... | ... | ... | ... | ... | ... | ... | ... |

#### 7.1.4 Parent/Child Relationships (Info Section)

If vehicle has a parent:
- **Parent Vehicle**: [Name]
  - Capital Calls Made to Parent: $X (total)
  - Capital Drawdowns Received from Parent: $Y (total)

If vehicle has children:
- **Child Vehicles** (table):
  - Child Name | Contributions Received | Distributions Sent | Capital Calls Made | Capital Drawdowns Sent

---

### 7.2 Simulation Results (Distributions + Risk Metrics)

**Page Title**: "Liquidity Simulation - [Portfolio Name] - [Simulation Name]"

**Configuration Display** (collapsible header):
- Simulation name, date run, parameters (stress test, depth, iterations)
- Button: "[View Simulation Config]" → modal with all inputs

**Tabbed View** (same structure as 7.1):
- Tab: "All Vehicles"
- Tab: "[Vehicle Name]" (one per vehicle)

#### 7.2.1 Per-Vehicle Display

**Chart Section: Time Series with Distributions**

**Chart 1: Total Portfolio Value Over Time** (Line + Shaded Bands)
- X-axis: Time periods
- Y-axis: Portfolio value ($)
- **Lines/Bands**:
  - Central line: P50 (median)
  - Shaded band 1: P25–P75 (middle 50%, lighter shade)
  - Shaded band 2: P5–P95 (wider range, very light shade)
  - Outer lines: P5 (lower tail) and P95 (upper tail)
- **Toggle** (user-controlled):
  - "Show all percentiles: P5, P10, P25, P50, P75, P90, P95" (7 lines)
  - "Show P50 ± 1 std dev" (simpler view)
- Tooltip on hover: All percentile values at that time point

**Chart 2: Cash Balance Over Time** (Line + Shaded Bands)
- X-axis: Time periods
- Y-axis: Cash balance ($)
- Same structure as Chart 1
- **CRITICAL VISUALIZATION**:
  - If any percentile crosses 0 (negative cash), highlight region in Red (#F44336)
  - Label: "Insolvency risk in X% of scenarios"
- If vehicle has minimum cash target, show target line in Green (#4CAF50)
- Tooltip: "P5: $X (risk) | P50: $Y (expected) | P95: $Z (best case)"

**Chart 3: Asset Allocation Over Time** (Heatmap or Multi-Chart View)

**Option A: Heatmap**:
- X-axis: Time periods
- Y-axis: Percentiles (P5, P10, P25, P50, P75, P90, P95)
- Z-axis (color intensity): % allocation to [selected asset type]
- User can toggle which asset type to view (dropdown)
- Insight: "In P95 scenario, cash allocation peaks at 40% in Q3 2025"

**Option B: Multi-Stacked-Area** (alternative):
- Separate charts for:
  - P50 (median allocation)
  - P5–P95 range (band showing range of allocations for each asset type)
- Shows: "In best case (P95), portfolio is 70% stocks. In worst case (P5), it's 30% stocks."

**Chart 4: Rebalancing Frequency** (Bar Chart)
- X-axis: Percentile (P5, P10, P25, P50, P75, P90, P95)
- Y-axis: # of rebalancing events (count)
- Bars: Count for each percentile
- Insight: "In worst case (P5), 12 rebalancings needed. In best case (P95), only 3."
- Tooltip: "P5 scenario has high rebalancing due to frequent capital calls from child vehicles"

#### 7.2.2 Risk Metrics Section

Display as cards or table:

**Card 1: Insolvency Risk**
- **Metric**: % of simulations where cash balance goes negative
- **Status**: 
  - Green badge if 0%
  - Red badge if > 0%
- **Example**: "Cash shortfall risk: 15% of scenarios"
- **Action**: If > 0%, suggest "Increase minimum cash reserve or adjust liquidation priority"

**Card 2: Excess Cash Risk**
- **Metric**: % of simulations where cash > 50% of portfolio (suboptimal allocation)
- **Status**: Yellow badge if > 25%
- **Example**: "Excess cash: 25% of scenarios"
- **Insight**: "Portfolio is too conservative in some scenarios"

**Card 3: Rebalancing Frequency**
- **Metric**: Average # of rebalancing events per year across all scenarios
- **Format**: "Avg: 4 rebalancings/year | Range: 1–10"
- **Example breakdown**:
  - Best case (P95): 1 rebalancing/year
  - Median (P50): 4 rebalancings/year
  - Worst case (P5): 10 rebalancings/year

**Card 4: Cash Reserve Adequacy**
- **Conditional**: Only show if vehicle has "Minimum Cash Reserve" target
- **Metric**: "% of time cash > target minimum"
- **Status**: Green if > 80%
- **Example**: "Maintains minimum 20% cash: 85% of the time"
- **Failure**: If < 80%, suggest increasing minimum cash or reducing target allocation %

**Card 5: Strategy Feasibility**
- **Metric**: "Strategy is feasible: All constraints satisfied in X% of scenarios"
- **Status**:
  - Green if 100%
  - Red if < 100%
- **Example**: "Constraints violated in 5% of scenarios"
- **Action**: "Review hedge fund redemption constraints or reduce allocation to constrained assets"

#### 7.2.3 Detailed Comparison Table

| Percentile | End-of-Period Value | Min Cash Balance | Max Cash Balance | # Rebalancings | Strategy Compliance |
|---|---|---|---|---|---|
| P5 | $8.5M | -$200K | $1.2M | 12 | ❌ No |
| P10 | $9.2M | $0 | $1.5M | 10 | ✓ Yes |
| P25 | $9.8M | $400K | $2M | 6 | ✓ Yes |
| P50 | $10.5M | $800K | $2.5M | 4 | ✓ Yes |
| P75 | $11.2M | $1.1M | $2.8M | 2 | ✓ Yes |
| P90 | $12M | $1.3M | $3M | 1 | ✓ Yes |
| P95 | $12.8M | $1.5M | $3.2M | 1 | ✓ Yes |

#### 7.2.4 Scenario Explorer (Advanced)

Dropdown: "Deep-dive into specific scenario"
- P5 (Worst Case)
- P10
- P25
- P50 (Median)
- P75
- P90
- P95 (Best Case)

Once selected, show detailed trajectory for that scenario only (like 7.1, but single scenario):
- All 5 charts showing ONLY that percentile's path
- Exact dates + amounts of all cashflows
- Heatmap of when rebalancings occur
- Insight: "In this scenario, cash dips to -$200K in Q3 2025, triggering 3 emergency liquidations"

#### 7.2.5 Parent/Child Relationships

(Same as 7.1.4)

---

## PART 8: COMPARISON VIEW

### 8.1 Triggered By

From Simulations page, user:
1. Selects 2 different simulations
2. Clicks "Compare Liquidity"

### 8.2 Page Title

"Liquidity Comparison: [Simulation 1 Name] vs [Simulation 2 Name]"

### 8.3 Layout

Side-by-side view:

```
┌──────────────────────────────┬──────────────────────────────┐
│  Simulation 1 Results        │  Simulation 2 Results        │
│                              │                              │
│  [All charts from 7.2]       │  [All charts from 7.2]       │
│                              │                              │
│  Risk Metrics:               │  Risk Metrics:               │
│  - Insolvency Risk: 5%       │  - Insolvency Risk: 15%      │
│  - Rebalancing: 4/yr avg     │  - Rebalancing: 8/yr avg     │
│                              │                              │
└──────────────────────────────┴──────────────────────────────┘
```

### 8.4 Comparison Insights (Top Section)

Auto-generated badges highlighting key differences:

```
✓ Simulation 1 has 20% lower rebalancing frequency
⚠ Simulation 2 has insolvency risk in 15% of scenarios; Simulation 1 has none
ℹ Simulation 1 requires 5% more cash reserve but safer overall
```

---

## PART 9: HIERARCHICAL VIEW INTEGRATION

### 9.1 Location

"Universe View" tab in Portfolio Detail Page (existing feature)

### 9.2 Enhancements for Liquidity Context

**Vehicle Node Badges**:

Each vehicle node in the tree shows a small "liquidity badge":

```
        [Vehicle A] 💚
           /    \
      [Sub-A1]   [Sub-A2]
       💛          🔴
```

**Badge Colors & Meanings**:
- 💚 **Green**: Cash > target | Strategy on track
- 💛 **Yellow**: Cash ~ target | Within tolerance
- 🔴 **Red**: Cash < target | Off-target or insolvency risk

**Hover Tooltip**:
- Vehicle name
- Current cash: $X
- Current value: $Y
- Current allocation: Z% stocks, W% bonds, etc.

### 9.3 Click to Open Details

Click any vehicle node → Details panel opens (same as Section 4.3.2)

---

## PART 10: DESIGN PRINCIPLES & COLOR CODING

### 10.1 Color Palette (Light Mode)

- **Cash**: Green (#4CAF50) — safe, liquid, readily available
- **Bonds**: Purple (#9C27B0) — stable, predictable, moderate liquidity
- **Stocks**: Blue (#2196F3) — moderate volatility, liquid
- **ETFs**: Cyan (#00BCD4) — similar to stocks, liquid
- **Hedge Funds**: Orange (#FF9800) — constrained, redemption limits, semi-liquid
- **Secondary Funds**: Warm Grey (#A0A0A0) — illiquid, long timeline
- **Primary Funds**: Dark Grey (#757575) — very illiquid, long-term
- **Cash Shortfall**: Red (#F44336) — critical alert, insolvency risk
- **Off-Target Allocation**: Yellow (#FFC107) — warning, needs attention
- **Rebalancing Action**: Teal (#009688) — neutral, informational

### 10.2 Chart Design

- **Clear, readable fonts**: Sans-serif, sufficient contrast
- **Tooltips on hover**: Show exact values + context (percentiles, dates)
- **Export capability**: All charts can export as CSV or PNG
- **Responsive design**: Charts scale on tablet/mobile (may stack vertically)
- **Accessibility**: Color-blind safe palette, high contrast for all text

### 10.3 Accessibility

- All charts have tabular data export option
- Colorblind-safe palette (avoid red-green only distinctions; use patterns or text labels)
- High contrast for all text (WCAG AA minimum)
- Keyboard navigation for dropdowns, buttons, drag-to-reorder
- Screen reader support for charts (via tables)

### 10.4 Interaction Patterns

- **Drag-to-reorder**: Liquidation priority list (smooth drag feedback)
- **Modals**: Centered, clear close action, prevent background scroll
- **Smooth transitions**: Opening details panel, toggling chart views
- **Loading indicators**: When running forecasts
- **Inline validation**: Feedback when user inputs invalid data (e.g., percentages don't sum to 100%)
- **Undo/Redo**: Option to undo strategy changes (nice-to-have)

---

## PART 11: DATA MODEL REQUIREMENTS

### 11.1 New Entities

#### 11.1.1 Vehicle

```json
{
  "id": "uuid",
  "portfolio_id": "uuid",
  "parent_vehicle_id": "uuid | null",
  "name": "string",
  "description": "string | null",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

#### 11.1.2 AssetPosition

```json
{
  "id": "uuid",
  "vehicle_id": "uuid",
  "asset_type": "enum(cash, bonds, stocks, etfs, hedge_funds, secondary_funds, primary_funds)",
  "symbol_or_name": "string",
  "quantity": "number",
  "current_value": "decimal",
  "acquisition_date": "date",
  "cost_basis": "decimal",
  "acquisition_details": "json | null",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

**Note**: For bonds, acquisition_details includes maturity_date, coupon_rate, coupon_frequency.

#### 11.1.3 LiquidityStrategy

```json
{
  "id": "uuid",
  "vehicle_id": "uuid",
  "name": "string",
  "description": "string | null",
  "is_preset": "boolean",
  "is_reusable": "boolean",
  
  "liquidation_priority": "array<string>",
  "is_proportional": "boolean",
  
  "rebalancing_frequency": "enum(annual)",
  "rebalancing_trigger": "enum(fixed, tolerance, min_cash_reserve)",
  "rebalancing_target_allocation": "json {asset_type: percentage, ...}",
  "rebalancing_tolerance_pct": "number | null",
  "min_cash_reserve_pct": "number | null",
  "min_cash_reserve_percentile": "enum(P5, P10, P50, etc.) | null",
  
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

#### 11.1.4 AssetTypeConstraint

```json
{
  "id": "uuid",
  "strategy_id": "uuid",
  "asset_type": "enum(cash, bonds, stocks, etfs, hedge_funds, secondary_funds, primary_funds)",
  
  "redemption_frequency": "enum(monthly, quarterly, semi-annual, annual, gated) | null",
  "notice_period_days": "number | null",
  "max_redemption_pct_per_period": "number | null",
  "annual_redemption_cap_by_year": "json {2024: 30, 2025: 20, ...} | null",
  
  "estimated_liquidation_timeline_months": "number | null",
  "max_liquidation_pct_per_year": "number | null",
  
  "exclude_from_liquidation": "array<string> | null",
  
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

#### 11.1.5 SimulationResult (Extended)

```json
{
  "id": "uuid",
  "portfolio_id": "uuid",
  "simulation_name": "string",
  "vehicle_id": "uuid | null",
  "stress_test_id": "uuid | null",
  "depth": "enum(fast, full)",
  "currency": "enum(USD, EUR, etc.)",
  "iterations": "number",
  "created_at": "timestamp",
  
  "liquidity_results": [
    {
      "period": "string (2024-Q1, 2024-Q2, 2024, etc.)",
      "vehicle_id": "uuid",
      "total_portfolio_value": "decimal",
      "cash_balance": "decimal",
      "asset_allocation": "json {asset_type: percentage, ...}",
      "contributions_in": "decimal",
      "distributions_out": "decimal",
      "capital_calls_in": "decimal",
      "capital_drawdowns_out": "decimal",
      "rebalancing_occurred": "boolean",
      "rebalancing_details": "json | null",
      "percentile_metrics": "json {P5, P10, P25, P50, P75, P90, P95} | null"
    }
  ]
}
```

---

## PART 12: IMPLEMENTATION NOTES

### 12.1 Phased Approach (Recommended)

**Phase 1: Foundation**
- Build Vehicle + AssetPosition model
- Build Liquidity Management Tab UI (Sections A & B)
- Simple strategy config (priority list, no constraints)

**Phase 2: Constraints & Rebalancing**
- Add AssetTypeConstraint model
- Implement hedge fund redemption constraints
- Implement rebalancing rules (annual, fixed target)

**Phase 3: Immediate Forecast**
- Build cashflow projection engine
- Implement Immediate Forecast results page (7.1)
- Add charts for mean forecasts

**Phase 4: Simulation & Distributions**
- Extend projection engine for Monte Carlo
- Implement Simulation results page (7.2)
- Add percentile distribution charts
- Add risk metrics

**Phase 5: Polish & Comparison**
- Add comparison view (Part 8)
- Add scenario explorer (7.2.4)
- Optimize performance (lazy loading, downsampling)

### 12.2 Performance Considerations

At scale (100+ vehicles, 50+ simulations, 10-year horizons):
- **Lazy load** charts (don't render all percentiles until user clicks "Show all")
- **Server-side aggregation**: Calculate percentiles on server, don't send all 50K iterations to frontend
- **Chart downsampling**: If showing 10-year history daily, downsample to weekly or monthly
- **Caching**: Cache forecast results, invalidate on strategy change

### 12.3 User Testing Recommendations

- Test with portfolio managers managing 50+ funds
- Validate that liquidation priority UI is intuitive (drag-to-reorder vs. other patterns)
- Ensure hedge fund constraint UI matches user mental model
- Test responsiveness on tablet (many charts may be dense)

### 12.4 Future Extensions

- **Auto-rebalancing**: Not just simulation; actually execute rebalancing
- **Real-time monitoring**: Alerts when cash drops below threshold
- **Custom reporting**: Export liquidity forecasts to PDF
- **External data integration**: Fetch bond coupon schedules, stock prices from APIs
- **Scenario comparison**: Save & compare multiple named scenarios
- **Optimization**: Suggest optimal liquidation priority based on past performance

---

## END OF SPECIFICATION

**Document Status**: Ready for Claude Code Implementation  
**Next Step**: Read checklist.md for implementation tasks and phases
