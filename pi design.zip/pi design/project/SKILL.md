---
name: cepres-design
description: Use this skill to generate well-branded interfaces and assets for Cepres (global PE / investment advisory fintech) and its Predictive Intelligence SaaS, either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files. Key references:

- `README.md` — full brand + product context, content fundamentals, visual foundations, iconography
- `colors_and_type.css` — CSS variables for color, type, spacing, radii, shadows
- `fonts/roboto.css` — local @font-face for Roboto (also available via Google Fonts)
- `assets/` — logos (PNG + SVG), marks (Dawn and White variants)
- `ui_kits/predictive_intelligence/` — working React UI kit with Sidebar, Topbar, KpiRow, PerformanceChart, FundsTable, PredictionPanel, and full Portfolio / Benchmark / Fund Detail / Predictions / Login screens
- `preview/` — design-system specimen cards (colors, type, spacing, components, brand)

If creating visual artifacts (slides, mocks, throwaway prototypes, landing pages), copy assets out and create static HTML files for the user to view. Import `colors_and_type.css` for tokens and the `ui_kits/predictive_intelligence/styles.css` plus JSX components for Cepres SaaS scaffolding.

If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand — strict primary/accent ratios (70–80 / 5–15), Roboto 400/600 only, Dawn #2F3E55 as the brand color, Cepres Green #058F8A for data accents, Gold #FFD700 for CTA emphasis, subtle shadows, 8px baseline grid.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (audience, screen, tone, variations), and act as an expert designer who outputs HTML artifacts *or* production code, depending on the need.
