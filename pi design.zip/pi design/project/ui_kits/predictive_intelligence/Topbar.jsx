// Topbar.jsx
function Topbar({ route, onNav }) {
  const titles = {
    portfolio: 'Portfolio overview',
    funds: 'Fund detail · Apex Capital VII',
    benchmark: 'Benchmark comparison',
    predictions: 'Predictive Intelligence',
    deals: 'Look-through deals',
    reports: 'Reports',
    settings: 'Settings',
    help: 'Help'
  };
  return (
    <header className="pi-topbar">
      <div>
        <div className="pi-eyebrow">Apex Capital · Q2 2026</div>
        <h1 className="pi-h1">{titles[route] || 'Portfolio'}</h1>
      </div>
      <div className="pi-topbar-actions">
        <div className="pi-search">
          <Icon name="search" size={16} />
          <input placeholder="Search funds, deals, GPs…" />
          <kbd>⌘K</kbd>
        </div>
        <button className="pi-icon-btn" title="Notifications"><Icon name="bell" /></button>
        <button className="pi-btn pi-btn-primary" onClick={() => onNav('predictions')}>
          <Icon name="sparkle" size={16} /> New prediction
        </button>
      </div>
    </header>
  );
}
window.Topbar = Topbar;
