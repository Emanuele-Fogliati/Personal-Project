// Sidebar.jsx — primary navigation
function Sidebar({ active, onNav }) {
  const items = [
    { id: 'portfolio', label: 'Portfolio', icon: 'grid' },
    { id: 'funds', label: 'Funds', icon: 'layers' },
    { id: 'benchmark', label: 'Benchmarks', icon: 'bar' },
    { id: 'predictions', label: 'Predictive Intelligence', icon: 'trend' },
    { id: 'deals', label: 'Look-through deals', icon: 'search' },
    { id: 'reports', label: 'Reports', icon: 'file' },
  ];
  const bottom = [
    { id: 'settings', label: 'Settings', icon: 'cog' },
    { id: 'help', label: 'Help', icon: 'help' },
  ];
  return (
    <aside className="pi-sidebar">
      <div className="pi-brand">
        <img src="../../assets/cepres-mark-white.svg" height="26" alt="" />
        <div className="pi-brand-text">
          <div className="pi-brand-name">CEPRES</div>
          <div className="pi-brand-product">Predictive Intelligence</div>
        </div>
      </div>
      <nav className="pi-nav">
        {items.map(i => (
          <button
            key={i.id}
            className={`pi-nav-item ${active === i.id ? 'is-active' : ''}`}
            onClick={() => onNav(i.id)}
          >
            <Icon name={i.icon} /> {i.label}
          </button>
        ))}
      </nav>
      <div className="pi-nav pi-nav-bottom">
        {bottom.map(i => (
          <button key={i.id} className="pi-nav-item" onClick={() => onNav(i.id)}>
            <Icon name={i.icon} /> {i.label}
          </button>
        ))}
      </div>
      <div className="pi-user">
        <div className="pi-avatar">AM</div>
        <div>
          <div className="pi-user-name">Alessandro Mori</div>
          <div className="pi-user-org">Apex Capital · LP</div>
        </div>
      </div>
    </aside>
  );
}
window.Sidebar = Sidebar;
