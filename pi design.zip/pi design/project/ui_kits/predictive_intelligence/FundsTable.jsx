// FundsTable.jsx
function FundsTable({ onOpen }) {
  const rows = [
    { name:'Apex Capital VII', gp:'Apex Capital Partners', vintage:2019, strat:'Buyout', commit:'$120M', nav:'$186M', irr:'18.4%', tvpi:'2.14×', dpi:'0.87×', status:'top' },
    { name:'Meridian Growth IV', gp:'Meridian Partners', vintage:2021, strat:'Growth', commit:'$80M', nav:'$104M', irr:'12.9%', tvpi:'1.38×', dpi:'0.12×', status:'mid' },
    { name:'Northwind II', gp:'Northwind Capital', vintage:2017, strat:'Infra', commit:'$60M', nav:'$102M', irr:'8.2%', tvpi:'1.72×', dpi:'1.22×', status:'risk' },
    { name:'Atlas Credit Opportunities', gp:'Atlas Credit', vintage:2022, strat:'Credit', commit:'$45M', nav:'$51M', irr:'9.8%', tvpi:'1.11×', dpi:'0.04×', status:'mid' },
    { name:'Helix Venture VI', gp:'Helix Ventures', vintage:2020, strat:'Venture', commit:'$25M', nav:'$48M', irr:'22.1%', tvpi:'1.92×', dpi:'0.31×', status:'top' },
    { name:'Pinnacle Secondaries I', gp:'Pinnacle Partners', vintage:2023, strat:'Secondaries', commit:'$30M', nav:'$32M', irr:'6.4%', tvpi:'1.06×', dpi:'—', status:'new' },
  ];
  const statusLabel = { top:'Top quartile', mid:'Second quartile', risk:'At risk', new:'New' };
  return (
    <div className="pi-card pi-fundstable-wrap">
      <div className="pi-card-head">
        <div>
          <div className="pi-card-title">Holdings</div>
          <div className="pi-card-sub">6 funds · committed $360M</div>
        </div>
        <div className="pi-card-actions">
          <button className="pi-btn pi-btn-ghost"><Icon name="filter" size={14}/> Filter</button>
          <button className="pi-btn pi-btn-ghost"><Icon name="download" size={14}/> Export</button>
        </div>
      </div>
      <table className="pi-table">
        <thead>
          <tr>
            <th style={{width:'28%'}}>Fund</th>
            <th>Vintage</th>
            <th>Strategy</th>
            <th className="num">Commit</th>
            <th className="num">NAV</th>
            <th className="num">Net IRR</th>
            <th className="num">TVPI</th>
            <th className="num">DPI</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.name} onClick={() => onOpen && onOpen(r)}>
              <td>
                <div className="pi-fund-name">{r.name}</div>
                <div className="pi-fund-gp">{r.gp}</div>
              </td>
              <td className="muted">{r.vintage}</td>
              <td>{r.strat}</td>
              <td className="num">{r.commit}</td>
              <td className="num">{r.nav}</td>
              <td className="num strong">{r.irr}</td>
              <td className="num">{r.tvpi}</td>
              <td className="num">{r.dpi}</td>
              <td><span className={`pi-chip pi-chip-${r.status}`}>{statusLabel[r.status]}</span></td>
              <td><Icon name="chev_right" size={16} color="#858585"/></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
window.FundsTable = FundsTable;
