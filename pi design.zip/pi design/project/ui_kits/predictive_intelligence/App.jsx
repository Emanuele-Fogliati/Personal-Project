// App.jsx — router + screens
function Benchmark() {
  const quartiles = [
    { label:'Top quartile', fill: 85, marker: 88, val:'≥14.0%' },
    { label:'Second', fill: 70, marker: 72, val:'10–14%' },
    { label:'Third', fill: 55, marker: 55, val:'6–10%' },
    { label:'Bottom', fill: 30, marker: 30, val:'<6%' },
  ];
  return (
    <div>
      <div className="pi-kpi-row" style={{gridTemplateColumns:'repeat(3,1fr)'}}>
        <KpiCard label="Peer set" value="128 funds" sub="Buyout · 2018–2020 vintage · NA + EU" variant="warm"/>
        <KpiCard label="Apex VII Net IRR" value="18.4%" delta="4.2 pp" deltaPositive sub="vs peer median" variant="default"/>
        <KpiCard label="Rank" value="11 / 128" sub="Top decile" variant="dawn"/>
      </div>
      <div className="pi-card">
        <div className="pi-card-head">
          <div>
            <div className="pi-card-title">Net IRR distribution · buyout 2018–2020</div>
            <div className="pi-card-sub">Dotted marker = Apex VII · filled bar = peer band</div>
          </div>
          <button className="pi-btn pi-btn-ghost"><Icon name="download" size={14}/> Export</button>
        </div>
        <div className="pi-bench">
          {quartiles.map(q => (
            <div key={q.label} className="pi-bench-row">
              <div>{q.label}</div>
              <div className="pi-bench-bar">
                <div className="pi-bench-fill" style={{width: q.fill+'%'}}/>
                <div className="pi-bench-marker" style={{left: q.marker+'%'}}/>
              </div>
              <div className="pi-bench-val">{q.val}</div>
            </div>
          ))}
        </div>
      </div>
      <PredictionPanel/>
    </div>
  );
}

function Predictions() {
  return (
    <div>
      <PredictionPanel/>
      <div className="pi-two-col">
        <div className="pi-card">
          <div className="pi-card-head">
            <div>
              <div className="pi-card-title">Projected NAV · next 5 years</div>
              <div className="pi-card-sub">Cepres PI-v4 · look-through model</div>
            </div>
          </div>
          <PerformanceChart showForecast/>
        </div>
        <div className="pi-card">
          <div className="pi-card-head">
            <div>
              <div className="pi-card-title">Scenarios</div>
              <div className="pi-card-sub">Adjust assumptions to re-forecast</div>
            </div>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:14,fontSize:13}}>
            <div><div style={{color:'#858585',fontSize:11,fontWeight: 500,letterSpacing:'.1em',textTransform:'uppercase'}}>Base case</div><div style={{fontSize:22,fontWeight: 500,color:'#2F3E55',fontVariantNumeric:'tabular-nums'}}>$3.6B · 82%</div></div>
            <div><div style={{color:'#858585',fontSize:11,fontWeight: 500,letterSpacing:'.1em',textTransform:'uppercase'}}>Bull case</div><div style={{fontSize:22,fontWeight: 500,color:'#058F8A',fontVariantNumeric:'tabular-nums'}}>$4.1B · 34%</div></div>
            <div><div style={{color:'#858585',fontSize:11,fontWeight: 500,letterSpacing:'.1em',textTransform:'uppercase'}}>Bear case</div><div style={{fontSize:22,fontWeight: 500,color:'#AF2323',fontVariantNumeric:'tabular-nums'}}>$2.9B · 18%</div></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FundDetail({ onBack }) {
  return (
    <div>
      <div className="pi-kpi-row" style={{gridTemplateColumns:'repeat(4,1fr)'}}>
        <KpiCard label="Commitment" value="$120M" sub="Drawn $94M · 78%" variant="warm"/>
        <KpiCard label="Net IRR" value="18.4%" delta="2.1 pp" deltaPositive sub="top quartile" variant="default"/>
        <KpiCard label="TVPI" value="2.14×" delta="0.08×" deltaPositive sub="trailing 12 mo" variant="default"/>
        <KpiCard label="DPI" value="0.87×" sub="On track" variant="dawn"/>
      </div>
      <div className="pi-card">
        <div className="pi-card-head">
          <div>
            <div className="pi-card-title">Apex Capital VII · performance</div>
            <div className="pi-card-sub">Indexed NAV · Q1 2024 = 100</div>
          </div>
          <div className="pi-card-actions">
            <button className="pi-btn pi-btn-ghost" onClick={onBack}>← Portfolio</button>
            <button className="pi-btn pi-btn-ghost"><Icon name="download" size={14}/> Export</button>
          </div>
        </div>
        <PerformanceChart showForecast/>
        <div style={{display:'flex',gap:22,marginTop:14,fontSize:12,color:'#5C5C5C'}}>
          <span><span style={{display:'inline-block',width:14,height:3,background:'#058F8A',verticalAlign:'middle',marginRight:6}}/> Apex VII</span>
          <span><span style={{display:'inline-block',width:14,height:2,background:'#00437F',verticalAlign:'middle',marginRight:6}}/> Peer benchmark</span>
          <span style={{color:'#858585'}}>—— actual &nbsp; - - - forecast</span>
        </div>
      </div>
      <PredictionPanel/>
    </div>
  );
}

function Portfolio({ onOpen }) {
  return (
    <div>
      <KpiRow/>
      <div className="pi-two-col">
        <div className="pi-card">
          <div className="pi-card-head">
            <div>
              <div className="pi-card-title">Portfolio NAV · indexed</div>
              <div className="pi-card-sub">Actual Q1 24 → Q3 26 · forecast to Q3 27</div>
            </div>
            <div className="pi-card-actions">
              <button className="pi-btn pi-btn-ghost">1Y</button>
              <button className="pi-btn pi-btn-ghost" style={{background:'#EDEEE9',borderColor:'#5C5C5C'}}>3Y</button>
              <button className="pi-btn pi-btn-ghost">5Y</button>
            </div>
          </div>
          <PerformanceChart showForecast/>
        </div>
        <PredictionPanel/>
      </div>
      <FundsTable onOpen={onOpen}/>
    </div>
  );
}

function Login({ onLogin }) {
  return (
    <div className="pi-login">
      <div className="pi-login-left">
        <img src="../../assets/cepres-mark-white.svg" height="36" alt=""/>
        <div>
          <div style={{fontSize:11,fontWeight: 500,letterSpacing:'.14em',textTransform:'uppercase',color:'#6FBFC4'}}>Predictive Intelligence</div>
          <div className="pi-login-lead" style={{marginTop:12}}>Forecast fund performance with <span>20 years</span> of look-through PE data.</div>
        </div>
        <div className="pi-login-foot">© 2026 CEPRES · LPs, GPs and advisors in 60+ countries.</div>
      </div>
      <div className="pi-login-right">
        <form className="pi-login-form" onSubmit={(e)=>{e.preventDefault();onLogin();}}>
          <div style={{fontSize:11,fontWeight: 500,letterSpacing:'.14em',textTransform:'uppercase',color:'#858585'}}>Sign in</div>
          <h2 style={{marginTop:6}}>Welcome back.</h2>
          <label className="pi-field"><label>Work email</label><input type="email" defaultValue="alessandro@apexcapital.com"/></label>
          <label className="pi-field"><label>Password</label><input type="password" defaultValue="••••••••"/></label>
          <button type="submit" className="pi-btn pi-btn-primary" style={{marginTop:22,width:'100%',justifyContent:'center'}}>Sign in</button>
          <div style={{marginTop:14,fontSize:12,color:'#5C5C5C',display:'flex',justifyContent:'space-between'}}><a href="#" style={{color:'#2F3E55'}}>Forgot password?</a><span>New here? <a href="#" style={{color:'#2F3E55'}}>Request access</a></span></div>
        </form>
      </div>
    </div>
  );
}

function App() {
  const [authed, setAuthed] = React.useState(() => localStorage.getItem('pi-authed') === '1');
  const [route, setRoute] = React.useState(() => localStorage.getItem('pi-route') || 'portfolio');
  React.useEffect(() => { localStorage.setItem('pi-route', route); }, [route]);
  React.useEffect(() => { localStorage.setItem('pi-authed', authed ? '1' : '0'); }, [authed]);

  if (!authed) return <Login onLogin={() => setAuthed(true)}/>;

  let screen;
  if (route === 'funds') screen = <FundDetail onBack={() => setRoute('portfolio')}/>;
  else if (route === 'benchmark') screen = <Benchmark/>;
  else if (route === 'predictions') screen = <Predictions/>;
  else screen = <Portfolio onOpen={() => setRoute('funds')}/>;

  return (
    <div className="pi-app" data-screen-label={route}>
      <Sidebar active={route} onNav={setRoute}/>
      <main className="pi-main">
        <Topbar route={route} onNav={setRoute}/>
        {screen}
      </main>
    </div>
  );
}
window.App = App;
