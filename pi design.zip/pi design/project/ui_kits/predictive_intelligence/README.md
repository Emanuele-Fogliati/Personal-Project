# Predictive Intelligence — UI Kit

A speculative SaaS application in the Cepres portfolio. Analytics for Private Equity: portfolio overview, fund detail, deal benchmarks, and forward-looking predictions.

## Files
- `index.html` — interactive click-through prototype
- `Sidebar.jsx` — primary navigation
- `Topbar.jsx` — search + user menu
- `KpiRow.jsx` — metric cards
- `PerformanceChart.jsx` — time-series line chart (SVG)
- `FundsTable.jsx` — sortable holdings table
- `PredictionPanel.jsx` — forecast card with confidence band
- `Chip.jsx`, `Button.jsx`, `Icon.jsx` — primitives

## Screens (routes in-app)
1. **Portfolio** — overview with KPIs, performance chart, funds table (default)
2. **Fund Detail** — one fund, with projection
3. **Benchmark** — compare fund vs peer set
4. **Predictions** — Predictive Intelligence hero view

## Caveats
- Built from brand standards only. No product screenshots or codebase were provided.
- Terminology (IRR, TVPI, DPI, MOIC, look-through) drawn from standard PE conventions and the brand guide.
