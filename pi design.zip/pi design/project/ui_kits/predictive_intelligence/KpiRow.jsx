// KpiRow.jsx
function KpiCard({ label, value, delta, deltaPositive, sub, variant }) {
  const cls = `pi-kpi pi-kpi-${variant || 'default'}`;
  return (
    <div className={cls}>
      <div className="pi-kpi-label">{label}</div>
      <div className="pi-kpi-value">{value}</div>
      <div className="pi-kpi-meta">
        {delta && (
          <span className={`pi-kpi-delta ${deltaPositive ? 'is-up' : 'is-down'}`}>
            {deltaPositive ? '↑' : '↓'} {delta}
          </span>
        )}
        {sub && <span className="pi-kpi-sub">{sub}</span>}
      </div>
    </div>
  );
}
function KpiRow() {
  return (
    <div className="pi-kpi-row">
      <KpiCard label="Portfolio NAV" value="$2.41B" delta="+4.2%" deltaPositive sub="vs Q1 2026" variant="default" />
      <KpiCard label="Net IRR" value="18.4%" delta="2.1 pp" deltaPositive sub="since inception" variant="warm" />
      <KpiCard label="TVPI" value="2.14×" delta="0.08×" deltaPositive sub="trailing 12 mo" variant="default" />
      <KpiCard label="DPI" value="0.87×" sub="On track to plan" variant="dawn" />
      <KpiCard label="Predicted exit" value="$3.6B" delta="+$210M" deltaPositive sub="5-yr forecast · 82% conf." variant="gold" />
    </div>
  );
}
window.KpiRow = KpiRow;
window.KpiCard = KpiCard;
