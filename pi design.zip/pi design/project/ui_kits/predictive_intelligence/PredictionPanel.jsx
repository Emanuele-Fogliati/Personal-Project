// PredictionPanel.jsx
function PredictionPanel() {
  const drivers = [
    { label:'Look-through EBITDA growth', impact:'+$140M', weight:0.62, up:true },
    { label:'Exit multiple expansion', impact:'+$90M', weight:0.48, up:true },
    { label:'FX headwind (EUR→USD)', impact:'−$20M', weight:0.18, up:false },
  ];
  return (
    <div className="pi-card pi-predict">
      <div className="pi-card-head">
        <div>
          <div className="pi-eyebrow">Predictive Intelligence</div>
          <div className="pi-card-title">5-year exit forecast · Apex Capital VII</div>
        </div>
        <span className="pi-chip pi-chip-gold">82% confidence</span>
      </div>
      <div className="pi-predict-headline">
        <div className="pi-predict-value">$3.6B</div>
        <div className="pi-predict-sub">
          Projected portfolio NAV at end-2030.
          <br/><span style={{color:'#058F8A',fontWeight: 500}}>+$210M vs consensus peer set.</span>
        </div>
      </div>
      <div className="pi-drivers">
        <div className="pi-drivers-title">Top contributors</div>
        {drivers.map(d => (
          <div key={d.label} className="pi-driver">
            <div className="pi-driver-label">{d.label}</div>
            <div className="pi-driver-bar">
              <div className={`pi-driver-fill ${d.up?'is-up':'is-down'}`} style={{width: `${d.weight*100}%`}}/>
            </div>
            <div className={`pi-driver-impact ${d.up?'is-up':'is-down'}`}>{d.impact}</div>
          </div>
        ))}
      </div>
      <div className="pi-predict-foot">
        <span style={{color:'#858585'}}>Model · CEPRES PI-v4 · 12,400 deals, 1999–2026</span>
        <button className="pi-btn pi-btn-ghost">See methodology <Icon name="arrow_right" size={14}/></button>
      </div>
    </div>
  );
}
window.PredictionPanel = PredictionPanel;
