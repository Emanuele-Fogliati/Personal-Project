// PerformanceChart.jsx — SVG line chart with forecast confidence band
function PerformanceChart({ showForecast = true }) {
  const actual = [
    { x: 0, y: 100 }, { x: 1, y: 108 }, { x: 2, y: 115 }, { x: 3, y: 124 },
    { x: 4, y: 138 }, { x: 5, y: 152 }, { x: 6, y: 168 }, { x: 7, y: 186 },
    { x: 8, y: 202 }, { x: 9, y: 214 }
  ];
  const forecast = [
    { x: 9, y: 214 }, { x: 10, y: 228 }, { x: 11, y: 244 }, { x: 12, y: 262 },
    { x: 13, y: 278 }, { x: 14, y: 296 }
  ];
  const bench = [
    { x: 0, y: 100 }, { x: 2, y: 108 }, { x: 4, y: 118 }, { x: 6, y: 132 },
    { x: 8, y: 148 }, { x: 10, y: 164 }, { x: 12, y: 180 }, { x: 14, y: 198 }
  ];
  const W = 760, H = 260, pad = { l: 44, r: 16, t: 16, b: 28 };
  const xs = (v) => pad.l + (v / 14) * (W - pad.l - pad.r);
  const ys = (v) => H - pad.b - ((v - 90) / 220) * (H - pad.t - pad.b);
  const toPath = (arr) => arr.map((p,i) => `${i?'L':'M'} ${xs(p.x)} ${ys(p.y)}`).join(' ');
  const bandTop = forecast.map(p => ({ x: p.x, y: p.y + (p.x-9)*6 }));
  const bandBot = forecast.map(p => ({ x: p.x, y: p.y - (p.x-9)*6 }));
  const bandPath = toPath(bandTop) + ' ' + bandBot.slice().reverse().map((p,i)=>`L ${xs(p.x)} ${ys(p.y)}`).join(' ') + ' Z';

  const quarters = ['Q1 24','Q3 24','Q1 25','Q3 25','Q1 26','Q3 26','Q1 27','Q3 27'];
  return (
    <svg className="pi-chart" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      {/* gridlines */}
      {[100,150,200,250,300].map((v,i) => (
        <g key={v}>
          <line x1={pad.l} x2={W-pad.r} y1={ys(v)} y2={ys(v)} stroke="#EDEEE9" strokeWidth="1"/>
          <text x={pad.l-8} y={ys(v)+4} textAnchor="end" className="pi-chart-label">{v}</text>
        </g>
      ))}
      {quarters.map((q,i) => (
        <text key={q} x={xs(i*2)} y={H-8} textAnchor="middle" className="pi-chart-label">{q}</text>
      ))}
      {/* forecast band */}
      {showForecast && <path d={bandPath} fill="#058F8A" opacity="0.12"/>}
      {/* benchmark */}
      <path d={toPath(bench)} fill="none" stroke="#00437F" strokeWidth="2" strokeDasharray="4 4"/>
      {/* actual */}
      <path d={toPath(actual)} fill="none" stroke="#058F8A" strokeWidth="2.5"/>
      {/* forecast dashed */}
      {showForecast && <path d={toPath(forecast)} fill="none" stroke="#058F8A" strokeWidth="2.5" strokeDasharray="5 4"/>}
      {/* forecast separator */}
      {showForecast && <line x1={xs(9)} x2={xs(9)} y1={pad.t} y2={H-pad.b} stroke="#D6D6D6" strokeDasharray="2 3"/>}
      {showForecast && <text x={xs(9)+6} y={pad.t+12} className="pi-chart-label" fill="#858585">Forecast →</text>}
      {/* actual dots */}
      {actual.map((p,i) => (
        <circle key={i} cx={xs(p.x)} cy={ys(p.y)} r="3" fill="#058F8A"/>
      ))}
    </svg>
  );
}
window.PerformanceChart = PerformanceChart;
