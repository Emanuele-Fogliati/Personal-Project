/* Liquidity Management tab — Phase 1 scaffolding.
   Layout: Section A (hierarchy + details) | Section B (strategy) | Section C (actions).
   Reference: descrizione.md §4. */

// ---------------- Section A.1 — compact hierarchy tree ----------------
function LiquidityTree({ selectedId, onSelect, funds }) {
  const vehicles = PI_DATA.VEHICLE_TREE;
  const root = PI_DATA.CLIENTS[0];

  // Layout constants — narrower canvas than Universe View so it fits the split.
  const MARGIN_X = 22, MARGIN_TOP = 38, LEVEL_H = 80;
  const ROOT_R = 24, VEHICLE_R = 18, SIBLING_GAP = 14, LEAF_MIN_W = 70;

  const childrenOf = (id) => vehicles.filter(v => v.parentId === id);

  const widthCache = {};
  function subtreeWidth(id) {
    if (widthCache[id] != null) return widthCache[id];
    const kids = childrenOf(id);
    let w = kids.length === 0
      ? LEAF_MIN_W
      : Math.max(LEAF_MIN_W, kids.reduce((s, k) => s + subtreeWidth(k.id), 0) + (kids.length - 1) * SIBLING_GAP);
    widthCache[id] = w;
    return w;
  }
  const totalW = subtreeWidth(root.id);
  const W = totalW + 2 * MARGIN_X;

  const nodes = [], edges = [];
  function maxDepth(id, d) {
    const k = childrenOf(id);
    return k.length === 0 ? d : Math.max(...k.map(c => maxDepth(c.id, d + 1)));
  }
  const depth = maxDepth(root.id, 0);
  function layout(id, d, startX) {
    const w = subtreeWidth(id);
    const cx = startX + w / 2;
    const cy = MARGIN_TOP + d * LEVEL_H;
    const isRoot = id === root.id;
    if (isRoot) {
      nodes.push({ id, kind: "portfolio", name: root.name, x: cx, y: cy, r: ROOT_R });
    } else {
      const v = vehicles.find(x => x.id === id);
      const compLight = PI_DATA.calculateVehicleComposition(id);
      nodes.push({ id, kind: "vehicle", name: v.name, desc: v.desc, x: cx, y: cy, r: VEHICLE_R,
        value: compLight.totalValue });
    }
    const kids = childrenOf(id);
    let cursor = startX;
    kids.forEach(k => {
      const kw = subtreeWidth(k.id);
      layout(k.id, d + 1, cursor);
      edges.push({ from: id, to: k.id });
      cursor += kw + SIBLING_GAP;
    });
  }
  layout(root.id, 0, MARGIN_X);
  const H = MARGIN_TOP + depth * LEVEL_H + VEHICLE_R + 24;

  return React.createElement("div", { className: "liq-tree-wrap" },
    React.createElement("svg", {
      className: "liq-tree-svg", viewBox: `0 0 ${W} ${H}`,
      preserveAspectRatio: "xMidYMin meet", role: "img",
      "aria-label": "Portfolio vehicle hierarchy"
    },
      edges.map((e, i) => {
        const a = nodes.find(n => n.id === e.from);
        const b = nodes.find(n => n.id === e.to);
        if (!a || !b) return null;
        const aR = a.kind === "portfolio" ? ROOT_R : VEHICLE_R;
        const ay = a.y + aR, by = b.y - VEHICLE_R;
        const midY = ay + (by - ay) * 0.55;
        return React.createElement("path", {
          key: i, className: "liq-tree-edge", fill: "none",
          d: `M ${a.x} ${ay} C ${a.x} ${midY}, ${b.x} ${midY}, ${b.x} ${by}`
        });
      }),
      nodes.map(n => {
        const active = selectedId === n.id;
        if (n.kind === "portfolio") {
          return React.createElement("g", {
            key: n.id, className: `liq-tree-node liq-tree-portfolio${active ? " is-active" : ""}`,
            transform: `translate(${n.x},${n.y})`,
            onClick: () => onSelect(n.id),
            role: "button", tabIndex: 0, "aria-label": `Portfolio ${n.name}`,
            onKeyDown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelect(n.id); } }
          },
            React.createElement("circle", { r: n.r }),
            React.createElement("text", { className: "liq-tree-lbl liq-tree-lbl-root", y: 4 }, "Portfolio"),
            React.createElement("title", null, n.name)
          );
        }
        return React.createElement("g", {
          key: n.id, className: `liq-tree-node liq-tree-vehicle${active ? " is-active" : ""}`,
          transform: `translate(${n.x},${n.y})`,
          onClick: () => onSelect(n.id),
          role: "button", tabIndex: 0,
          "aria-label": `Vehicle ${n.name}${n.desc ? " — " + n.desc : ""}`,
          onKeyDown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelect(n.id); } }
        },
          React.createElement("circle", { r: n.r }),
          React.createElement("text", { className: "liq-tree-lbl", y: 4 }, n.name),
          React.createElement("title", null, `${n.name}${n.desc ? " · " + n.desc : ""} · $${Math.round(n.value || 0)}M`)
        );
      })
    ),
    React.createElement("div", { className: "liq-tree-hint" },
      React.createElement(PI.Icon.Info, { size: 12 }),
      React.createElement("span", null, "Click any vehicle to inspect its liquidity details")
    )
  );
}

// ---------------- Section A.2 — composition pie ----------------
function CompositionPie({ composition, size = 160 }) {
  const r = size / 2 - 6, cx = size / 2, cy = size / 2;
  const entries = PI_DATA.SPEC_ASSET_TYPES
    .map(k => ({ key: k, value: composition.valueBySpecType[k] || 0 }))
    .filter(e => e.value > 0);
  const total = entries.reduce((s, e) => s + e.value, 0);
  if (total <= 0) {
    return React.createElement("div", { className: "liq-pie-empty" }, "No positions");
  }
  let acc = -Math.PI / 2;
  const slices = entries.map(e => {
    const frac = e.value / total;
    const start = acc, end = acc + frac * Math.PI * 2;
    acc = end;
    const x1 = cx + r * Math.cos(start), y1 = cy + r * Math.sin(start);
    const x2 = cx + r * Math.cos(end),   y2 = cy + r * Math.sin(end);
    const big = end - start > Math.PI ? 1 : 0;
    const d = `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${big} 1 ${x2} ${y2} Z`;
    const meta = PI_DATA.assetTypeMeta(PI_DATA.SPEC_TO_INTERNAL[e.key]);
    return { d, color: meta.color, label: meta.label, value: e.value, pct: frac };
  });
  return React.createElement("svg", {
    className: "liq-pie", width: size, height: size, viewBox: `0 0 ${size} ${size}`,
    role: "img", "aria-label": "Current composition by asset type"
  },
    slices.map((s, i) => React.createElement("path", {
      key: i, d: s.d, fill: s.color, stroke: "#fff", strokeWidth: 1.25,
      children: React.createElement("title", null, `${s.label}: $${s.value.toFixed(1)}M · ${(s.pct * 100).toFixed(1)}%`)
    })),
    React.createElement("circle", { cx, cy, r: r * 0.58, fill: "#fff" }),
    React.createElement("text", {
      x: cx, y: cy - 2, textAnchor: "middle", className: "liq-pie-total-val"
    }, `$${Math.round(total)}M`),
    React.createElement("text", {
      x: cx, y: cy + 14, textAnchor: "middle", className: "liq-pie-total-lbl"
    }, "total value")
  );
}

// ---------------- Section A.3 — sparkline ----------------
function Sparkline({ values, color, height = 40 }) {
  if (!values || values.length === 0) return null;
  const W = 240, H = height;
  const xs = values.map((_, i) => (i / (values.length - 1)) * (W - 8) + 4);
  const lo = Math.min(...values), hi = Math.max(...values);
  const ys = values.map(v => H - 4 - ((v - lo) / Math.max(hi - lo, 0.01)) * (H - 8));
  const d = xs.map((x, i) => `${i === 0 ? "M" : "L"} ${x} ${ys[i]}`).join(" ");
  const area = `${d} L ${xs[xs.length - 1]} ${H - 1} L ${xs[0]} ${H - 1} Z`;
  return React.createElement("svg", {
    viewBox: `0 0 ${W} ${H}`, className: "liq-spark", preserveAspectRatio: "none"
  },
    React.createElement("path", { d: area, fill: color + "22" }),
    React.createElement("path", { d, stroke: color, strokeWidth: 1.5, fill: "none" })
  );
}

// ---------------- Section A.4 — cashflow waterfall ----------------
function CashflowWaterfall({ vehicleId, period }) {
  const series = PI_DATA.VEHICLE_SERIES[vehicleId] || [];
  // period: "m" (last month), "q" (last quarter), "y" (last year), "all" (36 months)
  const cutoff = { m: 1, q: 3, y: 12, all: series.length }[period] || 12;
  const recent = series.slice(-cutoff);
  const rows = [];
  recent.forEach(r => {
    if (r.capCall !== 0) rows.push({ type: "Capital call", amount: r.capCall, date: r.month, direction: "in", source: "From parent vehicle" });
    if (r.distrib !== 0) rows.push({ type: "Distribution", amount: r.distrib, date: r.month, direction: "in", source: "From child vehicle" });
    if (r.capDraw !== 0) rows.push({ type: "Capital drawdown", amount: r.capDraw, date: r.month, direction: "out", source: "To parent vehicle" });
    if (r.contrib !== 0) rows.push({ type: "Contribution", amount: r.contrib, date: r.month, direction: "out", source: "To child vehicle" });
  });
  rows.sort((a, b) => b.date.localeCompare(a.date));
  const shown = rows.slice(0, 20);
  if (shown.length === 0) {
    return React.createElement("div", { className: "liq-empty" }, "No cashflows in this period.");
  }
  return React.createElement("div", { className: "liq-cf-table-wrap" },
    React.createElement("table", { className: "liq-cf-table" },
      React.createElement("thead", null,
        React.createElement("tr", null,
          React.createElement("th", null, "Type"),
          React.createElement("th", { className: "liq-num" }, "Amount"),
          React.createElement("th", null, "Date"),
          React.createElement("th", null, "Source / destination")
        )
      ),
      React.createElement("tbody", null,
        shown.map((r, i) => React.createElement("tr", { key: i },
          React.createElement("td", null,
            React.createElement("span", { className: `liq-cf-dir liq-cf-dir-${r.direction}` },
              React.createElement(r.direction === "in" ? PI.Icon.ArrowDown : PI.Icon.ArrowUp, { size: 11 })
            ),
            r.type
          ),
          React.createElement("td", { className: `liq-num ${r.amount >= 0 ? "pos" : "neg"}` },
            (r.amount >= 0 ? "+" : "") + PI.fmt.moneyPlain(r.amount)
          ),
          React.createElement("td", null, r.date),
          React.createElement("td", { className: "liq-muted" }, r.source)
        ))
      )
    ),
    rows.length > 20 && React.createElement("div", { className: "liq-cf-more" },
      `+${rows.length - 20} more rows`
    )
  );
}

// ---------------- Section A.5 — asset-specific details ----------------
function AssetSpecificSections({ vehicleId }) {
  // Include look-through so parents show what their descendants hold
  const ids = [vehicleId, ...PI_DATA.descendantVehicles(vehicleId).map(v => v.id)];
  const positions = PI_DATA.FUNDS.filter(f => ids.includes(f.vehicleId));

  const by = (internalTypes) => positions.filter(p => internalTypes.includes(p.assetType));
  const cashPos      = by(["cash"]);
  const bondPos      = by(["bond"]);
  const equityPos    = by(["stock", "etf"]);
  const hedgePos     = by(["hedge"]);
  const secondaryPos = by(["secondary"]);
  const primaryPos   = by(["primary", "coinvestment"]);

  const section = (title, count, content) =>
    count === 0 ? null : React.createElement("details", { className: "liq-asset-sec", open: count <= 3 },
      React.createElement("summary", null,
        React.createElement("span", null, title),
        React.createElement("span", { className: "liq-pill" }, count)
      ),
      content
    );

  // Hedge funds — redemption window + remaining cap + status
  const hedgeRow = (p) => {
    // Prototype placeholders: quarterly redemption, 30d notice, $X cap remaining.
    const nextWin = "Q3 2026";
    const noticeEnd = "Jun 30 2026";
    const remCap = Math.max(0, p.nav * 0.3 - p.nav * 0.12);
    const status = p.nav > 100 ? "Redemption available" : "Notice period active";
    return React.createElement("tr", { key: p.id },
      React.createElement("td", null, p.name),
      React.createElement("td", { className: "liq-num" }, PI.fmt.money(p.nav)),
      React.createElement("td", null, nextWin),
      React.createElement("td", null, noticeEnd),
      React.createElement("td", { className: "liq-num" }, PI.fmt.money(remCap)),
      React.createElement("td", null,
        React.createElement("span", { className: `liq-badge liq-badge-${status === "Redemption available" ? "ok" : "warn"}` }, status)
      )
    );
  };

  const bondRow = (p) => {
    const ad = p.acquisition_details || {};
    const mat = ad.maturity_date || "—";
    const couponPct = ad.coupon_rate != null ? (ad.coupon_rate * 100).toFixed(2) + "%" : "—";
    const freq = ad.coupon_frequency || "—";
    const ytm = ad.ytm != null ? (ad.ytm * 100).toFixed(2) + "%" : "—";
    // Next coupon estimate: 6 months or 12 months out depending on frequency
    const nextCoupon = freq === "annual" ? "Next 12m" : "Next 6m";
    const nextAmt = ad.coupon_rate ? p.nav * ad.coupon_rate * (freq === "annual" ? 1 : 0.5) : 0;
    return React.createElement("tr", { key: p.id },
      React.createElement("td", null, p.name),
      React.createElement("td", { className: "liq-num" }, PI.fmt.money(p.nav)),
      React.createElement("td", null, couponPct),
      React.createElement("td", null, freq),
      React.createElement("td", null, `${nextCoupon} · ${PI.fmt.money(nextAmt)}`),
      React.createElement("td", null, mat),
      React.createElement("td", { className: "liq-num" }, ytm)
    );
  };

  const eqRow = (p) => React.createElement("tr", { key: p.id },
    React.createElement("td", null, p.name),
    React.createElement("td", null, p.ticker || "—"),
    React.createElement("td", { className: "liq-num" }, PI.fmt.money(p.nav)),
    React.createElement("td", null,
      React.createElement("span", { className: `liq-pill liq-pill-${p.assetType}` },
        p.assetType.toUpperCase()))
  );

  const privRow = (p) => React.createElement("tr", { key: p.id },
    React.createElement("td", null, p.name),
    React.createElement("td", { className: "liq-num" }, PI.fmt.money(p.nav)),
    React.createElement("td", null, p.vintage || "—"),
    React.createElement("td", null, p.stage || "—"),
    React.createElement("td", null, p.gp || "—")
  );

  const cashRow = (p) => React.createElement("tr", { key: p.id },
    React.createElement("td", null, p.name),
    React.createElement("td", null, p.currency || "USD"),
    React.createElement("td", { className: "liq-num" }, PI.fmt.money(p.nav))
  );

  return React.createElement("div", { className: "liq-asset-sections" },
    section("Cash", cashPos.length,
      React.createElement("table", { className: "liq-asset-table" },
        React.createElement("thead", null, React.createElement("tr", null,
          React.createElement("th", null, "Account"),
          React.createElement("th", null, "Currency"),
          React.createElement("th", { className: "liq-num" }, "Balance")
        )),
        React.createElement("tbody", null, cashPos.map(cashRow))
      )),
    section("Hedge funds", hedgePos.length,
      React.createElement("table", { className: "liq-asset-table" },
        React.createElement("thead", null, React.createElement("tr", null,
          React.createElement("th", null, "Fund"),
          React.createElement("th", { className: "liq-num" }, "Current value"),
          React.createElement("th", null, "Next window"),
          React.createElement("th", null, "Notice ends"),
          React.createElement("th", { className: "liq-num" }, "Remaining cap"),
          React.createElement("th", null, "Status")
        )),
        React.createElement("tbody", null, hedgePos.map(hedgeRow))
      )),
    section("Bonds", bondPos.length,
      React.createElement("table", { className: "liq-asset-table" },
        React.createElement("thead", null, React.createElement("tr", null,
          React.createElement("th", null, "Bond"),
          React.createElement("th", { className: "liq-num" }, "Current value"),
          React.createElement("th", null, "Coupon"),
          React.createElement("th", null, "Frequency"),
          React.createElement("th", null, "Next coupon"),
          React.createElement("th", null, "Maturity"),
          React.createElement("th", { className: "liq-num" }, "YTM")
        )),
        React.createElement("tbody", null, bondPos.map(bondRow))
      )),
    section("Stocks & ETFs", equityPos.length,
      React.createElement("table", { className: "liq-asset-table" },
        React.createElement("thead", null, React.createElement("tr", null,
          React.createElement("th", null, "Name"),
          React.createElement("th", null, "Ticker"),
          React.createElement("th", { className: "liq-num" }, "Current value"),
          React.createElement("th", null, "Type")
        )),
        React.createElement("tbody", null, equityPos.map(eqRow))
      )),
    section("Secondary funds", secondaryPos.length,
      React.createElement("table", { className: "liq-asset-table" },
        React.createElement("thead", null, React.createElement("tr", null,
          React.createElement("th", null, "Fund"),
          React.createElement("th", { className: "liq-num" }, "Current value"),
          React.createElement("th", null, "Vintage"),
          React.createElement("th", null, "Stage"),
          React.createElement("th", null, "GP")
        )),
        React.createElement("tbody", null, secondaryPos.map(privRow))
      )),
    section("Primary funds", primaryPos.length,
      React.createElement("table", { className: "liq-asset-table" },
        React.createElement("thead", null, React.createElement("tr", null,
          React.createElement("th", null, "Fund"),
          React.createElement("th", { className: "liq-num" }, "Current value"),
          React.createElement("th", null, "Vintage"),
          React.createElement("th", null, "Stage"),
          React.createElement("th", null, "GP")
        )),
        React.createElement("tbody", null, primaryPos.map(privRow))
      ))
  );
}

// ---------------- Section A — Vehicle Details Panel ----------------
function VehicleDetailsPanel({ vehicleId, onClose }) {
  const [cfPeriod, setCfPeriod] = PI.useState("q");
  if (!vehicleId) {
    return React.createElement("div", { className: "liq-details-empty" },
      React.createElement(PI.Icon.Layers, { size: 28 }),
      React.createElement("div", { className: "liq-details-empty-title" }, "Select a vehicle"),
      React.createElement("div", { className: "liq-details-empty-sub" }, "Click any node in the hierarchy to inspect its cash balance, composition, and cashflow waterfall.")
    );
  }
  const vehicle = PI_DATA.vehicleById(vehicleId);
  if (!vehicle) return null;
  const composition = PI_DATA.calculateVehicleComposition(vehicleId);
  const series = PI_DATA.VEHICLE_SERIES[vehicleId] || [];
  const cashNow = series.length ? series[series.length - 1].cash : 0;
  const valueNow = composition.totalValue;
  const ancestry = PI_DATA.getVehicleAncestry(vehicleId);
  const level = ancestry.length - 1;
  const maxLevel = Math.max(...PI_DATA.VEHICLE_TREE.map(v => PI_DATA.getVehicleAncestry(v.id).length - 1));

  const compRows = PI_DATA.SPEC_ASSET_TYPES
    .map(k => {
      const val = composition.valueBySpecType[k] || 0;
      const meta = PI_DATA.assetTypeMeta(PI_DATA.SPEC_TO_INTERNAL[k]);
      const pct = valueNow > 0 ? val / valueNow : 0;
      return { spec: k, val, pct, label: meta.label, color: meta.color };
    })
    .filter(r => r.val > 0)
    .sort((a, b) => b.val - a.val);

  return React.createElement("div", { className: "liq-details" },
    React.createElement("div", { className: "liq-details-head" },
      React.createElement("div", null,
        React.createElement("div", { className: "drawer-eyebrow" },
          ancestry.slice(0, -1).map(a => a.name).join(" › ") + " ›"
        ),
        React.createElement("h3", { className: "liq-details-title" },
          vehicle.name,
          vehicle.desc && React.createElement("span", { className: "liq-details-sub" }, " · " + vehicle.desc)
        ),
        React.createElement("div", { className: "liq-details-level" },
          `Level ${level} of ${maxLevel}`
        )
      ),
      React.createElement(PI.IconBtn, {
        icon: React.createElement(PI.Icon.X, { size: 14 }),
        title: "Close details", onClick: onClose
      })
    ),

    // Overview KPI strip — cash + total value w/ sparklines
    React.createElement("div", { className: "liq-details-kpis" },
      React.createElement("div", { className: "liq-details-kpi" },
        React.createElement("div", { className: "liq-details-kpi-lbl" }, "Current cash"),
        React.createElement("div", { className: "liq-details-kpi-val num" }, PI.fmt.money(cashNow)),
        React.createElement(Sparkline, { values: series.slice(-14).map(r => r.cash), color: "#058F8A" })
      ),
      React.createElement("div", { className: "liq-details-kpi" },
        React.createElement("div", { className: "liq-details-kpi-lbl" }, "Portfolio value"),
        React.createElement("div", { className: "liq-details-kpi-val num" }, PI.fmt.money(valueNow)),
        React.createElement(Sparkline, { values: series.slice(-14).map(r => r.value), color: "#2F3E55" })
      )
    ),

    // Composition
    React.createElement("section", { className: "liq-details-section" },
      React.createElement("div", { className: "liq-details-section-head" },
        React.createElement("h4", { className: "liq-details-section-title" }, "Current composition"),
        React.createElement("div", { className: "liq-details-section-sub" },
          "% breakdown across the 7 liquidity asset types")
      ),
      React.createElement("div", { className: "liq-comp-grid" },
        React.createElement(CompositionPie, { composition, size: 160 }),
        React.createElement("table", { className: "liq-comp-table" },
          React.createElement("thead", null, React.createElement("tr", null,
            React.createElement("th", null, "Asset type"),
            React.createElement("th", { className: "liq-num" }, "Value"),
            React.createElement("th", { className: "liq-num" }, "Share")
          )),
          React.createElement("tbody", null,
            compRows.length === 0
              ? React.createElement("tr", null, React.createElement("td", { colSpan: 3, className: "liq-muted" }, "No positions in this vehicle."))
              : compRows.map(r => React.createElement("tr", { key: r.spec },
                  React.createElement("td", null,
                    React.createElement("span", { className: "liq-comp-dot", style: { background: r.color } }),
                    r.label
                  ),
                  React.createElement("td", { className: "liq-num" }, PI.fmt.money(r.val)),
                  React.createElement("td", { className: "liq-num" }, (r.pct * 100).toFixed(1) + "%")
                ))
          )
        )
      )
    ),

    // Cashflow waterfall
    React.createElement("section", { className: "liq-details-section" },
      React.createElement("div", { className: "liq-details-section-head" },
        React.createElement("h4", { className: "liq-details-section-title" }, "Cashflow waterfall"),
        React.createElement("div", { className: "liq-details-period" },
          ["m", "q", "y", "all"].map(p => React.createElement("button", {
            key: p, className: `liq-period-btn${cfPeriod === p ? " is-active" : ""}`,
            onClick: () => setCfPeriod(p)
          }, p === "m" ? "1M" : p === "q" ? "3M" : p === "y" ? "1Y" : "All"))
        )
      ),
      React.createElement(CashflowWaterfall, { vehicleId, period: cfPeriod })
    ),

    // Asset-specific sections
    React.createElement("section", { className: "liq-details-section" },
      React.createElement("div", { className: "liq-details-section-head" },
        React.createElement("h4", { className: "liq-details-section-title" }, "Asset-specific details")
      ),
      React.createElement(AssetSpecificSections, { vehicleId })
    )
  );
}

// ---------------- Section B — Strategy configuration ----------------
// Phase 2: wired against PI_DATA.LIQUIDITY_STRATEGIES / VEHICLE_STRATEGY_ASSIGNMENTS.
// `tick` is bumped externally by LiquidityTab after create/update/delete so we
// re-read from PI_DATA (mutation-based repo, not React state).
function StrategyConfigPanel({ selectedVehicleId, onSelectVehicle, onEditStrategy, onToast, onDataChange, tick }) {
  const presets = PI_DATA.getPresetStrategies();

  const vehicleOpts = [
    { value: "", label: "— Select vehicle —" },
    ...PI_DATA.VEHICLE_TREE.map(v => ({ value: v.id, label: `${v.name} · ${v.desc || ""}` }))
  ];

  const selected = selectedVehicleId && PI_DATA.vehicleById(selectedVehicleId);
  const currentStrategy = selectedVehicleId ? PI_DATA.getStrategyByVehicleId(selectedVehicleId) : null;
  // `tick` is read to re-render on data mutations (React doesn't know about PI_DATA mutations).
  void tick;

  const assignPreset = (presetId) => {
    try {
      PI_DATA.applyStrategyToVehicles(presetId, [selectedVehicleId]);
      const p = presets.find(x => x.id === presetId);
      onDataChange && onDataChange();
      onToast && onToast(`Applied "${p?.name}" preset to ${selected.name}`, "ok");
    } catch (e) {
      onToast && onToast(`Could not apply preset: ${e.message}`, "error");
    }
  };

  const fmtTimestamp = (iso) => {
    if (!iso) return "—";
    try { return new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }); }
    catch (_) { return iso; }
  };

  return React.createElement("div", { className: "liq-strat" },
    React.createElement("div", { className: "liq-strat-head" },
      React.createElement("div", { className: "eyebrow" }, "Section B — Strategy configuration"),
      React.createElement("h3", { className: "liq-strat-title" }, "Liquidity strategy")
    ),

    React.createElement("div", { className: "liq-strat-selector" },
      React.createElement("label", { className: "label", htmlFor: "liq-veh-sel" }, "Vehicle"),
      React.createElement(PI.Dropdown, {
        value: selectedVehicleId || "",
        options: vehicleOpts,
        onChange: onSelectVehicle,
        icon: React.createElement(PI.Icon.Filter, { size: 13 }),
        minWidth: 260
      })
    ),

    !selected && React.createElement("div", { className: "liq-strat-empty" },
      "Pick a vehicle from the hierarchy or the dropdown above to configure or review its liquidity strategy."),

    selected && React.createElement(PI.Fragment, null,
      React.createElement("div", { className: "liq-strat-current" },
        React.createElement("div", { className: "liq-strat-current-lbl" }, "Current strategy"),
        currentStrategy
          ? React.createElement("div", null,
              React.createElement("div", { className: "liq-strat-current-name" }, currentStrategy.name),
              currentStrategy.description && React.createElement("div", { className: "liq-strat-current-desc" }, currentStrategy.description),
              React.createElement("div", { className: "liq-strat-modified" }, `Last modified · ${fmtTimestamp(currentStrategy.updated_at)}`)
            )
          : React.createElement("div", { className: "liq-strat-none" },
              React.createElement(PI.Icon.Warning, { size: 14 }),
              React.createElement("span", null, "No strategy configured")
            )
      ),

      React.createElement("div", { className: "liq-strat-actions" },
        React.createElement(PI.Btn, {
          kind: "primary", size: "sm",
          icon: React.createElement(PI.Icon.Edit, { size: 12 }),
          onClick: () => onEditStrategy(selected.id)
        }, currentStrategy ? "Edit strategy" : "Create strategy")
      ),

      React.createElement("div", { className: "liq-strat-presets" },
        React.createElement("div", { className: "eyebrow" }, "Or apply a preset"),
        React.createElement("div", { className: "liq-strat-preset-grid" },
          presets.map(p => {
            const isCurrent = currentStrategy && currentStrategy.name && currentStrategy.name.startsWith(p.name);
            return React.createElement("button", {
              key: p.id, type: "button",
              className: `liq-strat-preset${isCurrent ? " is-active" : ""}`,
              onClick: () => assignPreset(p.id),
              title: `Clone "${p.name}" preset onto this vehicle`
            },
              React.createElement("div", { className: "liq-strat-preset-name" }, p.name),
              React.createElement("div", { className: "liq-strat-preset-desc" }, p.description)
            );
          })
        )
      )
    )
  );
}

// ---------------- Root: LiquidityTab ----------------
// Configuration-only entry point: pick a vehicle, view/edit its strategy,
// or apply a preset. Run-forecast / Run-simulation actions intentionally
// removed — the user runs both from the Portfolio Detail header buttons.
function LiquidityTab({ portfolio, funds, onToast }) {
  const [selectedId, setSelectedId] = PI.useState("V-08"); // default: first leaf under NA Buyout
  const [stratVehicleId, setStratVehicleId] = PI.useState("V-08");
  const [editorVehicleId, setEditorVehicleId] = PI.useState(null); // modal open iff non-null
  // tick increments after a strategy mutation so child panels re-read from PI_DATA.
  const [tick, setTick] = PI.useState(0);

  // Keep Section B in sync when the user picks a vehicle from the tree
  const handleSelect = (id) => {
    setSelectedId(id);
    if (id && !id.startsWith("CL-")) setStratVehicleId(id);
  };

  const openEditor = (vehicleId) => setEditorVehicleId(vehicleId);
  const closeEditor = () => setEditorVehicleId(null);

  const handleSaveStrategy = (payload) => {
    if (!editorVehicleId) return;
    const existing = PI_DATA.getStrategyByVehicleId(editorVehicleId);
    try {
      if (existing && !existing.is_preset) {
        PI_DATA.updateStrategy(existing.id, payload);
        onToast && onToast("Strategy updated", "ok");
      } else {
        PI_DATA.createStrategy(editorVehicleId, payload);
        onToast && onToast("Strategy created", "ok");
      }
      setTick(t => t + 1);
      setEditorVehicleId(null);
    } catch (e) {
      // validation errors are handled inside the modal; this catch only fires
      // for unexpected exceptions.
      onToast && onToast(`Could not save strategy: ${e.message}`, "error");
    }
  };

  const editorInitial = editorVehicleId ? PI_DATA.getStrategyByVehicleId(editorVehicleId) : null;

  return React.createElement("div", { className: "liq-tab", "data-screen-label": "02c Liquidity Management" },
    React.createElement("div", { className: "liq-grid" },
      // Section A — left column
      React.createElement("div", { className: "liq-col liq-col-a" },
        React.createElement("div", { className: "liq-col-head" },
          React.createElement("div", { className: "eyebrow" }, "Section A — Vehicle hierarchy"),
          React.createElement("h3", { className: "liq-col-title" }, "Portfolio structure")
        ),
        React.createElement(LiquidityTree, {
          selectedId, onSelect: handleSelect, funds
        }),
        React.createElement(VehicleDetailsPanel, {
          vehicleId: selectedId && !selectedId.startsWith("CL-") ? selectedId : null,
          onClose: () => setSelectedId(null)
        })
      ),
      // Section B — right column
      React.createElement("div", { className: "liq-col liq-col-b" },
        React.createElement(StrategyConfigPanel, {
          selectedVehicleId: stratVehicleId,
          onSelectVehicle: (id) => { setStratVehicleId(id); if (id) setSelectedId(id); },
          onEditStrategy: openEditor,
          onDataChange: () => setTick(t => t + 1),
          onToast,
          tick
        })
      )
    ),
    // Phase 2 — Strategy editor modal
    editorVehicleId && React.createElement(PI.StrategyEditorModal, {
      vehicleId: editorVehicleId,
      initialStrategy: editorInitial,
      onSave: handleSaveStrategy,
      onClose: closeEditor,
      onToast
    })
  );
}

window.PI.LiquidityTab = LiquidityTab;
// Exported so the simulation / immediate-forecast results pages can render
// the full vehicle hierarchy as an always-visible inspection panel.
window.PI.LiquidityTree = LiquidityTree;
