/* Universe View — top-down hierarchy tree of Portfolio → Vehicles → Investments.
   Includes Vehicle Detail inspector with capital calls/drawdowns, cash & value
   over time, strategy & rebalancing presets, and MC params entry points. */

function UniverseBubbles({ funds, onInspect, inspectedVehicleId, onToast, filterAssetTypes }) {
  const vehicles = PI_DATA.VEHICLE_TREE;
  const clients = PI_DATA.CLIENTS;
  const root = clients[0];

  // --- Interactivity: drag-to-reposition + double-click for details ---
  const [nodeOffsets, setNodeOffsets] = PI.useState({});
  const svgRef = PI.useRef(null);
  const dragRef = PI.useRef(null);

  PI.useEffect(() => {
    function onMove(ev) {
      const d = dragRef.current;
      if (!d) return;
      const dxCss = ev.clientX - d.startX;
      const dyCss = ev.clientY - d.startY;
      if (Math.abs(dxCss) > 3 || Math.abs(dyCss) > 3) d.moved = true;
      if (d.moved) {
        const nx = d.origDx + dxCss * d.scaleX;
        const ny = d.origDy + dyCss * d.scaleY;
        setNodeOffsets(o => ({ ...o, [d.id]: { dx: nx, dy: ny } }));
      }
    }
    function onUp() {
      const d = dragRef.current;
      if (!d) return;
      // Keep the moved flag briefly so a subsequent click can be suppressed.
      if (d.moved) {
        d.justDragged = true;
        setTimeout(() => { d.justDragged = false; }, 50);
      }
      dragRef.current = d.moved ? d : null;
    }
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup",   onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup",   onUp);
    };
  }, []);

  function startDrag(id, e) {
    if (!svgRef.current) return;
    e.stopPropagation();
    const rect = svgRef.current.getBoundingClientRect();
    const vb = svgRef.current.viewBox.baseVal;
    const cur = nodeOffsets[id] || { dx: 0, dy: 0 };
    dragRef.current = {
      id,
      startX: e.clientX, startY: e.clientY,
      origDx: cur.dx, origDy: cur.dy,
      scaleX: vb.width  / Math.max(rect.width,  1),
      scaleY: vb.height / Math.max(rect.height, 1),
      moved: false, justDragged: false
    };
  }
  function guardedClick(handler) {
    return (e) => {
      if (dragRef.current && dragRef.current.justDragged) {
        e.preventDefault(); e.stopPropagation();
        dragRef.current.justDragged = false;
        return;
      }
      handler(e);
    };
  }
  function offsetOf(id) { return nodeOffsets[id] || { dx: 0, dy: 0 }; }

  // ---- Layout constants ----
  const MARGIN_X     = 32;
  const MARGIN_TOP   = 50;
  const LEVEL_H      = 110;
  const ROOT_R       = 34;
  const VEHICLE_R    = 22;
  const SIBLING_GAP  = 20;
  const LEAF_MIN_W   = 130;
  const DOT_R        = 6;
  const DOT_GAP      = 4;
  const DOTS_TOP_PAD = 36; // distance from vehicle-node-center to top row of dot grid
  const BOTTOM_PAD   = 30;

  const childrenOf   = (id) => vehicles.filter(v => v.parentId === id);
  const directFundsOf = (id) => funds.filter(f => f.vehicleId === id)
    .filter(f => filterAssetTypes ? filterAssetTypes.has(f.assetType) : true);

  // Grid dimensions for N dots — prefer compact, slightly wider than tall
  function gridDims(n) {
    if (n <= 0) return { cols: 0, rows: 0, w: 0, h: 0 };
    let cols;
    if (n <= 2)      cols = n;
    else if (n <= 4) cols = 2;
    else if (n <= 6) cols = 3;
    else if (n <= 9) cols = 3;
    else if (n <= 12) cols = 4;
    else if (n <= 16) cols = 5;
    else              cols = 6;
    const rows = Math.ceil(n / cols);
    const w = cols * (2 * DOT_R) + (cols - 1) * DOT_GAP;
    const h = rows * (2 * DOT_R) + (rows - 1) * DOT_GAP;
    return { cols, rows, w, h };
  }

  // Max tree depth
  function maxDepth(id, d) {
    const kids = childrenOf(id);
    if (kids.length === 0) return d;
    return Math.max(...kids.map(k => maxDepth(k.id, d + 1)));
  }
  const depth = maxDepth(root.id, 0);

  // Subtree pixel width
  const widthCache = {};
  function subtreeWidth(id) {
    if (widthCache[id] != null) return widthCache[id];
    const kids = childrenOf(id);
    const directs = id === root.id ? [] : directFundsOf(id);
    const fundW = gridDims(directs.length).w;
    let w;
    if (kids.length === 0) {
      w = Math.max(LEAF_MIN_W, fundW + 12);
    } else {
      const kidsW = kids.reduce((s, k) => s + subtreeWidth(k.id), 0)
                  + (kids.length - 1) * SIBLING_GAP;
      w = Math.max(kidsW, LEAF_MIN_W, fundW + 12);
    }
    widthCache[id] = w;
    return w;
  }

  const totalW = subtreeWidth(root.id);
  const W = totalW + 2 * MARGIN_X;

  // Walk the tree and place nodes
  const nodes = [];
  const edges = [];
  const assetDots = [];

  function layout(id, d, startX) {
    const w  = subtreeWidth(id);
    const cx = startX + w / 2;
    const cy = MARGIN_TOP + d * LEVEL_H;
    const isRoot = id === root.id;

    if (isRoot) {
      nodes.push({ id, kind: "portfolio", name: root.name, x: cx, y: cy, r: ROOT_R });
    } else {
      const vehicle = vehicles.find(v => v.id === id);
      nodes.push({
        id, kind: "vehicle", vKind: vehicle.kind,
        name: vehicle.name, desc: vehicle.desc,
        x: cx, y: cy, r: VEHICLE_R
      });
    }

    // Place direct investment dots under the vehicle node (centered horizontally)
    if (!isRoot) {
      const directs = directFundsOf(id);
      if (directs.length > 0) {
        const g = gridDims(directs.length);
        const topY  = cy + DOTS_TOP_PAD;
        const leftX = cx - g.w / 2 + DOT_R;
        directs.forEach((f, i) => {
          const col = i % g.cols;
          const row = Math.floor(i / g.cols);
          const dx = leftX + col * (2 * DOT_R + DOT_GAP);
          const dy = topY  + row * (2 * DOT_R + DOT_GAP) + DOT_R;
          assetDots.push({
            id: f.id, parentId: id, x: dx, y: dy,
            color: PI_DATA.assetTypeMeta(f.assetType).color,
            name: f.name, assetType: f.assetType, fund: f
          });
        });
      }
    }

    // Recurse into vehicle children, laying them out left-to-right
    const kids = childrenOf(id);
    let cursor = startX;
    kids.forEach(k => {
      const kw = subtreeWidth(k.id);
      layout(k.id, d + 1, cursor);
      edges.push({ from: id, to: k.id });
      cursor += kw + SIBLING_GAP;
    });
  }

  layout(root.id, 0, MARGIN_X);

  // Canvas height: deepest node + any dot grid hanging below + padding
  let bottomY = MARGIN_TOP + depth * LEVEL_H + VEHICLE_R;
  assetDots.forEach(d => { if (d.y + DOT_R > bottomY) bottomY = d.y + DOT_R; });
  const H = bottomY + BOTTOM_PAD;

  return React.createElement("div", { className: "uv-canvas-wrap" },
    React.createElement("svg", {
      className: "uv-canvas uv-canvas-tree",
      viewBox: `0 0 ${W} ${H}`,
      preserveAspectRatio: "xMidYMin meet",
      ref: svgRef
    },
      // Edges (drawn first, beneath). Endpoints track each node's drag offset.
      edges.map((e, i) => {
        const a = nodes.find(n => n.id === e.from);
        const b = nodes.find(n => n.id === e.to);
        if (!a || !b) return null;
        const aR = a.kind === "portfolio" ? ROOT_R : VEHICLE_R;
        const bR = VEHICLE_R;
        const ao = offsetOf(a.id), bo = offsetOf(b.id);
        const ax = a.x + ao.dx, ay = a.y + aR + ao.dy;
        const bx = b.x + bo.dx, by = b.y - bR + bo.dy;
        const midY = ay + (by - ay) * 0.55;
        return React.createElement("path", {
          key: `e-${i}`,
          d: `M ${ax} ${ay} C ${ax} ${midY}, ${bx} ${midY}, ${bx} ${by}`,
          className: "uv-edge-tree",
          fill: "none"
        });
      }),

      // Nodes — draggable + double-click-to-inspect.
      nodes.map(n => {
        const active = inspectedVehicleId === n.id;
        const off = offsetOf(n.id);
        const tx = n.x + off.dx, ty = n.y + off.dy;
        if (n.kind === "portfolio") {
          return React.createElement("g", {
            key: n.id,
            className: "uv-node uv-node-portfolio uv-draggable",
            transform: `translate(${tx},${ty})`,
            onMouseDown: (ev) => startDrag(n.id, ev),
            onClick: guardedClick(() => onInspect(null)),
            onDoubleClick: () => onInspect(null)
          },
            React.createElement("circle", { r: n.r }),
            React.createElement("text", { className: "uv-label uv-label-root", y: 4 }, "Portfolio"),
            React.createElement("title", null, `${n.name} — drag to reposition, double-click for details`)
          );
        }
        return React.createElement("g", {
          key: n.id,
          className: `uv-node uv-node-vehicle uv-draggable${active ? " is-active" : ""}`,
          transform: `translate(${tx},${ty})`,
          onMouseDown: (ev) => startDrag(n.id, ev),
          onClick: guardedClick(() => onInspect(n.id)),
          onDoubleClick: () => onInspect(n.id)
        },
          React.createElement("circle", { r: n.r }),
          React.createElement("text", { className: "uv-label uv-label-vehicle", y: 4 }, n.name),
          React.createElement("title", null, `${n.name} · ${n.desc || ""} — drag to reposition, double-click for details`)
        );
      }),

      // Asset dots (drawn last, on top). Follow their parent vehicle's drag offset.
      assetDots.map(d => {
        const pOff = offsetOf(d.parentId);
        return React.createElement("g", {
          key: d.id,
          className: `uv-node uv-node-asset at-${d.assetType}`,
          transform: `translate(${d.x + pOff.dx},${d.y + pOff.dy})`,
          onClick: () => onToast && onToast(d.name, "info")
        },
          React.createElement("circle", { r: DOT_R, fill: d.color, stroke: "#fff", strokeWidth: 1.25 }),
          React.createElement("title", null, d.name)
        );
      })
    ),
    // Legend + interactive hint
    React.createElement("div", { className: "uv-legend" },
      React.createElement("div", { className: "uv-legend-title" }, "Asset types"),
      React.createElement("div", { className: "uv-legend-items" },
        PI_DATA.ASSET_TYPES.map(a => React.createElement("span", { key: a.id, className: "uv-legend-item" },
          React.createElement("span", { className: "uv-legend-dot", style: { background: a.color } }),
          React.createElement("span", null, a.label)
        ))
      ),
      React.createElement("div", { className: "uv-legend-hint" },
        React.createElement("span", null, "Drag any bubble to rearrange · Double-click to inspect"),
        Object.keys(nodeOffsets).length > 0 && React.createElement("button", {
          type: "button", className: "uv-reset-layout-btn",
          onClick: () => setNodeOffsets({})
        }, "Reset layout")
      )
    )
  );
}

// ---------- Vehicle Detail inspector ----------
function VehicleInspector({ vehicleId, funds, onClose, onToast, onSwitchToTable }) {
  const [tab, setTab] = PI.useState("overview");
  const [assetMix, setAssetMix] = PI.useState(new Set(PI_DATA.ASSET_TYPES.map(a => a.id)));
  const [strategy, setStrategy] = PI.useState("balanced");
  const [checkpoints, setCheckpoints] = PI.useState([
    { id: "cp-1", name: "Base strategy · balanced", when: "2026-04-01", active: true }
  ]);
  const vehicle = PI_DATA.vehicleById(vehicleId);
  if (!vehicle) return null;

  const descendantIds = [vehicle.id, ...PI_DATA.descendantVehicles(vehicle.id).map(v => v.id)];
  const directAssets = funds.filter(f => f.vehicleId === vehicle.id);
  const allAssets = funds.filter(f => descendantIds.includes(f.vehicleId));

  const series = PI_DATA.VEHICLE_SERIES[vehicleId] || [];
  const totalValue = PI_DATA.aggregateVehicleValue(vehicleId);
  const cashNow = series.length ? series[series.length - 1].cash : 0;

  // Aggregate cashflow totals
  const totals = series.reduce((s, r) => ({
    capCall: s.capCall + r.capCall,
    capDraw: s.capDraw + r.capDraw,
    contrib: s.contrib + r.contrib,
    distrib: s.distrib + r.distrib,
  }), { capCall: 0, capDraw: 0, contrib: 0, distrib: 0 });

  const preset = PI_DATA.STRATEGY_PRESETS.find(s => s.id === strategy);

  // Cash & value mini sparkline
  function sparkline(field, color, height=60) {
    if (!series.length) return null;
    const W = 640, H = height;
    const xs = series.map((_, i) => (i / (series.length - 1)) * (W - 16) + 8);
    const vals = series.map(r => r[field]);
    const lo = Math.min(...vals), hi = Math.max(...vals);
    const ys = vals.map(v => H - 8 - ((v - lo) / Math.max(hi - lo, 0.1)) * (H - 16));
    const d = xs.map((x, i) => `${i === 0 ? "M" : "L"} ${x} ${ys[i]}`).join(" ");
    const area = `${d} L ${xs[xs.length-1]} ${H-2} L ${xs[0]} ${H-2} Z`;
    return React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, style: { display: "block" } },
      React.createElement("path", { d: area, fill: color + "22" }),
      React.createElement("path", { d, stroke: color, strokeWidth: 1.5, fill: "none" })
    );
  }

  // Cashflow bars by month
  function cashflowBars(height=120) {
    if (!series.length) return null;
    const W = 640, H = height;
    const step = (W - 20) / series.length;
    const absMax = Math.max(
      ...series.map(r => Math.max(Math.abs(r.capCall + r.distrib), Math.abs(r.capDraw + r.contrib)))
    ) || 1;
    const y0 = H / 2;
    const scale = (H / 2 - 8) / absMax;
    return React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, style: { display: "block" } },
      React.createElement("line", { x1: 10, x2: W - 10, y1: y0, y2: y0, stroke: "var(--rule)", strokeDasharray: "3 3" }),
      series.map((r, i) => {
        const x = 10 + i * step + step * 0.1;
        const w = Math.max(2, step * 0.75);
        // Positives: capCall (dawn), distrib (green), stacked upward
        const posCC = r.capCall * scale;
        const posD  = r.distrib * scale;
        // Negatives: capDraw (red), contrib (gold), stacked downward
        const negCD = Math.abs(r.capDraw) * scale;
        const negC  = Math.abs(r.contrib) * scale;
        return React.createElement("g", { key: i },
          posCC > 0 && React.createElement("rect", { x, y: y0 - posCC, width: w, height: posCC, fill: "#2F3E55" }),
          posD  > 0 && React.createElement("rect", { x, y: y0 - posCC - posD, width: w, height: posD, fill: "#058F8A" }),
          negCD > 0 && React.createElement("rect", { x, y: y0, width: w, height: negCD, fill: "#AF2323" }),
          negC  > 0 && React.createElement("rect", { x, y: y0 + negCD, width: w, height: negC, fill: "#B56624" })
        );
      })
    );
  }

  return React.createElement("aside", { className: "uv-inspector" },
    React.createElement("header", { className: "uv-insp-head" },
      React.createElement("div", null,
        React.createElement("div", { className: "drawer-eyebrow" }, vehicle.kind === "cash-pool" ? "Liquidity pool" : vehicle.kind === "master-fund" ? "Master vehicle" : "Sub-vehicle"),
        React.createElement("h3", { className: "uv-insp-title" }, vehicle.name + (vehicle.desc ? ` · ${vehicle.desc}` : ""))
      ),
      React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
    ),

    React.createElement("div", { className: "uv-insp-kpis" },
      React.createElement("div", { className: "uv-insp-kpi" },
        React.createElement("div", { className: "uv-insp-kpi-lbl" }, "Total value"),
        React.createElement("div", { className: "uv-insp-kpi-val num" }, `$${Math.round(totalValue)}M`)
      ),
      React.createElement("div", { className: "uv-insp-kpi" },
        React.createElement("div", { className: "uv-insp-kpi-lbl" }, "Cash on hand"),
        React.createElement("div", { className: "uv-insp-kpi-val num" }, `$${Math.round(cashNow)}M`)
      ),
      React.createElement("div", { className: "uv-insp-kpi" },
        React.createElement("div", { className: "uv-insp-kpi-lbl" }, "Direct assets"),
        React.createElement("div", { className: "uv-insp-kpi-val num" }, directAssets.length)
      ),
      React.createElement("div", { className: "uv-insp-kpi" },
        React.createElement("div", { className: "uv-insp-kpi-lbl" }, "Look-through"),
        React.createElement("div", { className: "uv-insp-kpi-val num" }, allAssets.length)
      )
    ),

    // Tab bar inside inspector
    React.createElement("div", { className: "uv-insp-tabs" },
      ["overview", "cashflows", "strategy", "params"].map(t =>
        React.createElement("button", {
          key: t, className: `uv-insp-tab${tab === t ? " is-active" : ""}`,
          onClick: () => setTab(t)
        }, t === "overview" ? "Overview" : t === "cashflows" ? "Cash flows" : t === "strategy" ? "Strategy" : "MC params")
      )
    ),

    React.createElement("div", { className: "uv-insp-body" },
      tab === "overview" && React.createElement(PI.Fragment, null,
        React.createElement("div", { className: "eyebrow", style: { margin: "4px 0 8px" } }, "Portfolio value · 36 months"),
        sparkline("value", "#2F3E55", 80),
        React.createElement("div", { className: "eyebrow", style: { margin: "18px 0 8px" } }, "Cash balance · 36 months"),
        sparkline("cash", "#058F8A", 60),
        React.createElement("div", { className: "eyebrow", style: { margin: "18px 0 8px" } }, "Asset mix (direct + look-through)"),
        React.createElement(PI.AssetTypeChips, {
          byType: allAssets.reduce((m, f) => { m[f.assetType] = (m[f.assetType] || 0) + 1; return m; }, {})
        }),
        React.createElement("div", { style: { marginTop: 18 } },
          React.createElement(PI.Btn, { kind: "ghost", size: "sm",
            icon: React.createElement(PI.Icon.Table, { size: 13 }),
            onClick: onSwitchToTable }, "View all investments in table")
        )
      ),

      tab === "cashflows" && React.createElement(PI.Fragment, null,
        React.createElement("div", { className: "uv-cf-legend" },
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: "#2F3E55" } }), "Capital call (in from parent)"),
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: "#058F8A" } }), "Distribution (in from child)"),
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: "#AF2323" } }), "Capital drawdown (out to parent)"),
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: "#B56624" } }), "Contribution (out to child)")
        ),
        cashflowBars(160),
        React.createElement("div", { className: "uv-cf-totals" },
          React.createElement("div", null,
            React.createElement("div", { className: "uv-cf-lbl" }, "Capital calls (36m)"),
            React.createElement("div", { className: "uv-cf-val num pos" }, `+$${totals.capCall.toFixed(1)}M`)),
          React.createElement("div", null,
            React.createElement("div", { className: "uv-cf-lbl" }, "Capital drawdowns"),
            React.createElement("div", { className: "uv-cf-val num neg" }, `-$${Math.abs(totals.capDraw).toFixed(1)}M`)),
          React.createElement("div", null,
            React.createElement("div", { className: "uv-cf-lbl" }, "Distributions in"),
            React.createElement("div", { className: "uv-cf-val num pos" }, `+$${totals.distrib.toFixed(1)}M`)),
          React.createElement("div", null,
            React.createElement("div", { className: "uv-cf-lbl" }, "Contributions out"),
            React.createElement("div", { className: "uv-cf-val num neg" }, `-$${Math.abs(totals.contrib).toFixed(1)}M`))
        ),
        React.createElement("div", { className: "eyebrow", style: { margin: "18px 0 8px" } }, "Asset mix filter (recompute aggregates on the fly)"),
        React.createElement("div", { className: "uv-mixfilter" },
          PI_DATA.ASSET_TYPES.map(a => {
            const on = assetMix.has(a.id);
            return React.createElement("label", {
              key: a.id, className: `uv-mix-chip${on ? " is-on" : ""}`,
              style: { "--c": a.color }
            },
              React.createElement("input", {
                type: "checkbox", className: "chk", checked: on,
                onChange: () => {
                  const n = new Set(assetMix);
                  on ? n.delete(a.id) : n.add(a.id);
                  setAssetMix(n);
                }
              }),
              React.createElement("span", { className: "uv-mix-chip-dot" }),
              React.createElement("span", null, a.label)
            );
          })
        )
      ),

      tab === "strategy" && React.createElement(PI.Fragment, null,
        React.createElement("div", { className: "uv-strat-intro" },
          "Set the capital allocation & rebalancing strategy for this vehicle. The tool uses this to decide where to pull cash from when children issue capital calls, and where to deploy excess cash."
        ),
        React.createElement("div", { className: "uv-strat-presets" },
          PI_DATA.STRATEGY_PRESETS.map(p => React.createElement("button", {
            key: p.id,
            className: `uv-strat-preset${strategy === p.id ? " is-active" : ""}`,
            onClick: () => setStrategy(p.id)
          },
            React.createElement("div", { className: "uv-strat-preset-name" }, p.name),
            React.createElement("div", { className: "uv-strat-preset-desc" }, p.desc)
          ))
        ),
        preset?.tgt && React.createElement("div", { style: { marginTop: 18 } },
          React.createElement("div", { className: "eyebrow", style: { marginBottom: 8 } }, "Target allocation"),
          React.createElement("div", { className: "uv-strat-bars" },
            Object.entries(preset.tgt).map(([tid, w]) => {
              const meta = PI_DATA.assetTypeMeta(tid);
              return React.createElement("div", { key: tid, className: "uv-strat-row" },
                React.createElement("div", { className: "uv-strat-row-lbl" },
                  React.createElement("span", { className: "dot", style: { background: meta.color } }),
                  React.createElement("span", null, meta.label)
                ),
                React.createElement("div", { className: "uv-strat-row-bar" },
                  React.createElement("div", { className: "uv-strat-row-fill", style: { width: `${w*100}%`, background: meta.color } })
                ),
                React.createElement("div", { className: "uv-strat-row-pct num" }, `${Math.round(w*100)}%`)
              );
            })
          )
        ),
        preset?.id === "auto" && React.createElement("div", { className: "uv-strat-auto" },
          React.createElement("div", { className: "uv-strat-auto-title" },
            React.createElement(PI.Icon.Sparkles, { size: 14 }),
            React.createElement("span", null, "Auto-optimize objective")
          ),
          React.createElement("select", { className: "select" },
            React.createElement("option", null, "Keep ≥20% cash at all times"),
            React.createElement("option", null, "Cover P5 liquidity risk (worst-case contributions)"),
            React.createElement("option", null, "Cover P10 liquidity + maximize TVPI"),
            React.createElement("option", null, "Maximize Sharpe ratio")
          ),
          React.createElement("div", { style: { marginTop: 10, color: "var(--black-60)", fontSize: 12 } },
            "The optimizer runs a Monte-Carlo search over the feasible allocation space and returns the best-on-expectation mix."
          )
        ),
        React.createElement("div", { className: "uv-strat-ondemand" },
          React.createElement("div", { className: "eyebrow", style: { marginBottom: 8 } }, "On-the-fly changes & checkpoints"),
          React.createElement("p", { style: { fontSize: 12, color: "var(--black-60)", marginBottom: 10 } },
            "When running a simulation, you can branch the strategy here without re-running. Each checkpoint saves the allocation used from that month forward."),
          React.createElement("ul", { className: "uv-cp-list" },
            checkpoints.map(cp => React.createElement("li", { key: cp.id, className: "uv-cp-item" + (cp.active ? " is-active" : "") },
              React.createElement("span", { className: "uv-cp-dot" }),
              React.createElement("div", { style: { flex: 1 } },
                React.createElement("div", { className: "uv-cp-name" }, cp.name),
                React.createElement("div", { className: "uv-cp-when" }, "From " + cp.when)
              ),
              React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.Trash, { size: 12 }),
                onClick: () => setCheckpoints(cs => cs.filter(c => c.id !== cp.id)) })
            ))
          ),
          React.createElement(PI.Btn, {
            kind: "ghost", size: "sm",
            icon: React.createElement(PI.Icon.Plus, { size: 13 }),
            onClick: () => {
              const id = "cp-" + Date.now();
              setCheckpoints(cs => [...cs, {
                id, name: `Branch · ${preset?.name || "custom"}`,
                when: new Date().toISOString().slice(0,10), active: false
              }]);
              onToast && onToast("Checkpoint saved", "ok");
            }
          }, "Save as checkpoint")
        )
      ),

      tab === "params" && React.createElement(PI.Fragment, null,
        React.createElement("div", { className: "uv-params-intro" },
          "Monte-Carlo model parameters used to project this vehicle's assets. ",
          React.createElement("strong", null, "Cepres"),
          " values come from our calibration engine; override them below to use your own inputs."
        ),
        PI_DATA.MC_PARAMS.map(group => {
          const meta = PI_DATA.assetTypeMeta(group.assetType);
          return React.createElement("div", { key: group.assetType, className: "uv-params-block" },
            React.createElement("div", { className: "uv-params-head" },
              React.createElement("span", { className: "dot", style: { background: meta.color } }),
              React.createElement("span", { className: "uv-params-label" }, meta.label),
              React.createElement("span", { className: "uv-params-model" }, group.model)
            ),
            React.createElement("table", { className: "uv-params-tbl" },
              React.createElement("thead", null, React.createElement("tr", null,
                React.createElement("th", null, "Parameter"),
                React.createElement("th", { className: "num" }, "Cepres default"),
                React.createElement("th", { className: "num" }, "Your override"),
              )),
              React.createElement("tbody", null,
                group.params.map(p => React.createElement("tr", { key: p.key },
                  React.createElement("td", null, p.label),
                  React.createElement("td", { className: "num" },
                    p.unit === "%" ? (p.cepres * 100).toFixed(2) + "%" :
                    p.unit === "×" ? p.cepres.toFixed(2) + "×" :
                    p.unit === "y" ? p.cepres.toFixed(1) + "y" :
                    p.cepres.toFixed(3)
                  ),
                  React.createElement("td", { className: "num" },
                    React.createElement("input", {
                      className: "input uv-params-input", type: "number",
                      step: 0.001, placeholder: "—",
                      onChange: () => {}
                    })
                  )
                ))
              )
            )
          );
        })
      )
    )
  );
}

function UniverseView({ funds, inspectedVehicleId, onInspect, onClose, onSwitchToTable, onToast }) {
  return React.createElement("div", { className: `uv-wrap${inspectedVehicleId ? " has-inspector" : ""}` },
    React.createElement(UniverseBubbles, {
      funds, onInspect, inspectedVehicleId, onToast
    }),
    inspectedVehicleId && React.createElement(VehicleInspector, {
      vehicleId: inspectedVehicleId, funds, onClose, onToast, onSwitchToTable
    })
  );
}

window.PI.UniverseView = UniverseView;
window.PI.UniverseBubbles = UniverseBubbles;
window.PI.VehicleInspector = VehicleInspector;
