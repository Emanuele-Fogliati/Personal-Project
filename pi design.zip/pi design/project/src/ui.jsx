/* Shared icons (Lucide-inspired) and primitive components — exported via window */
const { useState, useEffect, useRef, useMemo, useCallback, Fragment } = React;

// --------------- Icons ---------------
const mkIcon = (d, vb="0 0 24 24") => ({size=16, stroke=1.75, className="", style={}}) =>
  React.createElement("svg", {
    width: size, height: size, viewBox: vb, fill: "none",
    stroke: "currentColor", strokeWidth: stroke, strokeLinecap: "round", strokeLinejoin: "round",
    className, style, "aria-hidden": true
  }, ...(Array.isArray(d) ? d : [d]).map((p, i) =>
    typeof p === "string"
      ? React.createElement("path", { key: i, d: p })
      : React.createElement(p.tag || "path", { key: i, ...p })
  ));

const Icon = {
  Folder:   mkIcon("M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"),
  Upload:   mkIcon(["M12 16V4", "M6 10l6-6 6 6", "M4 20h16"]),
  Download: mkIcon(["M12 4v12", "M6 10l6 6 6-6", "M4 20h16"]),
  FileSpreadsheet: mkIcon(["M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z", "M14 2v6h6", "M8 13h8", "M8 17h8", "M8 9h2"]),
  Plus:     mkIcon(["M12 5v14", "M5 12h14"]),
  Search:   mkIcon(["M21 21l-4.3-4.3", {tag:"circle", cx:11, cy:11, r:7}]),
  Filter:   mkIcon("M3 5h18l-7 8v6l-4 2v-8L3 5z"),
  X:        mkIcon(["M18 6L6 18", "M6 6l12 12"]),
  ChevronDown: mkIcon("M6 9l6 6 6-6"),
  ChevronRight: mkIcon("M9 6l6 6-6 6"),
  ChevronLeft: mkIcon("M15 6l-6 6 6 6"),
  ArrowRight: mkIcon(["M5 12h14", "M13 6l6 6-6 6"]),
  ArrowUpRight: mkIcon(["M7 17L17 7", "M8 7h9v9"]),
  ArrowUp:  mkIcon(["M12 19V5", "M6 11l6-6 6 6"]),
  ArrowDown: mkIcon(["M12 5v14", "M6 13l6 6 6-6"]),
  Edit:     mkIcon(["M12 20h9", "M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5z"]),
  Trash:    mkIcon(["M3 6h18", "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", "M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6", "M10 11v6", "M14 11v6"]),
  Share:    mkIcon([{tag:"circle",cx:18,cy:5,r:3}, {tag:"circle",cx:6,cy:12,r:3}, {tag:"circle",cx:18,cy:19,r:3}, "M8.6 13.5l6.8 4", "M15.4 6.5l-6.8 4"]),
  Check:    mkIcon("M5 12l5 5L20 7"),
  PieChart: mkIcon(["M21.21 15.89A10 10 0 1 1 8 2.83", "M22 12A10 10 0 0 0 12 2v10z"]),
  BarChart: mkIcon(["M3 3v18h18", "M7 14h2v4H7z", "M12 9h2v9h-2z", "M17 5h2v13h-2z"]),
  Layers:   mkIcon(["M12 2l10 6-10 6L2 8l10-6z", "M2 16l10 6 10-6", "M2 12l10 6 10-6"]),
  Play:     mkIcon("M6 4l14 8-14 8V4z"),
  Zap:      mkIcon("M13 2L3 14h8l-1 8 10-12h-8l1-8z"),
  Beaker:   mkIcon(["M6 2h12", "M7 2v6l-5 11a2 2 0 0 0 1.8 3h16.4a2 2 0 0 0 1.8-3L17 8V2", "M6 14h12"]),
  Settings: mkIcon([{tag:"circle",cx:12,cy:12,r:3}, "M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 0 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 0 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 0 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"]),
  Bell:     mkIcon(["M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9", "M13.7 21a2 2 0 0 1-3.4 0"]),
  Help:     mkIcon([{tag:"circle",cx:12,cy:12,r:10}, "M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3", "M12 17h.01"]),
  Sparkles: mkIcon(["M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z", "M19 14l.9 2.3 2.3.9-2.3.9-.9 2.3-.9-2.3-2.3-.9 2.3-.9z"]),
  Clock:    mkIcon([{tag:"circle",cx:12,cy:12,r:9}, "M12 7v5l3 2"]),
  Eye:      mkIcon(["M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z", {tag:"circle",cx:12,cy:12,r:3}]),
  Table:    mkIcon([{tag:"rect",x:3,y:3,width:18,height:18,rx:2}, "M3 9h18", "M3 15h18", "M9 3v18", "M15 3v18"]),
  MoreHoriz: mkIcon([{tag:"circle",cx:5,cy:12,r:1}, {tag:"circle",cx:12,cy:12,r:1}, {tag:"circle",cx:19,cy:12,r:1}]),
  Info:     mkIcon([{tag:"circle",cx:12,cy:12,r:10}, "M12 16v-4", "M12 8h.01"]),
  TrendingUp: mkIcon(["M3 17l6-6 4 4 8-8", "M14 7h7v7"]),
  Target:   mkIcon([{tag:"circle",cx:12,cy:12,r:10}, {tag:"circle",cx:12,cy:12,r:6}, {tag:"circle",cx:12,cy:12,r:2}]),
  PriceSeek: mkIcon([{tag:"circle",cx:10,cy:10,r:6}, "M20 20l-4.35-4.35", "M10 7v6", "M12 9h-3a1.2 1.2 0 0 0 0 2.4h2a1.2 1.2 0 0 1 0 2.4H8"]),
  Microscope: mkIcon([
    "M6 18h8",
    "M3 22h18",
    "M14 22a7 7 0 1 0 0-14h-1",
    "M9 14h2",
    "M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2z",
    "M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3"
  ]),
  Percent:  mkIcon([{tag:"line",x1:19,y1:5,x2:5,y2:19}, {tag:"circle",cx:6.5,cy:6.5,r:2.5}, {tag:"circle",cx:17.5,cy:17.5,r:2.5}]),
  Calendar: mkIcon([{tag:"rect",x:3,y:4,width:18,height:18,rx:2}, "M16 2v4", "M8 2v4", "M3 10h18"]),
  Copy:     mkIcon([{tag:"rect",x:9,y:9,width:13,height:13,rx:2}, "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"]),
  External: mkIcon(["M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", "M15 3h6v6", "M10 14L21 3"]),
  Save:     mkIcon(["M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z", "M17 21v-8H7v8", "M7 3v5h8"]),
  Users:    mkIcon(["M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2", {tag:"circle",cx:9,cy:7,r:4}, "M23 21v-2a4 4 0 0 0-3-3.87", "M16 3.13a4 4 0 0 1 0 7.75"]),
  Warning:  mkIcon(["M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z", "M12 9v4", "M12 17h.01"]),
};

// --------------- Format helpers ---------------
const fmt = {
  money(v, currency="USD") {
    if (v === null || v === undefined || isNaN(v)) return "—";
    const sign = v < 0 ? "-" : "";
    const abs = Math.abs(v);
    const symbol = { USD: "$", EUR: "€", GBP: "£" }[currency] || "$";
    if (abs >= 1000) return `${sign}${symbol}${(abs/1000).toFixed(2)}B`;
    return `${sign}${symbol}${abs.toFixed(1)}M`;
  },
  moneyPlain(v, currency="USD") {
    if (v === null || v === undefined || isNaN(v)) return "—";
    const sign = v < 0 ? "-" : "";
    const abs = Math.abs(v);
    const symbol = { USD: "$", EUR: "€", GBP: "£" }[currency] || "$";
    return `${sign}${symbol}${abs.toLocaleString(undefined, {minimumFractionDigits:1, maximumFractionDigits:1})}M`;
  },
  num(v, d=2) { if (v === null || v === undefined || isNaN(v)) return "—"; return (+v).toLocaleString(undefined, {minimumFractionDigits:d, maximumFractionDigits:d}); },
  pct(v, d=1) { if (v === null || v === undefined || isNaN(v)) return "—"; return (v*100).toFixed(d) + "%"; },
  mult(v) { if (v === null || v === undefined || isNaN(v)) return "—"; return (+v).toFixed(2) + "×"; },
  date(s) { return s || "—"; },
};

// --------------- Small components ---------------
function Btn({ kind="ghost", size, icon, children, onClick, type="button", disabled, title }) {
  const cls = `btn btn-${kind}${size ? ` btn-${size}` : ""}`;
  return React.createElement("button", { type, className: cls, onClick, disabled, title },
    icon, children && React.createElement("span", null, children));
}

function IconBtn({ icon, onClick, title, naked=false }) {
  return React.createElement("button", { type: "button", className: naked ? "btn-icon-naked" : "btn-icon", onClick, title }, icon);
}

function Field({ label, hint, error, required, children, wide }) {
  return React.createElement("div", { className: `field${wide ? " field-wide" : ""}` },
    label && React.createElement("label", { className: `label${required ? " field-req" : ""}` }, label),
    children,
    hint && !error && React.createElement("div", { className: "field-hint" }, hint),
    error && React.createElement("div", { className: "field-error" }, error)
  );
}

// Click-outside hook
function useClickOutside(onClose) {
  const ref = useRef();
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [onClose]);
  return ref;
}

// Dropdown
function Dropdown({ value, options, onChange, placeholder="Select…", icon, minWidth }) {
  const [open, setOpen] = useState(false);
  const ref = useClickOutside(() => setOpen(false));
  const selected = options.find(o => (o.value ?? o) === value);
  const label = selected ? (selected.label ?? selected) : placeholder;
  return React.createElement("div", { ref, className: "dd", style: { minWidth }, onClick: () => setOpen(o => !o) },
    icon, React.createElement("span", null, label),
    React.createElement(Icon.ChevronDown, { size: 14, className: "dd-caret" }),
    open && React.createElement("div", { className: "dd-menu", onClick: e => e.stopPropagation() },
      options.map(o => {
        const v = o.value ?? o; const l = o.label ?? o;
        return React.createElement("div", {
          key: v, className: `dd-item${v === value ? " is-active" : ""}`,
          onClick: () => { onChange(v); setOpen(false); }
        }, React.createElement("span", {style:{flex:1}}, l), v === value && React.createElement(Icon.Check, { size: 14, className: "tick" }));
      })
    )
  );
}

// Toast
function Toast({ kind="ok", children, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2400); return () => clearTimeout(t); }, [onDone]);
  return React.createElement("div", { className: `toast toast-${kind}` },
    kind === "ok" && React.createElement(Icon.Check, { size: 16 }),
    children);
}

// Scrim + dialog wrapper that prevents bg scroll
function Portal({ children }) {
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, []);
  return children;
}

window.PI = Object.assign(window.PI || {}, {
  useState, useEffect, useRef, useMemo, useCallback, Fragment,
  Icon, fmt,
  Btn, IconBtn, Field, Dropdown, Toast, Portal,
  useClickOutside,
});
