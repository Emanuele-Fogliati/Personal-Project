/* Investments table — sticky cols, horizontal scroll, column-header sort & filter */

function InvestmentsTable({ funds, selectedVehicle, onOpenCashflows, onEdit, onAdd, onDelete, onGoalSeek, density="comfy" }) {
  const [sort, setSort] = PI.useState({ key: "interimTvpi", dir: "desc" });
  const [search, setSearch] = PI.useState("");
  const [assetFilter, setAssetFilter] = PI.useState("all");
  const [statusFilter, setStatusFilter] = PI.useState("all");
  const [stageFilter, setStageFilter] = PI.useState("all");
  const [regionFilter, setRegionFilter] = PI.useState("all");
  const [vehicleFilter, setVehicleFilter] = PI.useState("all");
  const [ccyFilter, setCcyFilter] = PI.useState("all");
  const [cfFilter, setCfFilter] = PI.useState("all");

  // derive filter options from current (pre-filter) fund set
  const uniq = (key) => [...new Set(funds.map(f => f[key]).filter(v => v !== undefined && v !== null && v !== ""))].sort();
  const stageOpts   = uniq("stage");
  const regionOpts  = uniq("geography");
  const vehicleOpts = uniq("vehicle");
  const ccyOpts     = uniq("currency");
  const cfOpts      = uniq("cfPattern");

  const rows = PI.useMemo(() => {
    let out = funds;
    if (selectedVehicle && selectedVehicle !== "All vehicles") out = out.filter(f => f.vehicle === selectedVehicle);
    if (vehicleFilter !== "all") out = out.filter(f => f.vehicle === vehicleFilter);
    if (assetFilter !== "all")   out = out.filter(f => f.assetType === assetFilter);
    if (statusFilter !== "all")  out = out.filter(f => f.realization === statusFilter);
    if (stageFilter !== "all")   out = out.filter(f => f.stage === stageFilter);
    if (regionFilter !== "all")  out = out.filter(f => f.geography === regionFilter);
    if (ccyFilter !== "all")     out = out.filter(f => f.currency === ccyFilter);
    if (cfFilter !== "all")      out = out.filter(f => f.cfPattern === cfFilter);
    if (search) {
      const q = search.toLowerCase();
      out = out.filter(f => f.name.toLowerCase().includes(q) || f.id.toLowerCase().includes(q) || (f.gp||"").toLowerCase().includes(q));
    }
    out = [...out].sort((a, b) => {
      const av = a[sort.key], bv = b[sort.key];
      if (av === bv) return 0;
      if (typeof av === "string") return sort.dir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      return sort.dir === "asc" ? av - bv : bv - av;
    });
    return out;
  }, [funds, selectedVehicle, search, sort, assetFilter, statusFilter, stageFilter, regionFilter, vehicleFilter, ccyFilter, cfFilter]);

  const hasFilter = assetFilter !== "all" || statusFilter !== "all" || stageFilter !== "all"
                 || regionFilter !== "all" || vehicleFilter !== "all"
                 || ccyFilter !== "all" || cfFilter !== "all";
  function clearAll() {
    setAssetFilter("all"); setStatusFilter("all"); setStageFilter("all");
    setRegionFilter("all"); setVehicleFilter("all");
    setCcyFilter("all"); setCfFilter("all");
  }

  function toggleSort(key) {
    setSort(s => s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "desc" });
  }

  // Sortable header: label + arrow. Suppresses sort click on any nested element
  // that already handled the event (the column-filter button stops propagation).
  function sortableTh(key, label, opts={}) {
    const { num=false, stick, width } = opts;
    const cls = [num ? "num" : "", "sortable", stick ? `stick-${stick}` : ""].filter(Boolean).join(" ");
    return React.createElement("th", {
      key, className: cls, style: width ? { minWidth: width } : undefined,
      onClick: () => toggleSort(key)
    },
      React.createElement("span", { className: "th-inner" },
        React.createElement("span", null, label),
        sort.key === key && React.createElement(
          sort.dir === "asc" ? PI.Icon.ArrowUp : PI.Icon.ArrowDown,
          { size: 11, className: "hicon" }
        )
      )
    );
  }

  // Header that hosts a filter dropdown. No sorting, no row click.
  function filterTh(key, value, setValue, label, options, opts={}) {
    const { num=false, width } = opts;
    return React.createElement("th", {
      key, className: num ? "num" : "",
      style: width ? { minWidth: width } : undefined
    },
      React.createElement(PI.ColumnFilter, {
        label,
        value,
        options: [{ value: "all", label: `All ${label.toLowerCase()}` }, ...options.map(o => ({ value: o, label: String(o) }))],
        onChange: setValue
      })
    );
  }

  // Status tag with realization badge
  const realizationTag = (id) => {
    const map = { active: "tag-green", realized: "tag-outline", future: "tag-gold" };
    const label = (id || "active").charAt(0).toUpperCase() + (id || "active").slice(1);
    return React.createElement("span", { className: `tag ${map[id] || "tag-outline"}` }, label);
  };

  // Asset-type cell with colored dot + label
  const assetTypeCell = (id) => {
    const meta = PI_DATA.assetTypeMeta(id);
    return React.createElement("span", { className: "cell-atype" },
      React.createElement("span", { className: "cell-atype-dot", style: { background: meta.color } }),
      React.createElement("span", null, meta.label)
    );
  };

  const assetTypeOptions = PI_DATA.ASSET_TYPES.map(a => ({ value: a.id, label: a.label }));
  const statusOptions = PI_DATA.REALIZATIONS.map(r => ({ value: r.id, label: r.label }));

  return React.createElement("div", { className: "table-wrap" },
    React.createElement("div", { className: "tbl-toolbar" },
      React.createElement("div", { className: "tbl-toolbar-left" },
        React.createElement("div", { className: "tbl-search" },
          React.createElement(PI.Icon.Search, { size: 13 }),
          React.createElement("input", { placeholder: "Search investments, IDs, GPs", value: search, onChange: e => setSearch(e.target.value) })
        ),
        hasFilter && React.createElement("button", { className: "btn-chip-clear", onClick: clearAll }, "Clear filters"),
        React.createElement("span", { className: "tbl-count" }, `${rows.length} of ${funds.length} investments`)
      ),
      React.createElement("div", { className: "tbl-toolbar-right" },
        React.createElement(PI.Btn, { kind: "ghost", size: "sm", icon: React.createElement(PI.Icon.Table, {size:13}) }, "Columns"),
        React.createElement(PI.Btn, { kind: "ghost", size: "sm", icon: React.createElement(PI.Icon.Download, {size:13}) }, "Export"),
        React.createElement(PI.Btn, {
          kind: "primary", size: "sm",
          icon: React.createElement(PI.Icon.Plus, {size:14}),
          onClick: onAdd
        }, "Add investment")
      )
    ),
    React.createElement("div", { className: "tbl-scroll" },
      React.createElement("table", { className: "investments" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            sortableTh("name", "Investment", { stick: "1 stick-name" }),
            sortableTh("id", "Investment ID", { stick: "1 stick-id" }),
            React.createElement("th", { key: "assetType" },
              React.createElement(PI.ColumnFilter, {
                label: "Asset type",
                value: assetFilter,
                options: [{ value: "all", label: "All asset types" }, ...assetTypeOptions],
                onChange: setAssetFilter
              })
            ),
            filterTh("vehicle", vehicleFilter, setVehicleFilter, "Vehicle", vehicleOpts),
            sortableTh("vintage", "Vintage", { num: true }),
            filterTh("stage", stageFilter, setStageFilter, "Stage", stageOpts),
            filterTh("geography", regionFilter, setRegionFilter, "Region", regionOpts),
            React.createElement("th", { key: "status" },
              React.createElement(PI.ColumnFilter, {
                label: "Realization",
                value: statusFilter,
                options: [{ value: "all", label: "All statuses" }, ...statusOptions],
                onChange: setStatusFilter
              })
            ),
            filterTh("currency", ccyFilter, setCcyFilter, "CCY", ccyOpts),
            sortableTh("committed", "Committed", { num: true }),
            sortableTh("contributed", "Contributed (NAV)", { num: true }),
            sortableTh("distributed", "Distributed (NAV)", { num: true }),
            sortableTh("nav", "NAV", { num: true }),
            sortableTh("openCommitment", "Open commit", { num: true }),
            sortableTh("interimTvpi", "Interim TVPI", { num: true }),
            sortableTh("cepresTvpi", "CEPRES tgt TVPI", { num: true }),
            sortableTh("cepresTvpiStd", "CEPRES TVPI σ", { num: true }),
            sortableTh("clientTvpi", "Client tgt TVPI", { num: true }),
            sortableTh("clientTvpiStd", "Client TVPI σ", { num: true }),
            sortableTh("tvpiMin", "TVPI min", { num: true }),
            sortableTh("tvpiMax", "TVPI max", { num: true }),
            sortableTh("pod", "P(default)", { num: true }),
            filterTh("cfPattern", cfFilter, setCfFilter, "CF pattern", cfOpts),
            React.createElement("th", { key: "cf" }, "Cash flows"),
            sortableTh("purchaseDate", "Purchase date"),
            sortableTh("purchasePrice", "Purchase price", { num: true }),
            sortableTh("salesDate", "Sales date"),
            sortableTh("salesPrice", "Sales price", { num: true }),
            sortableTh("paidInBefore", "Paid-in before purchase", { num: true }),
            sortableTh("distributedBefore", "Dist. before purchase", { num: true }),
            sortableTh("dateInitialCf", "Initial CF date"),
            sortableTh("dateFirstProj", "First projected CF"),
            sortableTh("dateNav", "Date of NAV"),
            sortableTh("remainingContribDate", "Remaining contrib. date"),
            sortableTh("exitDate", "Exit date"),
            sortableTh("fundManager", "Fund manager"),
            sortableTh("investmentManager", "Investment mgr"),
            sortableTh("clientId", "Client inv. ID"),
            React.createElement("th", { key: "comment" }, "Comment"),
            React.createElement("th", { key: "actions", className: "stick-r" }, "")
          )
        ),
        React.createElement("tbody", null,
          rows.map(f => {
            return React.createElement("tr", { key: f.id },
              React.createElement("td", { className: "stick-1 stick-name" },
                React.createElement("div", { className: "inv-name" }, f.name),
                React.createElement("div", { className: "inv-gp" }, f.gp)
              ),
              React.createElement("td", { className: "stick-1 stick-id" },
                React.createElement("span", { className: "inv-id" }, f.id)
              ),
              React.createElement("td", null, assetTypeCell(f.assetType)),
              React.createElement("td", null, f.vehicle),
              React.createElement("td", { className: "num" }, f.vintage),
              React.createElement("td", null, f.stage && React.createElement("span", { className: "tag tag-outline" }, f.stage)),
              React.createElement("td", null, f.geography),
              React.createElement("td", null, realizationTag(f.realization)),
              React.createElement("td", null, f.currency),
              React.createElement("td", { className: "num" }, PI.fmt.moneyPlain(f.committed, f.currency)),
              React.createElement("td", { className: "num" }, PI.fmt.moneyPlain(f.contributed, f.currency)),
              React.createElement("td", { className: "num" }, PI.fmt.moneyPlain(f.distributed, f.currency)),
              React.createElement("td", { className: "num" }, PI.fmt.moneyPlain(f.nav, f.currency)),
              React.createElement("td", { className: "num" }, PI.fmt.moneyPlain(f.openCommitment, f.currency)),
              React.createElement("td", { className: "num", style: { fontWeight: 500 } }, PI.fmt.mult(f.interimTvpi)),
              React.createElement("td", { className: "num" }, PI.fmt.mult(f.cepresTvpi)),
              React.createElement("td", { className: "num" }, PI.fmt.num(f.cepresTvpiStd, 2)),
              React.createElement("td", { className: "num" }, PI.fmt.mult(f.clientTvpi)),
              React.createElement("td", { className: "num" }, PI.fmt.num(f.clientTvpiStd, 2)),
              React.createElement("td", { className: "num" }, PI.fmt.mult(f.tvpiMin)),
              React.createElement("td", { className: "num" }, PI.fmt.mult(f.tvpiMax)),
              React.createElement("td", { className: "num" }, PI.fmt.pct(f.pod, 1)),
              React.createElement("td", null, f.cfPattern),
              React.createElement("td", null,
                React.createElement("button", {
                  className: "cf-link", onClick: () => onOpenCashflows(f)
                }, "View cash flows",
                  React.createElement(PI.Icon.External, { size: 11 })
                )
              ),
              React.createElement("td", null, f.purchaseDate),
              React.createElement("td", { className: "num cell-with-action" },
                PI.fmt.moneyPlain(f.purchasePrice, f.currency),
                React.createElement("button", { className: "goal-seek-btn", title: "Goal-seek purchase price",
                  onClick: (e) => { e.stopPropagation(); onGoalSeek && onGoalSeek(f, "purchase"); } },
                  React.createElement(PI.Icon.Microscope, { size: 16 }))
              ),
              React.createElement("td", null, f.salesDate || React.createElement("span", { style: { color: "var(--black-40)" } }, "—")),
              React.createElement("td", { className: "num cell-with-action" },
                f.salesPrice ? PI.fmt.moneyPlain(f.salesPrice, f.currency) : React.createElement("span", { style: { color: "var(--black-40)" } }, "—"),
                React.createElement("button", { className: "goal-seek-btn", title: "Goal-seek sales price",
                  onClick: (e) => { e.stopPropagation(); onGoalSeek && onGoalSeek(f, "sales"); } },
                  React.createElement(PI.Icon.Microscope, { size: 16 }))
              ),
              React.createElement("td", { className: "num" }, PI.fmt.moneyPlain(f.paidInBefore, f.currency)),
              React.createElement("td", { className: "num" }, PI.fmt.moneyPlain(f.distributedBefore, f.currency)),
              React.createElement("td", null, f.dateInitialCf),
              React.createElement("td", null, f.dateFirstProj),
              React.createElement("td", null, f.dateNav),
              React.createElement("td", null, f.remainingContribDate),
              React.createElement("td", null, f.exitDate),
              React.createElement("td", null, f.fundManager),
              React.createElement("td", null, f.investmentManager),
              React.createElement("td", null, React.createElement("span", { className: "inv-id" }, f.clientId)),
              React.createElement("td", { style: { maxWidth: 220, overflow: "hidden", textOverflow: "ellipsis" } }, f.comment),
              React.createElement("td", { className: "stick-r" },
                React.createElement("div", { className: "row-actions" },
                  React.createElement("button", { title: "Edit", onClick: () => onEdit(f) },
                    React.createElement(PI.Icon.Edit, { size: 14 })),
                  React.createElement("button", { title: "Delete", className: "is-danger",
                    onClick: () => onDelete(f) },
                    React.createElement(PI.Icon.Trash, { size: 14 })),
                )
              )
            );
          })
        )
      )
    )
  );
}

window.PI.InvestmentsTable = InvestmentsTable;
