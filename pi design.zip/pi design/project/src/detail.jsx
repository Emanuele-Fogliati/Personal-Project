/* Portfolio Detail page */

// Split-button: primary click runs immediate forecast with current stress selection;
// chevron opens a small popover where user toggles stress tests, then clicks Run.
function ImmediateForecastButton({ onRun, size, label }) {
  const [open, setOpen] = PI.useState(false);
  const [stressIds, setStressIds] = PI.useState([]);
  const ref = PI.useClickOutside(() => setOpen(false));
  const stresses = PI_DATA.STRESS_TESTS;
  const selectedLabels = stressIds
    .map(id => stresses.find(s => s.id === id)?.name)
    .filter(Boolean);
  const btnSize = size || "md";

  return React.createElement("div", { ref, className: "split-btn" },
    React.createElement("button", {
      className: `btn btn-ghost btn-split-main${btnSize === "sm" ? " btn-sm" : ""}`,
      onClick: () => onRun(stressIds)
    },
      React.createElement(PI.Icon.Zap, { size: btnSize === "sm" ? 12 : 13 }),
      React.createElement("span", null, label || "Immediate forecast"),
      selectedLabels.length > 0 && React.createElement("span", { className: "split-btn-badge" },
        selectedLabels.length === 1 ? selectedLabels[0] : `${selectedLabels.length} stresses`
      )
    ),
    React.createElement("button", {
      className: `btn btn-ghost btn-split-caret${btnSize === "sm" ? " btn-sm" : ""}${open ? " is-open" : ""}`,
      onClick: () => setOpen(o => !o),
      title: "Configure stress tests"
    }, React.createElement(PI.Icon.ChevronDown, { size: 12 })),
    open && React.createElement("div", { className: "split-btn-menu" },
      React.createElement("div", { className: "split-btn-menu-head" },
        React.createElement("div", { className: "eyebrow" }, "Stress tests"),
        stressIds.length > 0 && React.createElement("button", {
          className: "split-btn-clear",
          onClick: () => setStressIds([])
        }, "Clear")
      ),
      React.createElement("div", { className: "split-btn-menu-sub" },
        "Optional — layer any of these scenarios on top of the base forecast."),
      React.createElement("div", { className: "split-btn-list" },
        stresses.map(st => {
          const on = stressIds.includes(st.id);
          return React.createElement("label", {
            key: st.id,
            className: `split-btn-item${on ? " is-on" : ""}`
          },
            React.createElement("input", {
              type: "checkbox",
              className: "chk",
              checked: on,
              onChange: () => setStressIds(on
                ? stressIds.filter(x => x !== st.id)
                : [...stressIds, st.id])
            }),
            React.createElement("div", null,
              React.createElement("div", { className: "split-btn-item-name" }, st.name),
              React.createElement("div", { className: "split-btn-item-desc" }, st.desc)
            )
          );
        })
      ),
      React.createElement("div", { className: "split-btn-menu-foot" },
        React.createElement(PI.Btn, {
          kind: "primary", size: "sm",
          icon: React.createElement(PI.Icon.Zap, { size: 12 }),
          onClick: () => { setOpen(false); onRun(stressIds); }
        }, "Run immediate forecast")
      )
    )
  );
}

function PortfolioDetail({ portfolio, funds, onBack, onStartForecast, onImmediateForecast, onImmediateForecastRun, onToast, onShowModal, setFunds }) {
  const [mode, setMode] = PI.useState("count");
  const [vehicle, setVehicle] = PI.useState("All vehicles");
  const [view, setView] = PI.useState("table");   // table | universe | liquidity
  const [inspectedVehicleId, setInspectedVehicleId] = PI.useState(null);
  const [name, setName] = PI.useState(portfolio.name);
  // Asset-type filter — set of disabled types. Empty = all visible.
  // Clicking a chip toggles that type off; clicking again re-enables.
  const [disabledTypes, setDisabledTypes] = PI.useState(() => new Set());

  const vehicleFunds = funds.filter(f => {
    if (vehicle !== "All vehicles" && f.vehicle !== vehicle) return false;
    return true;
  });
  // visibleFunds drives the table + downstream charts; respects asset-type chips.
  const visibleFunds = vehicleFunds.filter(f => !disabledTypes.has(f.assetType));

  // KPI totals reflect the *visible* selection — both vehicle filter AND chip
  // toggles. The user wants the headline numbers to respond live as they slice.
  const totals = visibleFunds.reduce((s, f) => ({
    contributed: s.contributed + f.contributed,
    distributed: s.distributed + f.distributed,
    nav: s.nav + f.nav,
    openCommitment: s.openCommitment + (f.openCommitment || 0),
  }), { contributed: 0, distributed: 0, nav: 0, openCommitment: 0 });
  const totalValue = totals.distributed + totals.nav;

  const vehicleOpts = ["All vehicles", ...PI_DATA.VEHICLES];

  // Chip counts always show the full vehicle universe, so the user can see what
  // they're filtering out (greyed) and turn it back on.
  const byType = vehicleFunds.reduce((m, f) => { m[f.assetType] = (m[f.assetType] || 0) + 1; return m; }, {});

  const toggleType = (tid) => setDisabledTypes(prev => {
    const next = new Set(prev);
    if (next.has(tid)) next.delete(tid); else next.add(tid);
    return next;
  });

  const metaKpi = (lbl, val) => React.createElement("span", { className: "pd-meta-kpi" },
    React.createElement("span", { className: "pd-meta-kpi-lbl" }, lbl),
    React.createElement("span", { className: "pd-meta-kpi-val" }, val)
  );

  return React.createElement("div", { className: "main-inner pd-main", "data-screen-label": "02 Portfolio Detail" },
    // ========== Page header ==========
    // Layered: crumb → title row (with primary actions) → KPI strip → view bar
    // — gives the title room to breathe and groups inputs vs. actions cleanly.
    React.createElement("div", { className: "pd-page-head" },
      React.createElement("div", { className: "page-crumb" },
        React.createElement("a", { href: "#", onClick: e => { e.preventDefault(); onBack(); } }, "Portfolios"),
        React.createElement(PI.Icon.ChevronRight, { size: 12, className: "sep" }),
        React.createElement("span", null, portfolio.name)
      ),
      React.createElement("div", { className: "pd-title-row" },
        React.createElement("h1", { className: "page-title pd-title" },
          React.createElement("span", {
            className: "page-title-editable", contentEditable: true, suppressContentEditableWarning: true,
            onBlur: e => setName(e.target.textContent),
          }, name),
          React.createElement("span", { className: "page-title-actions" },
            React.createElement(PI.IconBtn, {
              icon: React.createElement(PI.Icon.Share, {size:14}),
              title: "Share portfolio",
              onClick: () => onToast("Share link copied to clipboard", "ok")
            }),
            React.createElement(PI.IconBtn, {
              icon: React.createElement(PI.Icon.Download, {size:14}),
              title: "Download Excel",
              onClick: () => onToast("Downloading portfolio.xlsx…", "ok")
            })
          )
        ),
        React.createElement("div", { className: "pd-primary-actions" },
          React.createElement(ImmediateForecastButton, {
            onRun: (stressIds) => onImmediateForecastRun(stressIds)
          }),
          React.createElement(PI.Btn, { kind: "primary", icon: React.createElement(PI.Icon.Beaker, {size:13}),
            onClick: onStartForecast }, "Run simulation")
        )
      )
    ),

    // ========== Stats strip ==========
    // 3 KPIs + chips, all on a single row. Numbers respond live to chip clicks.
    React.createElement("div", { className: "pd-head-meta" },
      metaKpi("Investments", visibleFunds.length),
      React.createElement("span", { className: "pd-meta-sep" }),
      metaKpi("Total value", PI.fmt.money(totalValue)),
      React.createElement("span", { className: "pd-meta-sep" }),
      metaKpi("Open commitment", PI.fmt.money(totals.openCommitment)),
      React.createElement("span", { className: "pd-meta-chips" },
        React.createElement(PI.AssetTypeChips, {
          byType, disabledTypes, onToggle: toggleType
        })
      )
    ),

    // ========== View bar ==========
    // Dedicated row for view tabs + the vehicle filter — separates navigation
    // (Table/Universe/Liquidity) from page-level actions.
    React.createElement("div", { className: "pd-view-bar" },
      React.createElement("div", { className: "view-seg pd-view-seg" },
        React.createElement("button", {
          className: `view-seg-btn${view === "table" ? " is-active" : ""}`,
          onClick: () => setView("table"),
          title: "Table view"
        },
          React.createElement(PI.Icon.Table, { size: 13 }),
          React.createElement("span", null, "Table")
        ),
        React.createElement("button", {
          className: `view-seg-btn${view === "universe" ? " is-active" : ""}`,
          onClick: () => setView("universe"),
          title: "Universe view"
        },
          React.createElement(PI.Icon.Layers, { size: 13 }),
          React.createElement("span", null, "Universe")
        ),
        React.createElement("button", {
          className: `view-seg-btn${view === "liquidity" ? " is-active" : ""}`,
          onClick: () => setView("liquidity"),
          title: "Liquidity management"
        },
          React.createElement(PI.Icon.Target, { size: 13 }),
          React.createElement("span", null, "Liquidity")
        )
      ),
      React.createElement(PI.Dropdown, {
        value: vehicle, options: vehicleOpts, onChange: setVehicle,
        icon: React.createElement(PI.Icon.Filter, { size: 13 }),
        minWidth: 180
      })
    ),

    view === "table"
      ? React.createElement(PI.Fragment, null,
          // Distribution strip
          React.createElement("div", { style: { marginBottom: 24 } },
            React.createElement(PI.DistStrip, { funds: visibleFunds, mode, setMode, currency: "USD" })
          ),
          React.createElement("div", { style: { marginBottom: 10 } },
            React.createElement("div", { className: "eyebrow", style: { marginBottom: 8 } }, "Investments")
          ),
          React.createElement(PI.InvestmentsTable, {
            funds: visibleFunds,
            onOpenCashflows: (f) => onShowModal({ kind: "cashflows", fund: f }),
            onEdit: (f) => onShowModal({ kind: "edit", fund: f }),
            onDelete: (f) => onShowModal({ kind: "confirm-delete", fund: f }),
            onAdd: () => onShowModal({ kind: "add" }),
            onGoalSeek: (f, kind) => onShowModal({ kind: "goal-seek", fund: f, gsKind: kind }),
          })
        )
      : view === "liquidity"
      ? React.createElement(PI.LiquidityTab, {
          portfolio, funds: visibleFunds, onToast
        })
      : React.createElement(PI.UniverseView, {
          funds: visibleFunds,
          inspectedVehicleId,
          onInspect: setInspectedVehicleId,
          onClose: () => setInspectedVehicleId(null),
          onSwitchToTable: () => setView("table"),
          onToast
        })
  );
}

window.PI.PortfolioDetail = PortfolioDetail;
