/* Phase 4 — Monte Carlo Simulation (Liquidity Management).
   Self-contained: config modal + results view.

   The simulation reuses the SAME chart components as the Immediate Forecast
   (PI.LiqCharts) so the two views are visually identical. The only
   difference: the user picks a percentile (P5…P95) at the top and every
   chart re-renders showing how that scenario plays out, instead of just
   the mean path that the forecast shows.

   The underlying simulation is a synthesized-percentile-band prototype
   (see data.js `projectSimulation`) — the UI is what a real 50K-iteration
   Monte Carlo would produce; the numbers come from a closed-form μ ± z·σ
   model. Inter-vehicle cashflows (parent/child commitments) stay on the
   mean path regardless of percentile, since commitments are contractual
   and not market-dependent.

   Public exports on window.PI:
     LiquiditySimulationConfigModal ({ vehicleId, onRun, onClose })
     LiquiditySimulationResults     ({ simulation, onBack, onReconfigure })
*/

(function(){
  const { useState, useMemo } = PI;
  const PCTILES = PI_DATA.PCTILES;
  const LC = PI.LiqCharts; // shared chart namespace from liquidityForecast.jsx

  // --------------------------------------------------------------------
  // derivePeriod: given a per-month enriched row (mean path + value/cash
  // percentile bands) and a percentile key, produce a period shaped like
  // the forecast periods — so the shared charts can consume it directly.
  //
  // Rules:
  //   - end_value    = value_percentiles[pctKey]
  //   - cash_balance = cash_percentiles[pctKey]
  //   - non-cash asset values scale proportionally so the allocation sums
  //     back to the percentile total
  //   - cashflow + rebalancing_occurred stay on the mean path (honest —
  //     commitments don't re-distribute per percentile)
  // --------------------------------------------------------------------
  function derivePeriod(p, pctKey) {
    const valueNew = (p.value_percentiles && p.value_percentiles[pctKey] != null)
      ? p.value_percentiles[pctKey] : p.end_value;
    const cashNew  = (p.cash_percentiles  && p.cash_percentiles[pctKey]  != null)
      ? p.cash_percentiles[pctKey]  : p.cash_balance;

    // Non-cash scaling — scale the baseline (mean path) allocation values
    // so the total matches the percentile's value and cash.
    const nonCashBaseline = Math.max(0, p.end_value - p.cash_balance);
    const nonCashTarget   = Math.max(0, valueNew - cashNew);
    const scale = nonCashBaseline > 1e-6 ? (nonCashTarget / nonCashBaseline) : 0;

    const newVals = {};
    const srcVals = p.asset_allocation_value || {};
    Object.keys(srcVals).forEach(k => {
      newVals[k] = k === "cash" ? +cashNew.toFixed(2)
                                : +((srcVals[k] || 0) * scale).toFixed(2);
    });
    // Percentage allocation — recompute so it always sums to ~100.
    const totalNew = Object.values(newVals).reduce((s, v) => s + v, 0);
    const newPct = {};
    Object.keys(newVals).forEach(k => {
      newPct[k] = totalNew > 0 ? +(newVals[k] / totalNew * 100).toFixed(2) : 0;
    });

    return Object.assign({}, p, {
      end_value:    +Number(valueNew).toFixed(2),
      cash_balance: +Number(cashNew).toFixed(2),
      asset_allocation_value: newVals,
      asset_allocation_pct:   newPct
      // start_value, cashflow, net_cashflow, rebalancing_occurred,
      // compliance: left on the mean path intentionally.
    });
  }

  // --------------------------------------------------------------------
  // deriveSummary: recompute the KPI summary for a given per-percentile
  // periods array. Matches the shape produced by projectLiquidityForecast.
  // --------------------------------------------------------------------
  function deriveSummary(viewPeriods, initialTotalValue, initialCash, minCashTarget, rebalancingEventCount) {
    let minCash = Infinity, minCashPeriod = null, insolvencyPeriods = 0;
    viewPeriods.forEach(p => {
      if (p.cash_balance < minCash) { minCash = p.cash_balance; minCashPeriod = p.period; }
      if (p.cash_balance < 0) insolvencyPeriods += 1;
    });
    const last = viewPeriods[viewPeriods.length - 1] || null;
    return {
      currentPortfolioValue: initialTotalValue,
      currentCashBalance:    initialCash,
      endOfPeriodValue:      last ? last.end_value : 0,
      minCashDuringPeriod:   isFinite(minCash) ? minCash : 0,
      minCashPeriod,
      minCashTarget,
      rebalancingEventCount,
      complianceStatus:      last ? (last.compliance || "On target") : "On target",
      insolvencyPeriods
    };
  }

  // --------------------------------------------------------------------
  // Percentile chip selector — shown above the charts on the sim results.
  // --------------------------------------------------------------------
  function PercentileBar({ value, onChange }) {
    const hint = (() => {
      switch (value) {
        case "P5":  return "P5 — worst 5% tail. Use for stress planning.";
        case "P10": return "P10 — adverse scenario. Plan cushion against this.";
        case "P25": return "P25 — pessimistic quartile.";
        case "P50": return "P50 — median outcome (equivalent to the immediate forecast mean).";
        case "P75": return "P75 — optimistic quartile.";
        case "P90": return "P90 — upside scenario.";
        case "P95": return "P95 — best 5% tail.";
        default:    return "";
      }
    })();
    return React.createElement("div", { className: "liq-sim-pct-bar" },
      React.createElement("div", { className: "liq-sim-pct-lbl" },
        React.createElement("span", null, "Scenario"),
        React.createElement("div", { className: "liq-sim-pct-hint" }, hint)
      ),
      React.createElement("div", { className: "liq-sim-pct-chips" },
        PCTILES.map(pc => React.createElement("button", {
          key: pc.key, type: "button",
          className: `liq-sim-pct-chip ${value === pc.key ? "is-active" : ""} ${pc.key === "P50" ? "is-median" : ""}`,
          onClick: () => onChange(pc.key)
        }, pc.label))
      )
    );
  }

  // --------------------------------------------------------------------
  // Simulation Configuration Modal — unchanged from prior Phase 4 build.
  // --------------------------------------------------------------------
  function SimulationConfigModal({ vehicleId, onRun, onClose }) {
    const defaultStart = new Date().toISOString().slice(0, 10);
    const defaultEndDate = (() => {
      const d = new Date(); d.setFullYear(d.getFullYear() + 10); return d.toISOString().slice(0, 10);
    })();
    const defaultName = `Simulation ${new Date().toISOString().slice(0, 10)}`;
    const [simName, setSimName] = useState(defaultName);
    const [depth, setDepth] = useState("full");          // "fast" | "full"
    const [fineTuning, setFineTuning] = useState(false);
    const [currency, setCurrency] = useState("USD");
    const [stressId, setStressId] = useState("");
    const [startDate, setStartDate] = useState(defaultStart);
    const [endDate, setEndDate] = useState(defaultEndDate);
    const [vid, setVid] = useState(vehicleId || "V-08");

    const vehicleOpts = useMemo(() => (PI_DATA.VEHICLE_TREE || [])
      .filter(v => !String(v.id).startsWith("CL-"))
      .map(v => ({ value: v.id, label: `${v.id} · ${v.name}` })), []);

    const stressOpts = useMemo(() => {
      const base = [{ value: "", label: "None" }];
      (PI_DATA.STRESS_TESTS || []).forEach(s => base.push({ value: s.id, label: s.name || s.id }));
      return base;
    }, []);

    const errors = {};
    if (!simName || !simName.trim()) errors.simName = "Simulation name is required.";
    if (!currency) errors.currency = "Currency is required.";
    if (!startDate) errors.startDate = "Start date is required.";
    if (!endDate) errors.endDate = "End date is required.";
    if (startDate && endDate && endDate <= startDate) errors.endDate = "End date must be after start date.";
    if (!vid) errors.vehicle = "Vehicle is required.";
    const canRun = Object.keys(errors).length === 0;

    const handleRun = () => {
      if (!canRun) return;
      onRun({
        simulationName: simName.trim(),
        depth,
        fineTuning,
        currency,
        stressTestId: stressId || null,
        startDate,
        endDate,
        vehicleId: vid
      });
    };

    const iterationLabel = depth === "fast" ? "1,000 iterations" : "50,000 iterations";

    return React.createElement(PI.Portal, null,
      React.createElement("div", { className: "scrim" }),
      React.createElement("div", { className: "modal-wrap", onClick: onClose },
        React.createElement("div", { className: "modal modal-md liq-fc-cfg liq-sim-cfg", onClick: e => e.stopPropagation() },
          React.createElement("header", { className: "modal-head" },
            React.createElement("div", null,
              React.createElement("div", { className: "eyebrow" }, "Liquidity simulation"),
              React.createElement("h2", { className: "modal-title" }, "Configure simulation")
            ),
            React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose, title: "Close" })
          ),
          React.createElement("div", { className: "modal-body liq-fc-cfg-body" },
            React.createElement(PI.Field, { label: "Simulation name", required: true, error: errors.simName, wide: true },
              React.createElement("input", {
                type: "text", className: "input", value: simName,
                onChange: e => setSimName(e.target.value),
                placeholder: "e.g. Base case — Q2 2026"
              })
            ),
            React.createElement("div", { className: "field-row" },
              React.createElement(PI.Field, { label: "Simulation depth", hint: iterationLabel },
                React.createElement("div", { className: "liq-sim-radio-group" },
                  React.createElement("label", { className: "liq-sim-radio" },
                    React.createElement("input", {
                      type: "radio", name: "sim-depth", value: "fast",
                      checked: depth === "fast", onChange: () => setDepth("fast")
                    }),
                    React.createElement("span", null, "Fast"),
                    React.createElement("span", { className: "liq-sim-radio-sub" }, "1,000 iterations")
                  ),
                  React.createElement("label", { className: "liq-sim-radio" },
                    React.createElement("input", {
                      type: "radio", name: "sim-depth", value: "full",
                      checked: depth === "full", onChange: () => setDepth("full")
                    }),
                    React.createElement("span", null, "Full"),
                    React.createElement("span", { className: "liq-sim-radio-sub" }, "50,000 iterations")
                  )
                )
              ),
              React.createElement(PI.Field, { label: "Fine-tuning", hint: "Edit portfolio before running." },
                React.createElement("div", { className: "liq-sim-radio-group" },
                  React.createElement("label", { className: "liq-sim-radio" },
                    React.createElement("input", {
                      type: "radio", name: "sim-fine", value: "no",
                      checked: !fineTuning, onChange: () => setFineTuning(false)
                    }),
                    React.createElement("span", null, "No"),
                    React.createElement("span", { className: "liq-sim-radio-sub" }, "Run immediately")
                  ),
                  React.createElement("label", { className: "liq-sim-radio is-disabled", title: "Fine-tuning editor is out of prototype scope." },
                    React.createElement("input", {
                      type: "radio", name: "sim-fine", value: "yes",
                      checked: fineTuning, onChange: () => setFineTuning(true), disabled: true
                    }),
                    React.createElement("span", null, "Yes"),
                    React.createElement("span", { className: "liq-sim-radio-sub" }, "Edit first (soon)")
                  )
                )
              )
            ),
            React.createElement("div", { className: "field-row" },
              React.createElement(PI.Field, { label: "Currency", required: true, error: errors.currency },
                React.createElement(PI.Dropdown, {
                  value: currency, onChange: setCurrency,
                  options: [{ value: "USD", label: "USD — US Dollar" }, { value: "EUR", label: "EUR — Euro" }, { value: "GBP", label: "GBP — British Pound" }],
                  minWidth: 220
                })
              ),
              React.createElement(PI.Field, { label: "Stress test", hint: "Leave empty for baseline." },
                React.createElement(PI.Dropdown, {
                  value: stressId, onChange: setStressId,
                  options: stressOpts, minWidth: 220
                })
              )
            ),
            React.createElement("div", { className: "field-row" },
              React.createElement(PI.Field, { label: "Start date", required: true, error: errors.startDate },
                React.createElement("input", {
                  type: "date", className: "input", value: startDate,
                  onChange: e => setStartDate(e.target.value)
                })
              ),
              React.createElement(PI.Field, { label: "End date", required: true, error: errors.endDate, hint: "Default: 10 years from start." },
                React.createElement("input", {
                  type: "date", className: "input", value: endDate,
                  onChange: e => setEndDate(e.target.value)
                })
              )
            ),
            React.createElement(PI.Field, { label: "Vehicle", required: true, error: errors.vehicle, wide: true },
              React.createElement(PI.Dropdown, {
                value: vid, onChange: setVid, options: vehicleOpts, minWidth: 320
              })
            )
          ),
          React.createElement("footer", { className: "modal-foot" },
            React.createElement("div", { className: "liq-fc-cfg-status" },
              canRun
                ? React.createElement("span", { className: "strat-foot-ok" },
                    React.createElement(PI.Icon.Check, { size: 13 }), ` Ready to run (${iterationLabel}).`)
                : React.createElement("span", { className: "strat-foot-err" },
                    React.createElement(PI.Icon.Info, { size: 13 }),
                    ` ${Object.keys(errors).length} field${Object.keys(errors).length === 1 ? "" : "s"} need attention.`)
            ),
            React.createElement("div", { style: { display: "flex", gap: 8 } },
              React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
              React.createElement(PI.Btn, {
                kind: "primary",
                icon: React.createElement(PI.Icon.Beaker, { size: 13 }),
                onClick: handleRun, disabled: !canRun
              }, "Run simulation")
            )
          )
        )
      )
    );
  }

  // --------------------------------------------------------------------
  // Simulation Results — SAME layout as the forecast, driven by the
  // selected percentile.
  // --------------------------------------------------------------------
  // Inner body of the simulation results page (no chrome). Reused both
  // standalone and embedded inside ResultsPage's Liquidity Management tab.
  function SimulationResultsBody({ simulation, pctKey, setPctKey }) {
    const {
      periods, relationships, vehicleName, vehicleId,
      request_params, initialTotalValue, rebalancingByPercentile
    } = simulation;

    const fullStrategy = PI_DATA.getStrategyByVehicleId(vehicleId);
    const minCashTarget = fullStrategy && fullStrategy.min_cash_reserve_pct > 0
      ? (fullStrategy.min_cash_reserve_pct / 100) * initialTotalValue
      : 0;
    const initialComp = useMemo(() => PI_DATA.calculateVehicleComposition(vehicleId), [vehicleId]);
    const initialCash = (initialComp && initialComp.valueBySpecType && initialComp.valueBySpecType.cash) || 0;

    const viewPeriods = useMemo(
      () => periods.map(p => derivePeriod(p, pctKey)),
      [periods, pctKey]
    );
    const rebalancingCount = (rebalancingByPercentile && rebalancingByPercentile[pctKey]) || 0;
    const summary = useMemo(
      () => deriveSummary(viewPeriods, initialTotalValue, initialCash, minCashTarget, rebalancingCount),
      [viewPeriods, initialTotalValue, initialCash, minCashTarget, rebalancingCount]
    );

    const titleSuffix = `${pctKey} scenario`;

    // Use the shared LiquidityBodyLayout so the simulation inherits the
    // scrollspy nav, sections and rebalancing panel. The PercentileBar is
    // injected as extraTop so it sits at the top of the body.
    const strategyShape = fullStrategy
      ? { id: fullStrategy.id, name: fullStrategy.name, is_preset: fullStrategy.is_preset }
      : null;
    return React.createElement(LC.LiquidityBodyLayout, {
      periods: viewPeriods, summary, relationships, vehicleId, vehicleName,
      titleSuffix, minCashTarget,
      strategy: strategyShape,
      extraTop: React.createElement(PercentileBar, { value: pctKey, onChange: setPctKey })
    });
  }

  function SimulationResults({ simulation, onBack, onReconfigure, embedded }) {
    if (!simulation) return null;
    const [pctKey, setPctKey] = useState("P50");
    const [topTab, setTopTab] = useState("liquidity");
    // Currently-viewed vehicle. Starts as the one the user originally ran.
    // (Only used in the standalone view — when embedded, the parent owns the
    // vehicle scope and re-runs the simulation itself.)
    const [viewVid, setViewVid] = useState(simulation.vehicleId);

    // Re-run the simulation for the newly-selected vehicle with identical
    // request parameters. Reuse the original result when the selection
    // matches. This makes the standalone results view a live per-vehicle
    // explorer.
    const activeSim = useMemo(() => {
      if (viewVid === simulation.vehicleId) return simulation;
      try {
        return PI_DATA.projectSimulation(viewVid, {
          currency:       simulation.request_params.currency,
          stressTestId:   simulation.request_params.stress_test_id,
          startDate:      simulation.request_params.startDate,
          endDate:        simulation.request_params.endDate,
          depth:          simulation.request_params.depth,
          simulationName: simulation.request_params.simulation_name,
          fineTuning:     simulation.request_params.fine_tuning
        });
      } catch (e) {
        return simulation;
      }
    }, [viewVid, simulation]);

    // When embedded, ignore the internal viewVid state — the page-level
    // VehicleScopePicker drives the vehicle, and the parent re-runs the
    // simulation. Trust the prop, otherwise the stale viewVid would
    // override the parent's choice and the page wouldn't update.
    if (embedded) {
      return React.createElement(SimulationResultsBody, {
        simulation, pctKey, setPctKey
      });
    }

    const { vehicleName, vehicleId, strategy, request_params } = activeSim;

    const vehicleLabel = `${vehicleId} · ${vehicleName}`;

    return React.createElement("div", { className: "liq-fc-results liq-sim-results", "data-screen-label": "02e Simulation Results" },
      // ========== Page header ==========
      // Top row: back link + page-level actions. Title row: eyebrow + title +
      // metadata pills. Mirrors the Immediate Forecast layout. (Vehicle picker
      // lives in the always-visible hierarchy panel below.)
      React.createElement("header", { className: "liq-fc-head" },
        React.createElement("div", { className: "liq-fc-head-top" },
          React.createElement(PI.Btn, {
            kind: "ghost", size: "sm", onClick: onBack,
            icon: React.createElement(PI.Icon.ChevronLeft, { size: 13 })
          }, "Back to Liquidity"),
          React.createElement("div", { className: "liq-fc-head-actions" },
            React.createElement(PI.Btn, { kind: "ghost", onClick: onReconfigure,
              icon: React.createElement(PI.Icon.Settings, { size: 13 }) }, "Reconfigure")
          )
        ),
        React.createElement("div", { className: "liq-fc-head-title-block" },
          React.createElement("div", { className: "eyebrow liq-fc-head-eyebrow" }, "Liquidity simulation"),
          React.createElement("h2", { className: "liq-fc-head-title" }, `${request_params.simulation_name} — ${vehicleLabel}`),
          React.createElement("div", { className: "liq-fc-head-meta" },
            strategy && React.createElement("span", { className: "liq-fc-meta-pill" },
              React.createElement(PI.Icon.Target, { size: 11 }),
              `${strategy.name}${strategy.is_preset ? " · preset" : ""}`
            ),
            React.createElement("span", { className: "liq-fc-meta-pill" },
              `${request_params.depth === "fast" ? "Fast" : "Full"} · ${request_params.iterations.toLocaleString()} iterations`),
            React.createElement("span", { className: "liq-fc-meta-pill" }, request_params.currency),
            React.createElement("span", { className: "liq-fc-meta-pill" },
              `${request_params.startDate} → ${request_params.endDate}`),
            request_params.stress_test_id && React.createElement("span", { className: "liq-fc-meta-pill is-warn" },
              `Stress: ${request_params.stress_test_id}`)
          )
        )
      ),

      // Unified Liquidity ↔ Performance tab bar
      PI.UnifiedResultsTabs && React.createElement(PI.UnifiedResultsTabs, {
        active: topTab, onChange: setTopTab
      }),

      topTab === "liquidity"
        ? React.createElement(SimulationResultsBody, {
            simulation: activeSim, pctKey, setPctKey
          })
        : (PI.EmbeddedPerformancePane
            ? React.createElement(PI.EmbeddedPerformancePane, {
                forecastSrc: activeSim, kind: "simulation"
              })
            : null)
    );
  }

  // --------------------------------------------------------------------
  window.PI.LiquiditySimulationConfigModal = SimulationConfigModal;
  window.PI.LiquiditySimulationResults = SimulationResults;
})();
