/* Modals: Edit Fund (centered), Add Fund, Cash Flows (centered modal), Confirm delete */

function FundForm({ draft, setDraft, errors = {}, onGoalSeek, onOpenCashflows }) {
  const F = (label, k, props = {}) => React.createElement(PI.Field, { label, error: errors[k], hint: props.hint, required: props.required },
    React.createElement("input", {
      className: "input", value: draft[k] ?? "", type: props.type || "text",
      onChange: e => setDraft({ ...draft, [k]: props.type === "number" ? +e.target.value : e.target.value })
    })
  );
  const S = (label, k, opts, props = {}) => React.createElement(PI.Field, { label, error: errors[k], required: props.required },
    React.createElement("select", {
      className: "select", value: draft[k] ?? "",
      onChange: e => setDraft({ ...draft, [k]: e.target.value })
    }, opts.map(o => React.createElement("option", { key: o, value: o }, o)))
  );
  const FGoal = (label, k, kind, props = {}) => React.createElement(PI.Field, { label, error: errors[k], required: props.required },
    React.createElement("div", { className: "input-addon" },
      React.createElement("input", {
        className: "input", value: draft[k] ?? "", type: props.type || "text",
        onChange: e => setDraft({ ...draft, [k]: props.type === "number" ? +e.target.value : e.target.value })
      }),
      React.createElement("button", {
        className: "input-addon-btn", type: "button",
        onClick: () => onGoalSeek && onGoalSeek(kind), title: "Price goal seek"
      }, React.createElement(PI.Icon.Microscope, { size: 14 }), React.createElement("span", null, "Goal seek"))
    )
  );

  const assetType = draft.assetType || "primary";
  const STAGES = ["Buyout","Growth","Venture","Credit","Infrastructure"];
  const GEOS = ["North America","Europe","Asia Pacific","Emerging Markets"];
  const CURRENCIES = ["USD","EUR","GBP"];
  const HEDGE_STRATS = ["Long/Short Equity","Global Macro","Event-Driven","Relative Value","Multi-Strategy","Credit","Distressed","Arbitrage"];
  const CREDIT_RATINGS = ["AAA","AA+","AA","AA-","A+","A","A-","BBB+","BBB","BBB-","BB","B","CCC","Not rated"];

  // Cash flows section (Primary / Secondary / Co-investment only)
  const cfCount = Array.isArray(draft.cashflows) ? draft.cashflows.length : 0;
  const cashflowsSection = onOpenCashflows && React.createElement(PI.Fragment, null,
    React.createElement("div", { className: "form-section-title" }, "Cash flows"),
    React.createElement("div", { className: "cf-row-btn" },
      React.createElement(PI.Btn, {
        kind: "ghost", size: "sm",
        icon: React.createElement(PI.Icon.Plus, { size: 13 }),
        onClick: onOpenCashflows
      }, cfCount > 0 ? `Manage cash flows (${cfCount})` : "Add cash flows"),
      cfCount > 0 && React.createElement("span", { className: "cf-row-note" }, `${cfCount} entries scheduled`)
    )
  );

  // Asset-type picker — 7 tiles at the top
  const atypePicker = React.createElement("div", { className: "atype-picker" },
    PI_DATA.ASSET_TYPES.map(a => {
      const Ico = PI.Icon[a.icon] || PI.Icon.Layers;
      const active = a.id === assetType;
      return React.createElement("button", {
        key: a.id, type: "button",
        className: "atype-chip" + (active ? " is-active" : ""),
        style: active ? { borderColor: a.color, background: a.color + "14", color: a.color } : undefined,
        onClick: () => setDraft({ ...draft, assetType: a.id })
      },
        React.createElement(Ico, { size: 13 }),
        React.createElement("span", null, a.label)
      );
    })
  );

  const header = React.createElement(PI.Fragment, null,
    React.createElement("div", { className: "form-section-title" }, "Asset type"),
    atypePicker
  );

  if (assetType === "primary") {
    return React.createElement(PI.Fragment, null,
      header,
      React.createElement("div", { className: "form-section-title" }, "Identification"),
      React.createElement("div", { className: "form-grid" },
        F("Fund name", "name", { required: true }),
        F("Investment name", "investmentName"),
        F("Investment ID", "id", { required: true }),
        S("Parent vehicle", "vehicle", PI_DATA.VEHICLES),
        S("Stage", "stage", STAGES),
        S("Geography", "geography", GEOS),
      ),
      React.createElement("div", { className: "form-section-title" }, "Capital & schedule"),
      React.createElement("div", { className: "form-grid" },
        S("Currency", "currency", CURRENCIES),
        F("Vintage year", "vintage", { type: "number" }),
        F("Commitment ($M)", "committed", { type: "number", required: true }),
        F("Fund size ($M)", "fundSize", { type: "number" }),
        F("Date of first projected cash flow", "dateFirstProj"),
      ),
      cashflowsSection
    );
  }

  if (assetType === "secondary") {
    return React.createElement(PI.Fragment, null,
      header,
      React.createElement("div", { className: "form-section-title" }, "Identification & classification"),
      React.createElement("div", { className: "form-grid" },
        F("Fund name", "name", { required: true }),
        F("Investment name", "investmentName"),
        F("Investment ID", "id", { required: true }),
        S("Parent vehicle", "vehicle", PI_DATA.VEHICLES),
        S("Stage", "stage", STAGES),
        S("Geography", "geography", GEOS),
        S("Currency", "currency", CURRENCIES),
        F("Vintage year", "vintage", { type: "number" }),
        F("Commitment ($M)", "committed", { type: "number", required: true }),
        F("Fund size ($M)", "fundSize", { type: "number" }),
        F("Open commitment ($M)", "openCommitment", { type: "number" }),
        F("Date of first projected CF", "dateFirstProj"),
      ),
      React.createElement("div", { className: "form-section-title" }, "Secondary purchase & valuation"),
      React.createElement("div", { className: "form-grid" },
        F("Initial CF date", "dateInitialCf"),
        F("Paid-in before purchase ($M)", "paidInBefore", { type: "number" }),
        F("Dist. before purchase ($M)", "distributedBefore", { type: "number" }),
        F("Purchase date", "purchaseDate"),
        FGoal("Purchase price ($M)", "purchasePrice", "purchase", { type: "number" }),
        F("Valuation ($M)", "nav", { type: "number" }),
        F("Valuation date", "dateNav"),
      ),
      cashflowsSection
    );
  }

  if (assetType === "coinvestment") {
    return React.createElement(PI.Fragment, null,
      header,
      React.createElement("div", { className: "form-section-title" }, "Identification"),
      React.createElement("div", { className: "form-grid" },
        F("Company name", "name", { required: true }),
        F("Investment name", "investmentName"),
        F("Investment ID", "id", { required: true }),
        S("Parent vehicle", "vehicle", PI_DATA.VEHICLES),
        S("Stage", "stage", STAGES),
        S("Geography", "geography", GEOS),
      ),
      React.createElement("div", { className: "form-section-title" }, "Capital & dates"),
      React.createElement("div", { className: "form-grid" },
        S("Currency", "currency", CURRENCIES),
        F("Vintage year", "vintage", { type: "number" }),
        F("Commitment ($M)", "committed", { type: "number", required: true }),
        F("Date of first projected CF", "dateFirstProj"),
        F("Exit date", "exitDate"),
      ),
      cashflowsSection
    );
  }

  if (assetType === "stock") {
    return React.createElement(PI.Fragment, null,
      header,
      React.createElement("div", { className: "form-section-title" }, "Identification & position"),
      React.createElement("div", { className: "form-grid" },
        F("Ticker", "ticker", { required: true }),
        F("Company name", "name", { required: true }),
        F("Investment ID", "id", { required: true }),
        S("Parent vehicle", "vehicle", PI_DATA.VEHICLES),
        F("# Shares", "shares", { type: "number", required: true }),
        F("Purchase price per share (PMC)", "pricePerShare", { type: "number", required: true }),
        F("Purchase date", "purchaseDate"),
        S("Currency", "currency", CURRENCIES),
        F("Sector", "sector", { hint: "Optional" }),
      )
    );
  }

  if (assetType === "bond") {
    return React.createElement(PI.Fragment, null,
      header,
      React.createElement("div", { className: "form-section-title" }, "Identification & terms"),
      React.createElement("div", { className: "form-grid" },
        F("Issuer", "name", { required: true }),
        F("ISIN", "isin", { required: true }),
        F("Investment ID", "id", { required: true }),
        S("Parent vehicle", "vehicle", PI_DATA.VEHICLES),
        F("Face value ($M)", "faceValue", { type: "number", required: true }),
        F("Coupon rate (%)", "coupon", { type: "number" }),
        F("Maturity date", "maturityDate"),
        F("Purchase date", "purchaseDate"),
        F("Purchase price (% of nominal)", "pricePctNominal", { type: "number" }),
        S("Currency", "currency", CURRENCIES),
        S("Credit rating", "creditRating", CREDIT_RATINGS),
      )
    );
  }

  if (assetType === "etf") {
    return React.createElement(PI.Fragment, null,
      header,
      React.createElement("div", { className: "form-section-title" }, "Identification & position"),
      React.createElement("div", { className: "form-grid" },
        F("Ticker", "ticker", { required: true }),
        F("Fund name", "name", { required: true }),
        F("Investment ID", "id", { required: true }),
        S("Parent vehicle", "vehicle", PI_DATA.VEHICLES),
        F("# Shares", "shares", { type: "number", required: true }),
        F("Purchase price per share", "pricePerShare", { type: "number", required: true }),
        F("Purchase date", "purchaseDate"),
        S("Currency", "currency", CURRENCIES),
        F("Expense ratio (%)", "expenseRatio", { type: "number", hint: "Optional" }),
      )
    );
  }

  if (assetType === "hedge") {
    return React.createElement(PI.Fragment, null,
      header,
      React.createElement("div", { className: "form-section-title" }, "Identification & strategy"),
      React.createElement("div", { className: "form-grid" },
        F("Fund name", "name", { required: true }),
        F("Investment ID", "id", { required: true }),
        F("Manager / GP", "fundManager", { required: true }),
        S("Parent vehicle", "vehicle", PI_DATA.VEHICLES),
        S("Strategy", "strategy", HEDGE_STRATS),
        F("Subscription date", "subscriptionDate"),
        F("Commitment ($M)", "committed", { type: "number", required: true }),
        F("Current NAV ($M)", "nav", { type: "number" }),
        F("NAV date", "dateNav"),
        S("Currency", "currency", CURRENCIES),
        F("Lock-up (months)", "lockup", { type: "number", hint: "Optional" }),
        F("Management fee (%)", "mgmtFee", { type: "number", hint: "Optional" }),
      )
    );
  }

  return header;
}

function EditFundModal({ fund, isAdd, onSave, onClose, onOpenCashflows, onOpenGoalSeek, showToast }) {
  const [draft, setDraft] = PI.useState(fund || {
    assetType: "primary", currency: "USD", vintage: 2024,
    stage: "Buyout", geography: "North America",
    vehicle: PI_DATA.VEHICLES[0]
  });
  const [errors, setErrors] = PI.useState({});
  const [cfOpen, setCfOpen] = PI.useState(false);

  function save() {
    const e = {};
    const at = draft.assetType || "primary";
    // Name is required for all types
    if (!draft.name) e.name = "Required";
    if (!draft.id) e.id = "Required";
    // Capital/position field required varies per asset type
    if (at === "primary" || at === "secondary" || at === "coinvestment" || at === "hedge") {
      if (!draft.committed) e.committed = "Required";
    } else if (at === "stock" || at === "etf") {
      if (!draft.ticker) e.ticker = "Required";
      if (!draft.shares) e.shares = "Required";
      if (!draft.pricePerShare) e.pricePerShare = "Required";
    } else if (at === "bond") {
      if (!draft.isin) e.isin = "Required";
      if (!draft.faceValue) e.faceValue = "Required";
    }
    setErrors(e);
    if (Object.keys(e).length === 0) onSave(draft);
  }

  const at = draft.assetType || "primary";
  const canEditCashflows = at === "primary" || at === "secondary" || at === "coinvestment";

  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: onClose }),
    React.createElement("div", { className: "modal-wrap", onClick: onClose },
      React.createElement("div", { className: "modal modal-xl", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" }, isAdd ? "New investment" : "Edit investment"),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 500 } },
              isAdd ? "Add a fund to this portfolio" : (draft.name || "Investment"))
          ),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),
        React.createElement("div", { className: "modal-body is-no-scroll add-fund-form" },
          React.createElement(FundForm, {
            draft, setDraft, errors,
            onGoalSeek: (kind) => onOpenGoalSeek && onOpenGoalSeek(draft, kind),
            onOpenCashflows: canEditCashflows ? () => setCfOpen(true) : undefined
          })
        ),
        React.createElement("footer", { className: "modal-foot" },
          React.createElement("div", { style: { marginRight: "auto", fontSize: 12, color: "var(--black-60)" } },
            Object.keys(errors).length > 0
              ? React.createElement("span", { style: { color: "var(--red)" } }, "Please fix the highlighted fields.")
              : "All changes are validated on save."
          ),
          React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
          React.createElement(PI.Btn, { kind: "primary", icon: React.createElement(PI.Icon.Save, {size:13}), onClick: save },
            isAdd ? "Add fund" : "Save changes")
        )
      )
    ),
    cfOpen && React.createElement(CashflowsModal, {
      fund: draft,
      initialRows: draft.cashflows,
      onClose: () => setCfOpen(false),
      onSaveCashflows: (rows) => {
        setDraft(d => ({ ...d, cashflows: rows }));
        setCfOpen(false);
      },
      showToast: showToast || (() => {})
    })
  );
}

// ---------- Cash flows modal (centered, inline edits) ----------
function CashflowsModal({ fund, onClose, onSaveCashflows, showToast, initialRows }) {
  const [rows, setRows] = PI.useState(() => initialRows || PI_DATA.buildCashflows(fund, (fund.vintage || new Date().getFullYear()) + 1));
  const [editingId, setEditingId] = PI.useState(null);
  const [confirmId, setConfirmId] = PI.useState(null);
  const [adding, setAdding] = PI.useState(null);

  const sums = rows.reduce((acc, r) => {
    if (r.type === "Contribution") acc.contrib += Math.abs(r.amount);
    else if (r.type === "Distribution") acc.dist += r.amount;
    else if (r.type === "Valuation") acc.nav = r.amount;
    return acc;
  }, { contrib: 0, dist: 0, nav: 0 });

  function saveEdit(row) {
    setRows(rs => rs.map(r => r.id === row.id ? row : r));
    setEditingId(null);
    showToast("Cash flow updated", "ok");
  }
  function delRow(id) {
    setRows(rs => rs.filter(r => r.id !== id));
    setConfirmId(null);
    showToast("Cash flow removed", "ok");
  }
  function addRow(row) {
    setRows(rs => [...rs, { ...row, id: "CF-NEW-" + Date.now() }].sort((a, b) => a.date < b.date ? -1 : 1));
    setAdding(null);
    showToast("Cash flow added", "ok");
  }

  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: onClose }),
    React.createElement("div", { className: "modal-wrap", onClick: onClose },
      React.createElement("div", { className: "modal modal-lg", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" }, "Cash flows"),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 500 } }, fund.name)
          ),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),
        React.createElement("div", { className: "modal-body" },
          React.createElement("div", { className: "cf-summary" },
            React.createElement("div", { className: "cf-sum-card" },
              React.createElement("div", { className: "cf-sum-lbl" }, "Total contributions"),
              React.createElement("div", { className: "cf-sum-val num" }, PI.fmt.moneyPlain(sums.contrib, fund.currency))
            ),
            React.createElement("div", { className: "cf-sum-card is-dist" },
              React.createElement("div", { className: "cf-sum-lbl" }, "Total distributions"),
              React.createElement("div", { className: "cf-sum-val num" }, PI.fmt.moneyPlain(sums.dist, fund.currency))
            ),
            React.createElement("div", { className: "cf-sum-card is-nav" },
              React.createElement("div", { className: "cf-sum-lbl" }, "Latest NAV"),
              React.createElement("div", { className: "cf-sum-val num" }, PI.fmt.moneyPlain(sums.nav, fund.currency))
            )
          ),
          React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", margin: "12px 0 10px" } },
            React.createElement("div", { className: "eyebrow" }, `${rows.length} entries`),
            React.createElement(PI.Btn, {
              kind: "ghost", size: "sm",
              icon: React.createElement(PI.Icon.Plus, { size: 13 }),
              onClick: () => setAdding({ type: "Contribution", date: new Date().toISOString().slice(0,10), amount: -1 })
            }, "Add cash flow")
          ),
          React.createElement("table", { className: "cf-table" },
            React.createElement("thead", null, React.createElement("tr", null,
              React.createElement("th", null, "Type"),
              React.createElement("th", null, "Date"),
              React.createElement("th", { className: "num" }, "Amount"),
              React.createElement("th", { style: { width: 80 } }, "")
            )),
            React.createElement("tbody", null,
              adding && React.createElement("tr", { className: "is-add cf-add-row" },
                React.createElement("td", null,
                  React.createElement("select", { className: "select", value: adding.type, onChange: e => setAdding({...adding, type: e.target.value}) },
                    ["Contribution","Distribution","Valuation"].map(t => React.createElement("option", { key: t, value: t }, t)))
                ),
                React.createElement("td", null,
                  React.createElement("input", { className: "input", type: "date", value: adding.date, onChange: e => setAdding({...adding, date: e.target.value}) })
                ),
                React.createElement("td", { className: "num" },
                  React.createElement("input", { className: "input", type: "number", value: adding.amount, onChange: e => setAdding({...adding, amount: +e.target.value}) })
                ),
                React.createElement("td", null,
                  React.createElement("div", { style: { display: "flex", gap: 2 } },
                    React.createElement("button", { className: "btn-icon-naked", onClick: () => addRow(adding), title: "Save" }, React.createElement(PI.Icon.Check, { size: 14 })),
                    React.createElement("button", { className: "btn-icon-naked", onClick: () => setAdding(null), title: "Cancel" }, React.createElement(PI.Icon.X, { size: 14 }))
                  )
                )
              ),
              rows.map(r => {
                const isEdit = editingId === r.id;
                const isConfirm = confirmId === r.id;
                const dotClass = r.type === "Contribution" ? "contrib" : r.type === "Distribution" ? "dist" : "nav";
                if (isEdit) {
                  return React.createElement("tr", { key: r.id, className: "is-edit" },
                    React.createElement("td", null,
                      React.createElement("select", { className: "select", defaultValue: r.type, id: `cf-type-${r.id}` },
                        ["Contribution","Distribution","Valuation"].map(t => React.createElement("option", { key: t, value: t }, t)))
                    ),
                    React.createElement("td", null,
                      React.createElement("input", { className: "input", type: "date", defaultValue: r.date, id: `cf-date-${r.id}` })
                    ),
                    React.createElement("td", { className: "num" },
                      React.createElement("input", { className: "input", type: "number", defaultValue: r.amount, id: `cf-amt-${r.id}` })
                    ),
                    React.createElement("td", null,
                      React.createElement("div", { style: { display: "flex", gap: 2 } },
                        React.createElement("button", { className: "btn-icon-naked", title: "Save", onClick: () => saveEdit({
                          ...r,
                          type: document.getElementById(`cf-type-${r.id}`).value,
                          date: document.getElementById(`cf-date-${r.id}`).value,
                          amount: +document.getElementById(`cf-amt-${r.id}`).value,
                        })}, React.createElement(PI.Icon.Check, { size: 14 })),
                        React.createElement("button", { className: "btn-icon-naked", title: "Cancel", onClick: () => setEditingId(null) }, React.createElement(PI.Icon.X, { size: 14 }))
                      )
                    )
                  );
                }
                return React.createElement("tr", { key: r.id, onClick: () => !isConfirm && setEditingId(r.id) },
                  React.createElement("td", null,
                    React.createElement("span", { className: `cf-type-dot ${dotClass}` }),
                    r.type
                  ),
                  React.createElement("td", null, r.date),
                  React.createElement("td", { className: "num " + (r.amount >= 0 ? "cf-amount-pos" : "cf-amount-neg") },
                    (r.amount >= 0 ? "+" : "") + PI.fmt.moneyPlain(r.amount, fund.currency)
                  ),
                  React.createElement("td", null,
                    isConfirm
                      ? React.createElement("div", { style: { display: "flex", gap: 2 }, onClick: e => e.stopPropagation() },
                          React.createElement("button", { className: "btn-icon-naked", title: "Confirm delete", style: { color: "var(--red)" }, onClick: () => delRow(r.id) }, React.createElement(PI.Icon.Check, { size: 14 })),
                          React.createElement("button", { className: "btn-icon-naked", title: "Keep", onClick: () => setConfirmId(null) }, React.createElement(PI.Icon.X, { size: 14 }))
                        )
                      : React.createElement("div", { className: "row-actions", style: { opacity: 1 }, onClick: e => e.stopPropagation() },
                          React.createElement("button", { title: "Edit", onClick: () => setEditingId(r.id) }, React.createElement(PI.Icon.Edit, { size: 13 })),
                          React.createElement("button", { title: "Delete", className: "is-danger", onClick: () => setConfirmId(r.id) }, React.createElement(PI.Icon.Trash, { size: 13 }))
                        )
                  )
                );
              })
            )
          )
        ),
        React.createElement("footer", { className: "modal-foot" },
          React.createElement("div", { style: { marginRight: "auto", fontSize: 12, color: "var(--black-60)" } },
            "Click any row to edit inline."
          ),
          React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
          React.createElement(PI.Btn, { kind: "primary", icon: React.createElement(PI.Icon.Save, {size:13}),
            onClick: () => { onSaveCashflows(rows); onClose(); } }, "Save & close")
        )
      )
    )
  );
}

function ConfirmDialog({ title, message, confirmLabel = "Delete", confirmKind = "danger", onConfirm, onClose }) {
  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: onClose }),
    React.createElement("div", { className: "modal-wrap", onClick: onClose },
      React.createElement("div", { className: "modal modal-sm", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("h3", { style: { fontSize: 16, fontWeight: 500 } }, title),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),
        React.createElement("div", { className: "modal-body", style: { fontSize: 13, color: "var(--black-80)" } }, message),
        React.createElement("footer", { className: "modal-foot" },
          React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
          React.createElement(PI.Btn, { kind: confirmKind === "danger" ? "danger" : "primary", onClick: onConfirm }, confirmLabel)
        )
      )
    )
  );
}

window.PI.EditFundDrawer = EditFundModal; // keep same export name so app.jsx doesn't break
window.PI.EditFundModal = EditFundModal;
window.PI.CashflowsDrawer = CashflowsModal;
window.PI.CashflowsModal = CashflowsModal;
window.PI.ConfirmDialog = ConfirmDialog;
