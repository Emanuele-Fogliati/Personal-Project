/* Simulation-only probability distribution charts:
     - DensityDistribution: smooth KDE-like curve with P10/Median/P90 stats
     - ProbByYearChart:     year dropdown + DensityDistribution
     - ViolinCard:          SINGLE metric violin (full-width card)
     - SimDistributionsSection: TVPI density + 4 per-year prob charts
     - SimComparisonSection:    4 separate ViolinCards (contrib/distrib/net/nav)
     - SimResultsBlock:     convenience orchestrator for the Distributions tab
*/

(function(){
  const COL = (window.PI && window.PI.FC_COL) || {
    contrib: "#2F3E55", distrib: "#7FCCC8", net: "#058F8A", nav: "#E5AD00",
    grid: "var(--rule-soft)", axis: "var(--black-60)",
  };

  function fmtX(v){ return (v >= 0 ? "" : "-") + Math.abs(v).toFixed(2) + "×"; }
  function fmtP(v){ return (v * 100).toFixed(1) + "%"; }
  function fmtM(v){
    if (!Number.isFinite(v)) return "—";
    const a = Math.abs(v);
    if (a >= 1000) return (v < 0 ? "-$" : "$") + (Math.abs(v)/1000).toFixed(2) + "B";
    return (v < 0 ? "-$" : "$") + Math.abs(v).toFixed(0) + "M";
  }
  const FMT = { "x": fmtX, "%": fmtP, "$": fmtM };

  // ---------------------------------------------------------------
  // Density distribution — KDE-style curve with percentile markers
  // ---------------------------------------------------------------
  function DensityDistribution({ mean, std, p10, p90, min, max, unit = "x",
                                 accent = COL.net, height = 220, seed = 1,
                                 showStats = true }){
    const fmt = FMT[unit] || fmtX;
    const span = (p90 - p10) || Math.abs(mean) * 0.2 || 1;
    const lo = Number.isFinite(min) ? min : (mean - 2.2 * std);
    const hi = Number.isFinite(max) ? max : (mean + 2.2 * std);
    const xLo = lo - span * 0.05;
    const xHi = hi + span * 0.05;

    const W = 560, H = height;
    const padL = 16, padR = 16, padT = 20, padB = 36;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;

    const N = 180;
    const xs = [], ys = [];
    let yMax = 0;
    for (let i = 0; i < N; i++) {
      const x = xLo + (i / (N - 1)) * (xHi - xLo);
      const z = (x - mean) / (std || 1);
      const pdf = Math.exp(-0.5 * z * z);
      xs.push(x); ys.push(pdf);
      if (pdf > yMax) yMax = pdf;
    }
    yMax = yMax || 1;

    const xScale = (v) => padL + ((v - xLo) / (xHi - xLo)) * innerW;
    const yScale = (v) => padT + innerH - (v / yMax) * innerH;

    const pathD = xs.map((x, i) => `${i === 0 ? "M" : "L"} ${xScale(x).toFixed(2)} ${yScale(ys[i]).toFixed(2)}`).join(" ");
    const fillD = pathD + ` L ${xScale(xs[xs.length-1]).toFixed(2)} ${padT + innerH} L ${xScale(xs[0]).toFixed(2)} ${padT + innerH} Z`;

    const inBand = xs.map((x, i) => x >= p10 && x <= p90 ? i : -1).filter(i => i >= 0);
    const bandD = inBand.length > 0
      ? `M ${xScale(xs[inBand[0]]).toFixed(2)} ${padT + innerH} ` +
        inBand.map(i => `L ${xScale(xs[i]).toFixed(2)} ${yScale(ys[i]).toFixed(2)}`).join(" ") +
        ` L ${xScale(xs[inBand[inBand.length-1]]).toFixed(2)} ${padT + innerH} Z`
      : "";

    const xTicks = [];
    for (let i = 0; i <= 5; i++) xTicks.push(xLo + (i / 5) * (xHi - xLo));

    return React.createElement("div", { className: "sim-density" },
      React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height, style: { display: "block" } },
        React.createElement("defs", null,
          React.createElement("linearGradient", { id: "density-grad-" + seed, x1: 0, x2: 0, y1: 0, y2: 1 },
            React.createElement("stop", { offset: "0%", stopColor: accent, stopOpacity: 0.28 }),
            React.createElement("stop", { offset: "100%", stopColor: accent, stopOpacity: 0.04 })
          )
        ),
        React.createElement("path", { d: fillD, fill: `url(#density-grad-${seed})` }),
        bandD && React.createElement("path", { d: bandD, fill: accent, fillOpacity: 0.20 }),
        React.createElement("path", { d: pathD, stroke: accent, strokeWidth: 2, fill: "none", strokeLinejoin: "round" }),
        React.createElement("line", {
          x1: padL, x2: padL + innerW, y1: padT + innerH, y2: padT + innerH,
          stroke: "var(--rule)", strokeWidth: 1
        }),
        xTicks.map((t, i) => React.createElement("g", { key: i },
          React.createElement("line", {
            x1: xScale(t), x2: xScale(t), y1: padT + innerH, y2: padT + innerH + 4,
            stroke: "var(--rule)", strokeWidth: 1
          }),
          React.createElement("text", {
            x: xScale(t), y: padT + innerH + 16, fontSize: 10,
            fill: "var(--black-60)", textAnchor: "middle"
          }, fmt(t))
        )),
        [["P10", p10, "var(--black-60)"], ["Mean", mean, accent], ["P90", p90, "var(--black-60)"]]
          .map(([lbl, val, col], i) => {
            if (!Number.isFinite(val)) return null;
            const x = xScale(val);
            const z = (val - mean) / (std || 1);
            const pdf = Math.exp(-0.5 * z * z);
            const yTop = yScale(pdf);
            return React.createElement("g", { key: i },
              React.createElement("line", {
                x1: x, x2: x, y1: yTop, y2: padT + innerH,
                stroke: col, strokeWidth: lbl === "Mean" ? 1.5 : 1,
                strokeDasharray: lbl === "Mean" ? "" : "3 3", opacity: 0.75
              }),
              React.createElement("text", {
                x: x, y: yTop - 6, fontSize: 10, fill: col,
                textAnchor: "middle", fontWeight: lbl === "Mean" ? 500 : 400
              }, lbl)
            );
          })
      ),
      showStats && React.createElement("div", { className: "sim-density-stats" },
        React.createElement("div", { className: "sim-stat" },
          React.createElement("div", { className: "sim-stat-lbl" }, "P10"),
          React.createElement("div", { className: "sim-stat-val" }, fmt(p10))
        ),
        React.createElement("div", { className: "sim-stat" },
          React.createElement("div", { className: "sim-stat-lbl" }, "Mean"),
          React.createElement("div", { className: "sim-stat-val", style: { color: accent } }, fmt(mean))
        ),
        React.createElement("div", { className: "sim-stat" },
          React.createElement("div", { className: "sim-stat-lbl" }, "P90"),
          React.createElement("div", { className: "sim-stat-val" }, fmt(p90))
        ),
        React.createElement("div", { className: "sim-stat" },
          React.createElement("div", { className: "sim-stat-lbl" }, "Std dev"),
          React.createElement("div", { className: "sim-stat-val" }, fmt(std))
        )
      )
    );
  }

  // ---------------------------------------------------------------
  // Probability by Year chart — year dropdown + density
  // ---------------------------------------------------------------
  function ProbByYearChart({ data, metric, unit = "$", accent = COL.net, seed = 1,
                              title, sub, defaultYear }){
    const series = data.yearDist[metric];
    const simYears = series.filter(s => s.isSim).map(s => s.year);
    const [year, setYear] = React.useState(defaultYear || simYears[Math.floor(simYears.length / 2)] || series[series.length - 1].year);
    const dat = series.find(s => s.year === year) || series[0];
    return React.createElement("div", { className: "fc-card" },
      React.createElement("div", { className: "fc-card-head" },
        React.createElement("div", { className: "fc-card-head-left" },
          React.createElement("div", { className: "card-title" }, title),
          React.createElement("div", { className: "card-sub" }, sub)
        ),
        React.createElement("div", { className: "sim-year-toolbar" },
          React.createElement("span", { className: "sim-year-pill" }, "Year"),
          React.createElement("select", {
            className: "sim-year-select",
            value: year,
            onChange: (e) => setYear(+e.target.value)
          },
            series.map(s => React.createElement("option", {
              key: s.year, value: s.year, disabled: !s.isSim
            }, s.year + (s.isSim ? "" : " · hist")))
          )
        )
      ),
      React.createElement("div", { className: "sim-year-info" },
        React.createElement("span", { className: "sim-year-info-yr" }, year),
        React.createElement("span", { className: "sim-year-info-kind is-" + (dat.isSim ? "sim" : "hist") },
          dat.isSim ? "Simulated" : "Historical"),
        React.createElement("span", { className: "sim-year-info-range" },
          "Range ", (FMT[unit] || fmtX)(dat.min), " – ", (FMT[unit] || fmtX)(dat.max))
      ),
      React.createElement(DensityDistribution, {
        mean: dat.mean, std: dat.std, p10: dat.p10, p90: dat.p90,
        min: dat.min, max: dat.max, unit, accent, seed, height: 220
      })
    );
  }

  // ---------------------------------------------------------------
  // ViolinCard — single metric violin, full-width card
  // ---------------------------------------------------------------
  function ViolinCard({ data, metric, color, label, unit = "$" }){
    const { years, simStartIdx, yearDist } = data;
    const simYears = years.filter((_, i) => i >= simStartIdx);
    const series = yearDist[metric];

    // Render one violin per simulation year (side by side horizontally).
    const W = 920, H = 320;
    const padL = 58, padR = 16, padT = 22, padB = 44;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;

    const simSeries = series.filter(s => s.isSim);
    const slotW = innerW / simSeries.length;
    const violinW = Math.min(slotW * 0.78, 40);

    // Global y-range across simulated years
    const minV = Math.min(...simSeries.map(s => s.min));
    const maxV = Math.max(...simSeries.map(s => s.max));
    const yLo = minV - Math.abs(maxV - minV) * 0.05;
    const yHi = maxV + Math.abs(maxV - minV) * 0.05;
    const yScale = (v) => padT + innerH - ((v - yLo) / (yHi - yLo || 1)) * innerH;

    // Ticks
    const span = yHi - yLo;
    const rough = Math.pow(10, Math.floor(Math.log10(Math.max(1, span))));
    const step = span / rough > 5 ? rough : rough / 2;
    const yTicks = [];
    const startT = Math.floor(yLo / step) * step;
    for (let v = startT; v <= yHi + step * 0.01; v += step) yTicks.push(v);

    // Stats for the summary row (averaged across all sim years)
    const avgMean = simSeries.reduce((a, s) => a + s.mean, 0) / simSeries.length;
    const avgStd  = simSeries.reduce((a, s) => a + s.std, 0)  / simSeries.length;
    const avgP10  = simSeries.reduce((a, s) => a + s.p10, 0)  / simSeries.length;
    const avgP90  = simSeries.reduce((a, s) => a + s.p90, 0)  / simSeries.length;

    return React.createElement("div", { className: "fc-card sim-violin-card" },
      React.createElement("div", { className: "fc-card-head" },
        React.createElement("div", { className: "fc-card-head-left" },
          React.createElement("div", { className: "card-title" },
            React.createElement("span", { className: "sim-violin-swatch", style: { background: color } }),
            label, " · distribution across simulated years"
          ),
          React.createElement("div", { className: "card-sub" },
            "Each violin is the probability density for a given simulation year — wider = more likely. P10/P90 shown as horizontal marks.")
        ),
        React.createElement("div", { className: "sim-violin-summary" },
          React.createElement("div", { className: "sim-stat" },
            React.createElement("div", { className: "sim-stat-lbl" }, "Avg P10"),
            React.createElement("div", { className: "sim-stat-val" }, fmtM(avgP10))
          ),
          React.createElement("div", { className: "sim-stat" },
            React.createElement("div", { className: "sim-stat-lbl" }, "Avg Mean"),
            React.createElement("div", { className: "sim-stat-val", style: { color } }, fmtM(avgMean))
          ),
          React.createElement("div", { className: "sim-stat" },
            React.createElement("div", { className: "sim-stat-lbl" }, "Avg P90"),
            React.createElement("div", { className: "sim-stat-val" }, fmtM(avgP90))
          ),
          React.createElement("div", { className: "sim-stat" },
            React.createElement("div", { className: "sim-stat-lbl" }, "Avg σ"),
            React.createElement("div", { className: "sim-stat-val" }, fmtM(avgStd))
          )
        )
      ),
      React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, style: { display: "block" } },
        // Y grid
        yTicks.map((t, i) => React.createElement("g", { key: i },
          React.createElement("line", {
            x1: padL, x2: padL + innerW, y1: yScale(t), y2: yScale(t),
            stroke: t === 0 ? "var(--black-40)" : COL.grid,
            strokeDasharray: t === 0 ? "" : "3 3"
          }),
          React.createElement("text", {
            x: padL - 8, y: yScale(t) + 3, fontSize: 10,
            fill: COL.axis, textAnchor: "end"
          }, fmtM(t))
        )),
        // Violins
        simSeries.map((s, i) => {
          const cx = padL + i * slotW + slotW / 2;
          const { mean, std, p10, p90, min, max, year } = s;
          const N = 40;
          const pts = [];
          let maxPdf = 0;
          for (let k = 0; k < N; k++) {
            const v = min + (k / (N - 1)) * (max - min);
            const z = (v - mean) / (std || 1);
            const pdf = Math.exp(-0.5 * z * z);
            pts.push({ v, pdf });
            if (pdf > maxPdf) maxPdf = pdf;
          }
          const toW = (pdf) => (pdf / maxPdf) * (violinW / 2);
          const rightPath = pts.map((p, k) => `${k === 0 ? "M" : "L"} ${(cx + toW(p.pdf)).toFixed(2)} ${yScale(p.v).toFixed(2)}`).join(" ");
          const leftPath = [...pts].reverse().map(p => `L ${(cx - toW(p.pdf)).toFixed(2)} ${yScale(p.v).toFixed(2)}`).join(" ");
          const fullPath = rightPath + " " + leftPath + " Z";

          return React.createElement("g", { key: year },
            React.createElement("path", { d: fullPath,
              fill: color, fillOpacity: 0.22, stroke: color, strokeWidth: 1 }),
            [p10, p90].map((v, k) => React.createElement("line", {
              key: k,
              x1: cx - violinW * 0.25, x2: cx + violinW * 0.25,
              y1: yScale(v), y2: yScale(v),
              stroke: color, strokeWidth: 1, opacity: 0.75
            })),
            React.createElement("circle", { cx, cy: yScale(mean), r: 2.5, fill: color }),
            React.createElement("text", {
              x: cx, y: H - 26, fontSize: 10, fill: COL.axis, textAnchor: "middle"
            }, year),
            React.createElement("text", {
              x: cx, y: H - 12, fontSize: 9, fill: COL.axis, textAnchor: "middle", opacity: 0.8
            }, fmtM(mean))
          );
        })
      )
    );
  }

  // ---------------------------------------------------------------
  // TVPI distribution (aggregate — derived from portfolio-level stats)
  // ---------------------------------------------------------------
  function TvpiDistribution({ accent = COL.net, seed = 42, meanTvpi = 1.74, p10 = 1.22, p90 = 2.28, height = 220 }){
    const std = (p90 - p10) / 2.56;
    return React.createElement(DensityDistribution, {
      mean: meanTvpi, std, p10, p90,
      min: meanTvpi - 3 * std, max: meanTvpi + 3 * std,
      unit: "x", accent, seed, height
    });
  }

  // ---------------------------------------------------------------
  // SimDistributionsSection — TVPI + 4 per-year prob cards (2x2 grid)
  // ---------------------------------------------------------------
  function SimDistributionsSection({ data, kpis }){
    const k = kpis || { meanTvpi: 1.74, p10: 1.22, p90: 2.28 };
    return React.createElement(React.Fragment, null,
      React.createElement("div", { className: "fc-card" },
        React.createElement("div", { className: "fc-card-head" },
          React.createElement("div", { className: "fc-card-head-left" },
            React.createElement("div", { className: "card-title" }, "TVPI distribution"),
            React.createElement("div", { className: "card-sub" },
              "Terminal TVPI density across 50,000 simulated paths")
          )
        ),
        React.createElement(TvpiDistribution, {
          accent: COL.net, seed: 42,
          meanTvpi: k.meanTvpi, p10: k.p10, p90: k.p90
        })
      ),
      React.createElement("div", { className: "sim-prob-grid" },
        React.createElement(ProbByYearChart, {
          data, metric: "contrib", unit: "$", accent: COL.contrib, seed: 51,
          title: "Contribution · per-year distribution",
          sub: "Capital called in the selected simulation year — density across 50k paths"
        }),
        React.createElement(ProbByYearChart, {
          data, metric: "distrib", unit: "$", accent: COL.distrib, seed: 63,
          title: "Distribution · per-year distribution",
          sub: "Capital returned in the selected year — density across 50k paths"
        }),
        React.createElement(ProbByYearChart, {
          data, metric: "net", unit: "$", accent: COL.net, seed: 71,
          title: "Net cashflow · per-year distribution",
          sub: "Contribution + distribution in the selected year"
        }),
        React.createElement(ProbByYearChart, {
          data, metric: "nav", unit: "$", accent: COL.nav, seed: 83,
          title: "NAV · per-year distribution",
          sub: "Year-end portfolio value in the selected year"
        })
      )
    );
  }

  // ---------------------------------------------------------------
  // SimComparisonSection — 4 separate ViolinCards stacked vertically
  // ---------------------------------------------------------------
  function SimComparisonSection({ data }){
    return React.createElement(React.Fragment, null,
      React.createElement(ViolinCard, { data, metric: "contrib", color: COL.contrib, label: "Contribution" }),
      React.createElement("div", { style: { height: 16 } }),
      React.createElement(ViolinCard, { data, metric: "distrib", color: COL.distrib, label: "Distribution" }),
      React.createElement("div", { style: { height: 16 } }),
      React.createElement(ViolinCard, { data, metric: "net",     color: COL.net,     label: "Net cashflow" }),
      React.createElement("div", { style: { height: 16 } }),
      React.createElement(ViolinCard, { data, metric: "nav",     color: COL.nav,     label: "NAV" })
    );
  }

  // Convenience full block (TVPI + per-year grid + 4 violins)
  function SimResultsBlock({ portfolio, data, kpis }){
    const d = data || (PI.fcBuildForecast ? PI.fcBuildForecast(portfolio) : null);
    if (!d) return null;
    return React.createElement(React.Fragment, null,
      React.createElement(SimDistributionsSection, { data: d, kpis }),
      React.createElement("div", { style: { height: 16 } }),
      React.createElement(SimComparisonSection, { data: d })
    );
  }

  Object.assign(window.PI, {
    SimDensityDistribution:    DensityDistribution,
    SimProbByYearChart:        ProbByYearChart,
    SimViolinCard:             ViolinCard,
    SimTvpiDistribution:       TvpiDistribution,
    SimDistributionsSection,
    SimComparisonSection,
    SimResultsBlock,
  });
})();
