/* Portfolios list — table view with search, archive tab, column-header filters */

// AssetTypeChips renders a row of asset-type counts.
// When `onToggle` is supplied, chips become clickable filters: clicking one
// turns it off (the parent filters that type out of the table). `disabledTypes`
// is a Set of type ids currently filtered out — those chips render greyed out.
function AssetTypeChips({ byType, compact=false, onToggle, disabledTypes }) {
  if (!byType) return null;
  const entries = Object.entries(byType).filter(([,n]) => n > 0);
  if (entries.length === 0) return null;
  const interactive = typeof onToggle === "function";
  return React.createElement("div", { className: "atype-chips" + (compact ? " is-compact" : "") + (interactive ? " is-interactive" : "") },
    entries.map(([tid, n]) => {
      const meta = PI_DATA.assetTypeMeta(tid);
      const off = disabledTypes && disabledTypes.has(tid);
      const cls = "atype-chip" + (interactive ? " is-clickable" : "") + (off ? " is-off" : "");
      const title = interactive
        ? `${off ? "Show" : "Hide"} ${meta.label}${n === 1 ? "" : "s"} (${n})`
        : `${n} ${meta.label}${n === 1 ? "" : "s"}`;
      const props = {
        key: tid, className: cls,
        style: { "--c": meta.color },
        title,
        ...(interactive ? {
          onClick: () => onToggle(tid),
          role: "button",
          tabIndex: 0,
          "aria-pressed": !off,
          onKeyDown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onToggle(tid); } }
        } : {})
      };
      return React.createElement("span", props,
        React.createElement("span", { className: "atype-chip-dot" }),
        React.createElement("span", { className: "atype-chip-n" }, n),
        !compact && React.createElement("span", { className: "atype-chip-lbl" }, meta.label)
      );
    })
  );
}
PI.AssetTypeChips = AssetTypeChips;

function PortfoliosPage({ portfolios, archived, onSelect, onOpen, onOpenSims, onNewModal, onArchive, onRestore, onDelete, onToast }) {
  const [search, setSearch] = PI.useState("");
  const [tab, setTab] = PI.useState("active");
  const [ownerFilter, setOwnerFilter] = PI.useState("all");

  const source = tab === "active" ? portfolios : archived;
  const ownerOptions = [...new Set(source.map(p => p.owner).filter(Boolean))].sort();
  const filtered = source.filter(p => {
    if (ownerFilter !== "all" && p.owner !== ownerFilter) return false;
    if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });
  const hasFilter = ownerFilter !== "all";

  // Reset owner filter when tab changes (owners differ between active/archived)
  PI.useEffect(() => { setOwnerFilter("all"); }, [tab]);

  return React.createElement("div", { className: "main-inner", "data-screen-label": "01 Portfolios" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("div", { className: "page-crumb" },
          React.createElement("span", null, "Workspace"),
          React.createElement("span", { className: "sep" }, "/"),
          React.createElement("span", null, "Portfolios")
        ),
        React.createElement("h1", { className: "page-title" }, "Portfolios"),
        React.createElement("div", { className: "page-sub" },
          "Upload, manage, and forecast private-market portfolios."
        )
      ),
      React.createElement("div", { className: "head-actions" },
        React.createElement(PI.Btn, {
          kind: "ghost",
          icon: React.createElement(PI.Icon.Download, { size: 14 }),
          onClick: () => onToast("Template downloaded: cepres-portfolio-template.xlsx")
        }, "Download template"),
        React.createElement(PI.Btn, {
          kind: "primary",
          icon: React.createElement(PI.Icon.Plus, { size: 14 }),
          onClick: onNewModal
        }, "New portfolio")
      )
    ),

    React.createElement("div", { className: "tab-bar" },
      React.createElement("button", {
        className: `tab${tab === "active" ? " is-active" : ""}`,
        onClick: () => setTab("active")
      }, "Active ", React.createElement("span", { className: "tab-count" }, portfolios.length)),
      React.createElement("button", {
        className: `tab${tab === "archived" ? " is-active" : ""}`,
        onClick: () => setTab("archived")
      }, "Archived ", React.createElement("span", { className: "tab-count" }, archived.length))
    ),

    React.createElement("div", { className: "table-wrap" },
      React.createElement("div", { className: "tbl-toolbar" },
        React.createElement("div", { className: "tbl-toolbar-left" },
          React.createElement("div", { className: "tbl-search" },
            React.createElement(PI.Icon.Search, { size: 13 }),
            React.createElement("input", {
              placeholder: "Search by portfolio name",
              value: search, onChange: e => setSearch(e.target.value)
            })
          ),
          hasFilter && React.createElement("button", {
            className: "btn-chip-clear",
            onClick: () => setOwnerFilter("all")
          }, "Clear filters"),
          React.createElement("span", { className: "tbl-count" }, `${filtered.length} of ${source.length}`)
        )
      ),
      React.createElement("div", { className: "tbl-scroll" },
        React.createElement("table", { className: "portfolios-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              React.createElement("th", { style: { minWidth: 280 } }, "Portfolio name"),
              React.createElement("th", { style: { minWidth: 200 } }, "Asset mix"),
              React.createElement("th", { className: "num" }, "Open commitment"),
              React.createElement("th", null,
                React.createElement(PI.ColumnFilter, {
                  label: "Owner",
                  value: ownerFilter,
                  options: [{ value: "all", label: "All owners" }, ...ownerOptions.map(o => ({ value: o, label: o }))],
                  onChange: setOwnerFilter
                })
              ),
              React.createElement("th", null, "Last modified"),
              React.createElement("th", { className: "num" }, "Simulations"),
              React.createElement("th", { style: { width: 80 } }, "")
            )
          ),
          React.createElement("tbody", null,
            filtered.length === 0 && React.createElement("tr", null,
              React.createElement("td", { colSpan: 7, className: "tbl-empty" },
                tab === "archived"
                  ? "No archived portfolios."
                  : search
                    ? `No portfolios match "${search}".`
                    : React.createElement(PI.Fragment, null,
                        "No portfolios yet. ",
                        React.createElement("a", { href: "#", onClick: e => { e.preventDefault(); onNewModal(); } }, "Create your first portfolio"),
                        "."
                      )
              )
            ),
            filtered.map(p => {
              return React.createElement("tr", {
                key: p.id,
                className: "is-clickable",
                onClick: () => tab === "active" && onOpen(p.id)
              },
                React.createElement("td", null,
                  React.createElement("div", { className: "inv-name" }, p.name),
                  React.createElement("div", { className: "inv-gp" }, `${PI.fmt.mult(p.tvpi)} TVPI · NAV ${PI.fmt.money(p.nav)}`)
                ),
                React.createElement("td", null, React.createElement(AssetTypeChips, { byType: p.byType || { primary: p.funds }, compact: false })),
                React.createElement("td", { className: "num" }, PI.fmt.money(p.openCommitment || 0)),
                React.createElement("td", null, p.owner),
                React.createElement("td", null, p.updatedAt),
                React.createElement("td", { className: "num" },
                  tab === "active" ? React.createElement("button", {
                    className: "cf-link",
                    onClick: e => { e.stopPropagation(); onOpenSims(p); }
                  }, (p.simCount || 0), " runs") : (p.simCount || 0)
                ),
                React.createElement("td", { onClick: e => e.stopPropagation() },
                  React.createElement("div", { className: "row-actions", style: { opacity: 1 } },
                    tab === "active"
                      ? React.createElement(PI.Fragment, null,
                          React.createElement("button", { title: "Share", onClick: () => onToast("Share link copied") },
                            React.createElement(PI.Icon.Share, { size: 13 })),
                          React.createElement("button", { title: "Archive", onClick: () => onArchive(p) },
                            React.createElement(PI.Icon.Folder, { size: 13 }))
                        )
                      : React.createElement(PI.Fragment, null,
                          React.createElement("button", { title: "Restore",
                            onClick: () => onRestore(p) },
                            React.createElement(PI.Icon.ArrowRight, { size: 13 })),
                          React.createElement("button", { title: "Permanently delete", className: "is-danger",
                            onClick: () => onDelete(p) },
                            React.createElement(PI.Icon.Trash, { size: 13 }))
                        )
                  )
                )
              );
            })
          )
        )
      )
    )
  );
}

window.PI.PortfoliosPage = PortfoliosPage;
