/* Results page — Monte Carlo simulation outcomes.

   Layout (all sections always visible, organized with a sticky section nav):
     Page head → hero v2
     Sticky section nav (Cashflows · Composition · Distributions · Violins · Detail)
     Section: Cashflows          (always)
     Section: Composition        (always)
     Section: Distributions      (simulation only — TVPI density + per-year prob)
     Section: Comparison / Violins (simulation only — 4 per-metric violin cards)
     Section: Detail             (always — year-by-year table)
*/

// Page-level vehicle scope picker — button that opens a popover containing
// the LiquidityTree. Picking a vehicle re-scopes both Performance and
// Liquidity tabs. Picking "Whole portfolio" clears the scope.
function VehicleScopePicker({ value, onChange }) {
  const [open, setOpen] = PI.useState(false);
  const ref = PI.useClickOutside(() => setOpen(false));
  const v = value && PI_DATA.vehicleById ? PI_DATA.vehicleById(value) : null;
  const label = v ? `${v.id} · ${v.name}` : "Whole portfolio";
  return React.createElement("div", { ref, className: "vsp-wrap" },
    React.createElement("button", {
      type: "button",
      className: `vsp-btn${open ? " is-open" : ""}`,
      onClick: () => setOpen(o => !o),
      title: "Change vehicle scope"
    },
      React.createElement(PI.Icon.Layers, { size: 13 }),
      React.createElement("span", { className: "vsp-btn-lbl" }, "Vehicle:"),
      React.createElement("span", { className: "vsp-btn-val" }, label),
      React.createElement(PI.Icon.ChevronDown, { size: 12, className: "vsp-btn-caret" })
    ),
    open && React.createElement("div", { className: "vsp-popover" },
      React.createElement("div", { className: "vsp-popover-head" },
        React.createElement("div", { className: "eyebrow" }, "Vehicle scope"),
        React.createElement("div", { className: "vsp-popover-sub" },
          "Pick a vehicle to scope the results, or view the whole portfolio.")
      ),
      React.createElement("button", {
        type: "button",
        className: `vsp-portfolio-row${value == null ? " is-active" : ""}`,
        onClick: () => { onChange(null); setOpen(false); }
      },
        React.createElement(PI.Icon.Target, { size: 12 }),
        React.createElement("span", null, "Whole portfolio"),
        value == null && React.createElement(PI.Icon.Check, { size: 12, className: "vsp-portfolio-check" })
      ),
      PI.LiquidityTree && React.createElement("div", { className: "vsp-tree-wrap" },
        React.createElement(PI.LiquidityTree, {
          selectedId: value,
          onSelect: (id) => {
            if (!id) return;
            if (String(id).startsWith("CL-")) { onChange(null); setOpen(false); return; }
            onChange(id);
            setOpen(false);
          },
          funds: PI_DATA.FUNDS || []
        })
      )
    )
  );
}

function ResultsPage({ portfolio, funds, config, onDone, onShowModal, onToast, embedded }) {
  const cfg = config || {};
  const isSimulation = cfg.type === "simulation";
  const isImmediate  = cfg.type === "immediate";
  // Crumb / title labels — three flavours: simulation, immediate forecast,
  // or a regular (deep) forecast. Distributions/violins sections are
  // gated on `isSimulation` only — both forecast variants exclude them.
  const crumbLabel = isImmediate ? "Immediate forecast results"
                  : isSimulation ? "Simulation results"
                  :                "Forecast results";
  const titleFallback = isImmediate ? "Immediate forecast"
                     : isSimulation ? "Simulation"
                     :                "Forecast";

  const [activeSection, setActiveSection] = PI.useState("cashflows");
  // Top-level tab: Performance vs Liquidity Management. Unifies both result
  // sets into a single page (per user request — see CLAUDE.md / checklist).
  const [topTab, setTopTab] = PI.useState("performance");
  // Vehicle scope — null = whole portfolio (Performance shows the aggregate
  // forecast; Liquidity falls back to its own default vehicle). When set,
  // both tabs re-render scoped to the chosen vehicle.
  const [selectedVehicleId, setSelectedVehicleId] = PI.useState(null);

  // Demo KPIs consumed by SimDistributionsSection (TVPI density chart).
  const kpis = { meanTvpi: 1.90, p10: 1.34, p90: 2.50 };

  // Scoped portfolio shim for fcBuildForecast — when a vehicle is picked we
  // change the seed (id) and scale (committed) so the synthesized forecast
  // visibly differs per vehicle. When nothing is picked we use the portfolio
  // as-is (aggregate behavior, unchanged).
  const scopedPortfolio = PI.useMemo(() => {
    if (!selectedVehicleId) return portfolio;
    const v = PI_DATA.vehicleById && PI_DATA.vehicleById(selectedVehicleId);
    if (!v) return portfolio;
    const agg = PI_DATA.aggregateVehicleValue
      ? PI_DATA.aggregateVehicleValue(selectedVehicleId)
      : 0;
    return Object.assign({}, portfolio, {
      id: selectedVehicleId,
      name: v.name,
      committed: agg > 0 ? agg * 1.6 : portfolio.committed
    });
  }, [portfolio, selectedVehicleId]);

  const forecastData = PI.useMemo(
    () => (PI.fcBuildForecast ? PI.fcBuildForecast(scopedPortfolio) : null),
    [scopedPortfolio?.id]
  );

  const sections = [
    { key: "cashflows",     num: "01",                       label: "Cashflows",     show: true },
    { key: "composition",   num: "02",                       label: "Composition",   show: true },
    { key: "distributions", num: "03",                       label: "Distributions", show: isSimulation },
    { key: "violins",       num: "04",                       label: "Violin plots",  show: isSimulation },
    { key: "detail",        num: isSimulation ? "05" : "03", label: "Detail",        show: true },
  ].filter(s => s.show);

  // Smooth scroll to a section and mark it active. `.res-section` uses
  // scroll-margin-top so the sticky nav never overlaps the section head.
  const jumpTo = (key) => {
    setActiveSection(key);
    const el = document.getElementById("section-" + key);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  // Light-weight scroll spy — updates activeSection as the user scrolls.
  PI.useEffect(() => {
    const handler = () => {
      let current = sections[0]?.key;
      for (const s of sections) {
        const el = document.getElementById("section-" + s.key);
        if (!el) continue;
        const top = el.getBoundingClientRect().top;
        if (top - 120 <= 0) current = s.key;
      }
      if (current && current !== activeSection) setActiveSection(current);
    };
    window.addEventListener("scroll", handler, { passive: true });
    handler(); // sync initial state in case page loads scrolled
    return () => window.removeEventListener("scroll", handler);
  }, [sections.map(s => s.key).join(","), activeSection]);

  // ---- Page head ----
  // Crumb → title (with inline Share/Download icons) → primary action.
  // Meta line (iterations · investments · completed) intentionally omitted —
  // those facts are already conveyed by the crumb + hero headline.
  const pageHead = React.createElement("div", { className: "page-head" },
    React.createElement("div", null,
      React.createElement("div", { className: "page-crumb" },
        React.createElement("a", { href: "#", onClick: e => { e.preventDefault(); onDone(); } }, "Portfolios"),
        React.createElement(PI.Icon.ChevronRight, { size: 12, className: "sep" }),
        React.createElement("span", null, portfolio.name),
        React.createElement(PI.Icon.ChevronRight, { size: 12, className: "sep" }),
        React.createElement("span", null, crumbLabel)
      ),
      React.createElement("h1", { className: "page-title" },
        React.createElement("span", null, cfg.name || titleFallback),
        React.createElement("span", { className: "page-title-actions" },
          React.createElement(PI.IconBtn, {
            icon: React.createElement(PI.Icon.Share, { size: 14 }),
            title: "Share results",
            onClick: () => onToast("Share link copied", "ok")
          }),
          React.createElement(PI.IconBtn, {
            icon: React.createElement(PI.Icon.Download, { size: 14 }),
            title: "Export report",
            onClick: () => onToast("Exporting results…", "ok")
          })
        )
      )
    ),
    React.createElement("div", { className: "head-actions" },
      React.createElement(VehicleScopePicker, {
        value: selectedVehicleId,
        onChange: setSelectedVehicleId
      }),
      React.createElement(PI.Btn, { kind: "primary", icon: React.createElement(PI.Icon.ArrowRight, { size: 13 }),
        onClick: onDone }, "Back to portfolio")
    )
  );

  // ---- Sticky anchor nav ----
  const sectionNav = React.createElement("nav", { className: "res-anchor-nav" },
    React.createElement("div", { className: "res-anchor-nav-inner" },
      sections.map(s => React.createElement("button", {
        key: s.key,
        className: "res-anchor-item" + (activeSection === s.key ? " is-active" : ""),
        onClick: () => jumpTo(s.key)
      },
        React.createElement("span", { className: "res-anchor-num" }, s.num),
        React.createElement("span", { className: "res-anchor-text" },
          React.createElement("span", { className: "res-anchor-lbl" }, s.label)
        )
      ))
    )
  );

  // ---- Section wrapper helper ----
  const makeSection = (key, num, title, content) => React.createElement("section", {
    id: "section-" + key,
    className: "res-section"
  },
    React.createElement("header", { className: "res-section-head" },
      React.createElement("div", { className: "res-section-num" }, num),
      React.createElement("div", { className: "res-section-text" },
        React.createElement("h2", { className: "res-section-title" }, title)
      )
    ),
    React.createElement("div", { className: "res-section-body" }, content)
  );

  // ---- All sections ----
  const sectionsBlock = forecastData && React.createElement("div", { className: "res-sections" },
    makeSection("cashflows", "01", "Cashflows",
      PI.FCCashflowsSection && React.createElement(PI.FCCashflowsSection, {
        data: forecastData, showUncertainty: isSimulation
      })
    ),
    makeSection("composition", "02", "Composition",
      PI.FCCompositionSection && React.createElement(PI.FCCompositionSection, {
        data: forecastData, showUncertainty: isSimulation
      })
    ),
    isSimulation && makeSection("distributions", "03", "Probability distributions",
      PI.SimDistributionsSection && React.createElement(PI.SimDistributionsSection, {
        data: forecastData, kpis
      })
    ),
    isSimulation && makeSection("violins", "04", "Violin plots",
      PI.SimComparisonSection && React.createElement(PI.SimComparisonSection, { data: forecastData })
    ),
    makeSection("detail", isSimulation ? "05" : "03", "Year-by-year detail",
      PI.FCDetailSection && React.createElement(PI.FCDetailSection, { data: forecastData })
    )
  );

  // ---- Unified tab bar (Performance ↔ Liquidity Management) ----
  // Available always; entry point sets initial tab via topTab state default.
  const unifiedTabs = !embedded && PI.UnifiedResultsTabs && React.createElement(PI.UnifiedResultsTabs, {
    active: topTab, onChange: setTopTab
  });

  // Performance content: existing ResultsPage body.
  const performanceBody = React.createElement(React.Fragment, null,
    sectionNav,
    sectionsBlock
  );

  // Liquidity content: rendered via PI.EmbeddedLiquidityPane. Vehicle scope
  // is owned by this page (VehicleScopePicker) and passed down — so the
  // picker drives both Performance and Liquidity tabs from a single place.
  const liquidityBody = PI.EmbeddedLiquidityPane
    ? React.createElement(PI.EmbeddedLiquidityPane, {
        portfolio, config: cfg, vehicleId: selectedVehicleId
      })
    : React.createElement("div", { style: { padding: 24, color: "var(--black-60)" } },
        "Liquidity Management view unavailable (module not loaded).");

  // When embedded, return only the body (no page head, no tabs).
  if (embedded) {
    return React.createElement("div", { className: "res-embedded" }, performanceBody);
  }

  return React.createElement("div", { className: "main-inner", "data-screen-label": "05 Results" },
    pageHead,
    unifiedTabs,
    topTab === "liquidity" ? liquidityBody : performanceBody
  );
}

window.PI.ResultsPage = ResultsPage;
