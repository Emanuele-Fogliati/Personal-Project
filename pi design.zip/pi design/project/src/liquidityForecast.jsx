/* Phase 3 — Immediate Forecast (Liquidity Management) — interactive.
   Self-contained: config modal + results view with a shared, interactive
   chart set (hover tooltips + collapsible per-chart data tables) plus a
   parent/child vehicle relationship explorer.

   Public exports on window.PI:
     LiquidityForecastConfigModal ({ vehicleId, onRun, onClose })
     LiquidityForecastResults     ({ forecast, onBack, onReconfigure })

   Also exposes PI.LiqCharts (chart components + helpers) for reuse by the
   Simulation view — the simulation renders the SAME chart set with data
   derived from a user-selected percentile.
*/

(function(){
  const { useState, useMemo, useEffect } = PI;
  const SPEC = PI_DATA.SPEC_ASSET_TYPES; // cash, bonds, stocks, etfs, hedge_funds, secondary_funds, primary_funds

  // ============ Formatting helpers ============
  function specLabel(k) {
    return PI_DATA.assetTypeMeta(PI_DATA.SPEC_TO_INTERNAL[k]).label;
  }
  function specColor(k) {
    return PI_DATA.assetTypeMeta(PI_DATA.SPEC_TO_INTERNAL[k]).color;
  }
  function fmtMoney(v) {
    const n = Number(v) || 0;
    const abs = Math.abs(n);
    if (abs >= 1000) return `${n < 0 ? "-" : ""}$${(Math.abs(n)/1000).toFixed(2)}B`;
    if (abs >= 1)    return `${n < 0 ? "-" : ""}$${Math.abs(n).toFixed(1)}M`;
    return `${n < 0 ? "-" : ""}$${Math.abs(n).toFixed(2)}M`;
  }
  function fmtPct(v) { return `${(Number(v) || 0).toFixed(1)}%`; }
  function fmtDate(iso) {
    if (!iso) return "";
    // Bare "YYYY" period — display as-is.
    if (iso.length === 4) return iso;
    // Year-end markers from the annual aggregator ("YYYY-12-31") → "YYYY".
    if (iso.length >= 10 && iso.slice(5, 10) === "12-31") return iso.slice(0, 4);
    // Otherwise "2026-04-01" → "Apr 2026".
    if (iso.length < 7) return iso;
    const y = iso.slice(0, 4), m = Number(iso.slice(5, 7));
    const mos = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return `${mos[m-1] || ""} ${y}`;
  }

  // Short description shown beneath each per-asset bar chart.
  const ASSET_DESCRIPTIONS = {
    bonds:           "Fixed-income bonds (corporate, government). Liquid, t+1-3 settlement.",
    stocks:          "Listed equity holdings. Liquid, t+1-3 settlement.",
    etfs:            "Exchange-traded funds. Basket exposure, t+1-3 settlement.",
    hedge_funds:     "Absolute-return strategies. Gated redemption windows.",
    secondary_funds: "Secondary PE positions. Multi-year hold, discount-to-NAV entry.",
    primary_funds:   "Primary PE commitments. Driven by capital calls and distributions."
  };
  function niceMax(v) {
    if (v <= 0) return 10;
    const mag = Math.pow(10, Math.floor(Math.log10(v)));
    const n = v / mag;
    const r = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
    return r * mag;
  }
  function yearLabel(period) { return period.slice(0, 4); }

  // ============ Reusable hover helper ============
  // Tracks the hover index (nearest data point) for an interactive chart.
  // handleMove / handleLeave attach to the outer SVG wrap (<div>).
  function makeChartHover(n, W, PAD_L, PAD_R, setIdx) {
    const iw = W - PAD_L - PAD_R;
    return {
      handleMove: (e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        if (rect.width <= 0) return;
        const ratio = W / rect.width;
        const sx = (e.clientX - rect.left) * ratio;
        if (sx < PAD_L - 4 || sx > W - PAD_R + 4) { setIdx(null); return; }
        const t = iw > 0 ? (sx - PAD_L) / iw : 0;
        const i = Math.round(t * (n - 1));
        setIdx(Math.max(0, Math.min(n - 1, i)));
      },
      handleLeave: () => setIdx(null)
    };
  }

  // Positioned tooltip — flips to the opposite side when near the right edge.
  function Tooltip({ xPct, children }) {
    const isRight = xPct > 55;
    return React.createElement("div", {
      className: `liq-fc-tt ${isRight ? "is-right" : ""}`,
      style: { left: `${xPct}%` }
    }, children);
  }

  // ============ Chart 1: Total Portfolio Value Over Time ============
  function ChartValue({ periods, titleSuffix }) {
    const W = 640, H = 240, PAD_L = 54, PAD_R = 14, PAD_T = 14, PAD_B = 30;
    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const values = periods.map(p => p.end_value);
    const vMax = niceMax(Math.max(...values, 1));
    const vMin = 0;
    const n = periods.length;
    const xAt = i => PAD_L + (n <= 1 ? iw / 2 : (i / (n - 1)) * iw);
    const yAt = v => PAD_T + ih - ((v - vMin) / (vMax - vMin)) * ih;
    const pts = periods.map((p, i) => `${xAt(i)},${yAt(p.end_value)}`).join(" ");
    const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => vMin + f * (vMax - vMin));
    // Axis tick labels: include every annual period (p.period === "YYYY")
    // as well as any monthly period anchored on Jan-01 plus first/last.
    const yearStarts = periods.map((p, i) => ({ p, i })).filter(({ p, i }) =>
      p.period.length === 4 || p.period.endsWith("-01") || i === 0 || i === periods.length - 1
    );

    const [hoverIdx, setHoverIdx] = useState(null);
    const { handleMove, handleLeave } = makeChartHover(n, W, PAD_L, PAD_R, setHoverIdx);

    const peakIdx = values.indexOf(Math.max(...values));
    const curP = hoverIdx !== null ? periods[hoverIdx] : null;
    const prevP = hoverIdx !== null && hoverIdx > 0 ? periods[hoverIdx - 1] : null;
    const delta = curP && prevP ? curP.end_value - prevP.end_value : null;
    const vs0   = curP ? curP.end_value - values[0] : null;

    return React.createElement("div", { className: "liq-fc-chart" },
      React.createElement("div", { className: "liq-fc-chart-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "liq-fc-chart-title" },
            "Total portfolio value over time" + (titleSuffix ? ` · ${titleSuffix}` : "")
          ),
          React.createElement("div", { className: "liq-fc-chart-sub" },
            "Hover the chart to inspect any period."
          )
        )
      ),
      React.createElement("div", {
        className: "liq-fc-svg-wrap",
        onMouseMove: handleMove, onMouseLeave: handleLeave
      },
        React.createElement("svg", { className: "liq-fc-svg", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Portfolio value line chart" },
          ticks.map((t, i) => React.createElement("g", { key: i },
            React.createElement("line", { x1: PAD_L, x2: W - PAD_R, y1: yAt(t), y2: yAt(t), className: "liq-fc-grid" }),
            React.createElement("text", { x: PAD_L - 6, y: yAt(t) + 3, textAnchor: "end", className: "liq-fc-axis" }, fmtMoney(t))
          )),
          yearStarts.map(({ p, i }) => React.createElement("text", {
            key: i, x: xAt(i), y: H - 10, textAnchor: "middle", className: "liq-fc-axis"
          }, yearLabel(p.period))),
          React.createElement("polyline", { points: pts, fill: "none", stroke: "#2196F3", strokeWidth: 2 }),
          // Peak marker
          peakIdx >= 0 && React.createElement("circle", {
            cx: xAt(peakIdx), cy: yAt(values[peakIdx]), r: 3, fill: "#D89B2A", stroke: "#fff", strokeWidth: 1.5
          }, React.createElement("title", null, `Peak: ${fmtMoney(values[peakIdx])} at ${periods[peakIdx].period}`)),
          // Hover line + dot
          hoverIdx !== null && React.createElement("line", {
            x1: xAt(hoverIdx), x2: xAt(hoverIdx), y1: PAD_T, y2: PAD_T + ih,
            stroke: "var(--ink)", strokeWidth: 1, strokeDasharray: "2 3", opacity: 0.55
          }),
          hoverIdx !== null && React.createElement("circle", {
            cx: xAt(hoverIdx), cy: yAt(periods[hoverIdx].end_value),
            r: 4, fill: "#2196F3", stroke: "#fff", strokeWidth: 2
          })
        ),
        hoverIdx !== null && curP && React.createElement(Tooltip, {
          xPct: xAt(hoverIdx) / W * 100
        },
          React.createElement("div", { className: "liq-fc-tt-head" }, fmtDate(curP.date)),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "Portfolio value"),
            React.createElement("strong", null, fmtMoney(curP.end_value))
          ),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "vs. start"),
            React.createElement("span", {
              className: vs0 >= 0 ? "liq-fc-tt-pos" : "liq-fc-tt-neg"
            }, `${vs0 >= 0 ? "+" : ""}${fmtMoney(vs0)}`)
          ),
          delta !== null && React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "vs. prev"),
            React.createElement("span", {
              className: delta >= 0 ? "liq-fc-tt-pos" : "liq-fc-tt-neg"
            }, `${delta >= 0 ? "+" : ""}${fmtMoney(delta)}`)
          ),
          curP.rebalancing_occurred && React.createElement("div", { className: "liq-fc-tt-tag" }, "Rebalanced")
        )
      ),
      React.createElement("div", { className: "liq-fc-chart-table-wrap" },
        React.createElement("table", { className: "liq-fc-chart-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              ["Period","Portfolio value","Δ vs. prev","vs. start"].map((h, i) =>
                React.createElement("th", { key: i }, h))
            )
          ),
          React.createElement("tbody", null,
            periods.map((p, i) => {
              const d = i > 0 ? p.end_value - periods[i-1].end_value : 0;
              const v0 = p.end_value - values[0];
              return React.createElement("tr", { key: i },
                React.createElement("td", null, p.period),
                React.createElement("td", null, fmtMoney(p.end_value)),
                React.createElement("td", { className: d >= 0 ? "num-pos" : "num-neg" },
                  i === 0 ? "–" : `${d >= 0 ? "+" : ""}${fmtMoney(d)}`),
                React.createElement("td", { className: v0 >= 0 ? "num-pos" : "num-neg" },
                  `${v0 >= 0 ? "+" : ""}${fmtMoney(v0)}`)
              );
            })
          )
        )
      )
    );
  }

  // ============ Chart 2: Cash Balance Over Time ============
  function ChartCash({ periods, minCashTarget, titleSuffix }) {
    const W = 640, H = 240, PAD_L = 54, PAD_R = 14, PAD_T = 14, PAD_B = 30;
    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const vals = periods.map(p => p.cash_balance);
    const rawMax = Math.max(...vals, minCashTarget || 0, 1);
    const rawMin = Math.min(...vals, 0);
    const vMax = niceMax(rawMax);
    const vMin = rawMin < 0 ? -niceMax(-rawMin) : 0;
    const n = periods.length;
    const xAt = i => PAD_L + (n <= 1 ? iw / 2 : (i / (n - 1)) * iw);
    const yAt = v => PAD_T + ih - ((v - vMin) / (vMax - vMin)) * ih;
    const pts = periods.map((p, i) => `${xAt(i)},${yAt(p.cash_balance)}`).join(" ");
    const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => vMin + f * (vMax - vMin));
    // Axis tick labels: include every annual period (p.period === "YYYY")
    // as well as any monthly period anchored on Jan-01 plus first/last.
    const yearStarts = periods.map((p, i) => ({ p, i })).filter(({ p, i }) =>
      p.period.length === 4 || p.period.endsWith("-01") || i === 0 || i === periods.length - 1
    );
    const zeroY = yAt(0);
    const targetY = minCashTarget > 0 ? yAt(minCashTarget) : null;

    const [hoverIdx, setHoverIdx] = useState(null);
    const { handleMove, handleLeave } = makeChartHover(n, W, PAD_L, PAD_R, setHoverIdx);

    const insolvencyCount = vals.filter(v => v < 0).length;
    const curP = hoverIdx !== null ? periods[hoverIdx] : null;

    return React.createElement("div", { className: "liq-fc-chart" },
      React.createElement("div", { className: "liq-fc-chart-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "liq-fc-chart-title" },
            "Cash balance over time" + (titleSuffix ? ` · ${titleSuffix}` : "")
          ),
          React.createElement("div", { className: "liq-fc-chart-sub" },
            insolvencyCount > 0
              ? `⚠ ${insolvencyCount} period${insolvencyCount === 1 ? "" : "s"} with cash below $0 (insolvency risk).`
              : (minCashTarget > 0
                  ? `Dashed line marks the ${fmtMoney(minCashTarget)} minimum target.`
                  : "No minimum-cash target on this strategy.")
          )
        )
      ),
      React.createElement("div", {
        className: "liq-fc-svg-wrap",
        onMouseMove: handleMove, onMouseLeave: handleLeave
      },
        React.createElement("svg", { className: "liq-fc-svg", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Cash balance line chart" },
          vMin < 0 && React.createElement("rect", {
            x: PAD_L, y: zeroY, width: iw, height: (PAD_T + ih) - zeroY, fill: "#FDECEC", opacity: 0.6
          }),
          targetY !== null && React.createElement("rect", {
            x: PAD_L, y: PAD_T, width: iw, height: targetY - PAD_T, fill: "#E4F3F2", opacity: 0.5
          }),
          ticks.map((t, i) => React.createElement("g", { key: i },
            React.createElement("line", { x1: PAD_L, x2: W - PAD_R, y1: yAt(t), y2: yAt(t), className: "liq-fc-grid" }),
            React.createElement("text", { x: PAD_L - 6, y: yAt(t) + 3, textAnchor: "end", className: "liq-fc-axis" }, fmtMoney(t))
          )),
          targetY !== null && React.createElement("line", {
            x1: PAD_L, x2: W - PAD_R, y1: targetY, y2: targetY,
            stroke: "#4CAF50", strokeWidth: 1.5, strokeDasharray: "5 4"
          }),
          vMin < 0 && React.createElement("line", {
            x1: PAD_L, x2: W - PAD_R, y1: zeroY, y2: zeroY, stroke: "#F44336", strokeWidth: 1.5
          }),
          yearStarts.map(({ p, i }) => React.createElement("text", {
            key: i, x: xAt(i), y: H - 10, textAnchor: "middle", className: "liq-fc-axis"
          }, yearLabel(p.period))),
          React.createElement("polyline", { points: pts, fill: "none", stroke: "#4CAF50", strokeWidth: 2 }),
          hoverIdx !== null && React.createElement("line", {
            x1: xAt(hoverIdx), x2: xAt(hoverIdx), y1: PAD_T, y2: PAD_T + ih,
            stroke: "var(--ink)", strokeWidth: 1, strokeDasharray: "2 3", opacity: 0.55
          }),
          hoverIdx !== null && React.createElement("circle", {
            cx: xAt(hoverIdx), cy: yAt(periods[hoverIdx].cash_balance),
            r: 4, fill: periods[hoverIdx].cash_balance < 0 ? "#F44336" : "#4CAF50",
            stroke: "#fff", strokeWidth: 2
          })
        ),
        hoverIdx !== null && curP && React.createElement(Tooltip, {
          xPct: xAt(hoverIdx) / W * 100
        },
          React.createElement("div", { className: "liq-fc-tt-head" }, fmtDate(curP.date)),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "Cash balance"),
            React.createElement("strong", { className: curP.cash_balance < 0 ? "liq-fc-tt-neg" : null },
              fmtMoney(curP.cash_balance))
          ),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "Net cashflow"),
            React.createElement("span", {
              className: curP.net_cashflow >= 0 ? "liq-fc-tt-pos" : "liq-fc-tt-neg"
            }, `${curP.net_cashflow >= 0 ? "+" : ""}${fmtMoney(curP.net_cashflow)}`)
          ),
          minCashTarget > 0 && React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "vs. target"),
            React.createElement("span", {
              className: curP.cash_balance >= minCashTarget ? "liq-fc-tt-pos" : "liq-fc-tt-neg"
            }, `${curP.cash_balance - minCashTarget >= 0 ? "+" : ""}${fmtMoney(curP.cash_balance - minCashTarget)}`)
          ),
          curP.cash_balance < 0 && React.createElement("div", { className: "liq-fc-tt-tag is-bad" }, "Insolvency risk")
        )
      ),
      React.createElement("div", { className: "liq-fc-chart-table-wrap" },
        React.createElement("table", { className: "liq-fc-chart-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              ["Period","Cash balance","Net cashflow","vs. target"].map((h, i) =>
                React.createElement("th", { key: i }, h))
            )
          ),
          React.createElement("tbody", null,
            periods.map((p, i) => {
              const vsT = p.cash_balance - (minCashTarget || 0);
              return React.createElement("tr", { key: i, className: p.cash_balance < 0 ? "is-insolv" : null },
                React.createElement("td", null, p.period),
                React.createElement("td", { className: p.cash_balance < 0 ? "num-neg" : null }, fmtMoney(p.cash_balance)),
                React.createElement("td", { className: p.net_cashflow >= 0 ? "num-pos" : "num-neg" },
                  `${p.net_cashflow >= 0 ? "+" : ""}${fmtMoney(p.net_cashflow)}`),
                React.createElement("td", { className: vsT >= 0 ? "num-pos" : "num-neg" },
                  minCashTarget > 0 ? `${vsT >= 0 ? "+" : ""}${fmtMoney(vsT)}` : "–")
              );
            })
          )
        )
      )
    );
  }

  // ============ Chart 3: Non-Cash Assets Over Time ============
  // Six non-cash asset types as individual lines (absolute $ value).
  function ChartNonCashAssets({ periods, titleSuffix }) {
    const NON_CASH = SPEC.filter(k => k !== "cash"); // 6 asset types
    const W = 640, H = 260, PAD_L = 54, PAD_R = 14, PAD_T = 14, PAD_B = 46;
    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const n = periods.length;
    const seriesByKey = {};
    let gMax = 1;
    NON_CASH.forEach(k => {
      seriesByKey[k] = periods.map(p => (p.asset_allocation_value && p.asset_allocation_value[k]) || 0);
      seriesByKey[k].forEach(v => { if (v > gMax) gMax = v; });
    });
    const vMax = niceMax(gMax);
    const xAt = i => PAD_L + (n <= 1 ? iw / 2 : (i / (n - 1)) * iw);
    const yAt = v => PAD_T + ih - (v / vMax) * ih;
    const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => f * vMax);
    // Axis tick labels: include every annual period (p.period === "YYYY")
    // as well as any monthly period anchored on Jan-01 plus first/last.
    const yearStarts = periods.map((p, i) => ({ p, i })).filter(({ p, i }) =>
      p.period.length === 4 || p.period.endsWith("-01") || i === 0 || i === periods.length - 1
    );

    const [hoverIdx, setHoverIdx] = useState(null);
    const [hidden, setHidden] = useState({}); // assetKey → true if hidden
    const { handleMove, handleLeave } = makeChartHover(n, W, PAD_L, PAD_R, setHoverIdx);
    const toggleSeries = (k) => setHidden(h => ({ ...h, [k]: !h[k] }));

    return React.createElement("div", { className: "liq-fc-chart" },
      React.createElement("div", { className: "liq-fc-chart-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "liq-fc-chart-title" },
            "Non-cash assets over time" + (titleSuffix ? ` · ${titleSuffix}` : "")
          ),
          React.createElement("div", { className: "liq-fc-chart-sub" },
            "Click legend items to toggle lines. Hover for per-asset values."
          )
        )
      ),
      React.createElement("div", {
        className: "liq-fc-svg-wrap",
        onMouseMove: handleMove, onMouseLeave: handleLeave
      },
        React.createElement("svg", { className: "liq-fc-svg", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Non-cash assets line chart" },
          ticks.map((t, i) => React.createElement("g", { key: i },
            React.createElement("line", { x1: PAD_L, x2: W - PAD_R, y1: yAt(t), y2: yAt(t), className: "liq-fc-grid" }),
            React.createElement("text", { x: PAD_L - 6, y: yAt(t) + 3, textAnchor: "end", className: "liq-fc-axis" }, fmtMoney(t))
          )),
          yearStarts.map(({ p, i }) => React.createElement("text", {
            key: i, x: xAt(i), y: H - 28, textAnchor: "middle", className: "liq-fc-axis"
          }, yearLabel(p.period))),
          NON_CASH.map(k => {
            if (hidden[k]) return null;
            const series = seriesByKey[k];
            const pts = series.map((v, i) => `${xAt(i)},${yAt(v)}`).join(" ");
            return React.createElement("polyline", {
              key: k, points: pts, fill: "none",
              stroke: specColor(k), strokeWidth: 1.6, opacity: 0.9
            });
          }),
          hoverIdx !== null && React.createElement("line", {
            x1: xAt(hoverIdx), x2: xAt(hoverIdx), y1: PAD_T, y2: PAD_T + ih,
            stroke: "var(--ink)", strokeWidth: 1, strokeDasharray: "2 3", opacity: 0.55
          }),
          hoverIdx !== null && NON_CASH.map(k => {
            if (hidden[k]) return null;
            return React.createElement("circle", {
              key: k, cx: xAt(hoverIdx), cy: yAt(seriesByKey[k][hoverIdx]),
              r: 3.2, fill: specColor(k), stroke: "#fff", strokeWidth: 1.5
            });
          })
        ),
        hoverIdx !== null && React.createElement(Tooltip, {
          xPct: xAt(hoverIdx) / W * 100
        },
          React.createElement("div", { className: "liq-fc-tt-head" }, fmtDate(periods[hoverIdx].date)),
          NON_CASH.filter(k => !hidden[k]).map(k => React.createElement("div", { key: k, className: "liq-fc-tt-row" },
            React.createElement("span", null,
              React.createElement("span", { className: "liq-fc-tt-swatch", style: { background: specColor(k) } }),
              specLabel(k)
            ),
            React.createElement("strong", null, fmtMoney(seriesByKey[k][hoverIdx]))
          ))
        )
      ),
      React.createElement("div", { className: "liq-fc-legend" },
        NON_CASH.map(k => React.createElement("button", {
          key: k, type: "button",
          className: `liq-fc-legend-item is-toggle ${hidden[k] ? "is-off" : ""}`,
          onClick: () => toggleSeries(k)
        },
          React.createElement("span", { className: "liq-fc-legend-swatch", style: { background: specColor(k) } }),
          React.createElement("span", null, specLabel(k))
        ))
      ),
      React.createElement("div", { className: "liq-fc-chart-table-wrap" },
        React.createElement("table", { className: "liq-fc-chart-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              React.createElement("th", null, "Period"),
              NON_CASH.map(k => React.createElement("th", { key: k }, specLabel(k)))
            )
          ),
          React.createElement("tbody", null,
            periods.map((p, i) => React.createElement("tr", { key: i },
              React.createElement("td", null, p.period),
              NON_CASH.map(k => React.createElement("td", { key: k }, fmtMoney(seriesByKey[k][i])))
            ))
          )
        )
      )
    );
  }

  // ============ Chart 3b: Per-Asset Bar Chart (one chart per non-cash type) ============
  // Renders a single non-cash asset type as annual bars, with description,
  // hover tooltip, and always-open data table. Rendered in a 2-column grid by
  // `ChartsNonCashPerAsset`.
  function ChartPerAssetBar({ assetKey, periods, titleSuffix }) {
    const W = 480, H = 220, PAD_L = 56, PAD_R = 14, PAD_T = 14, PAD_B = 30;
    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const n = periods.length;
    const series = periods.map(p => (p.asset_allocation_value && p.asset_allocation_value[assetKey]) || 0);
    const totals = periods.map(p => {
      const av = p.asset_allocation_value || {};
      return SPEC.reduce((s, k) => s + (av[k] || 0), 0);
    });
    const shares = series.map((v, i) => totals[i] > 0 ? (v / totals[i]) * 100 : 0);
    const vMax = niceMax(Math.max(...series, 1));
    const groupW = iw / Math.max(n, 1);
    const barW = Math.max(6, groupW - 8);
    const xAt = i => PAD_L + i * groupW + groupW / 2;
    const yAt = v => PAD_T + ih - (v / vMax) * ih;
    const zeroY = PAD_T + ih;
    const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => f * vMax);
    const color = specColor(assetKey);
    const label = specLabel(assetKey);
    const desc = ASSET_DESCRIPTIONS[assetKey] || "";
    const labelStep = n > 10 ? Math.ceil(n / 8) : 1;

    const [hoverIdx, setHoverIdx] = useState(null);
    const handleMove = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      if (rect.width <= 0) return;
      const ratio = W / rect.width;
      const sx = (e.clientX - rect.left) * ratio;
      if (sx < PAD_L || sx > W - PAD_R) { setHoverIdx(null); return; }
      const i = Math.max(0, Math.min(n - 1, Math.floor((sx - PAD_L) / groupW)));
      setHoverIdx(i);
    };
    const handleLeave = () => setHoverIdx(null);
    const cur = hoverIdx !== null ? periods[hoverIdx] : null;
    const curVal = hoverIdx !== null ? series[hoverIdx] : null;
    const prevVal = hoverIdx !== null && hoverIdx > 0 ? series[hoverIdx - 1] : null;
    const peakIdx = series.indexOf(Math.max(...series));

    return React.createElement("div", { className: "liq-fc-chart liq-fc-chart-per-asset" },
      React.createElement("div", { className: "liq-fc-chart-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "liq-fc-chart-title" },
            React.createElement("span", { className: "liq-fc-per-asset-swatch", style: { background: color } }),
            label + (titleSuffix ? ` · ${titleSuffix}` : "")
          ),
          React.createElement("div", { className: "liq-fc-chart-sub" }, desc)
        )
      ),
      React.createElement("div", {
        className: "liq-fc-svg-wrap",
        onMouseMove: handleMove, onMouseLeave: handleLeave
      },
        React.createElement("svg", { className: "liq-fc-svg", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": label + " annual bar chart" },
          ticks.map((t, i) => React.createElement("g", { key: i },
            React.createElement("line", { x1: PAD_L, x2: W - PAD_R, y1: yAt(t), y2: yAt(t), className: "liq-fc-grid" }),
            React.createElement("text", { x: PAD_L - 6, y: yAt(t) + 3, textAnchor: "end", className: "liq-fc-axis" }, fmtMoney(t))
          )),
          // Bars
          periods.map((p, i) => {
            const v = series[i];
            const bx = PAD_L + i * groupW + (groupW - barW) / 2;
            const by = yAt(v);
            const bh = Math.max(0, zeroY - by);
            const faded = hoverIdx !== null && hoverIdx !== i;
            return React.createElement("rect", {
              key: i, x: bx, y: by, width: barW, height: bh,
              fill: color, opacity: faded ? 0.35 : 0.92, rx: 2
            });
          }),
          // Peak marker (triangle above the tallest bar)
          peakIdx >= 0 && series[peakIdx] > 0 && React.createElement("polygon", {
            points: `${xAt(peakIdx)},${yAt(series[peakIdx]) - 8} ${xAt(peakIdx) - 4},${yAt(series[peakIdx]) - 2} ${xAt(peakIdx) + 4},${yAt(series[peakIdx]) - 2}`,
            fill: "#D89B2A"
          }),
          // X-axis year labels
          periods.map((p, i) => (i % labelStep === 0 || i === n - 1) && React.createElement("text", {
            key: "lbl-" + i, x: xAt(i), y: H - 10, textAnchor: "middle", className: "liq-fc-axis"
          }, p.period))
        ),
        hoverIdx !== null && cur && React.createElement(Tooltip, {
          xPct: xAt(hoverIdx) / W * 100
        },
          React.createElement("div", { className: "liq-fc-tt-head" }, cur.period),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null,
              React.createElement("span", { className: "liq-fc-tt-swatch", style: { background: color } }),
              label
            ),
            React.createElement("strong", null, fmtMoney(curVal))
          ),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "Share of portfolio"),
            React.createElement("span", null, fmtPct(shares[hoverIdx]))
          ),
          prevVal !== null && React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "Δ vs. prev"),
            React.createElement("span", {
              className: (curVal - prevVal) >= 0 ? "liq-fc-tt-pos" : "liq-fc-tt-neg"
            }, `${(curVal - prevVal) >= 0 ? "+" : ""}${fmtMoney(curVal - prevVal)}`)
          ),
          peakIdx === hoverIdx && React.createElement("div", { className: "liq-fc-tt-tag" }, "Peak year")
        )
      ),
      React.createElement("div", { className: "liq-fc-chart-table-wrap" },
        React.createElement("table", { className: "liq-fc-chart-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              ["Year","Value","Share","Δ vs. prev"].map((h, i) =>
                React.createElement("th", { key: i }, h))
            )
          ),
          React.createElement("tbody", null,
            periods.map((p, i) => {
              const d = i > 0 ? series[i] - series[i-1] : 0;
              return React.createElement("tr", { key: i },
                React.createElement("td", null, p.period),
                React.createElement("td", null, fmtMoney(series[i])),
                React.createElement("td", null, fmtPct(shares[i])),
                React.createElement("td", { className: d >= 0 ? "num-pos" : "num-neg" },
                  i === 0 ? "–" : `${d >= 0 ? "+" : ""}${fmtMoney(d)}`)
              );
            })
          )
        )
      )
    );
  }

  // Grid wrapper: one bar chart per non-cash asset type (6 charts total).
  function ChartsNonCashPerAsset({ periods, titleSuffix }) {
    const NON_CASH = SPEC.filter(k => k !== "cash");
    return React.createElement("div", { className: "liq-fc-per-asset-grid" },
      NON_CASH.map(k => React.createElement(ChartPerAssetBar, {
        key: k, assetKey: k, periods, titleSuffix
      }))
    );
  }

  // ============ Chart 4: Asset Allocation Over Time (Stacked Area) ============
  function ChartAllocation({ periods, titleSuffix }) {
    const [mode, setMode] = useState("pct"); // "pct" | "value"
    const W = 640, H = 260, PAD_L = 54, PAD_R = 14, PAD_T = 14, PAD_B = 46;
    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const n = periods.length;
    const xAt = i => PAD_L + (n <= 1 ? iw / 2 : (i / (n - 1)) * iw);

    const values = SPEC.map(k => periods.map(p => (mode === "pct"
      ? (p.asset_allocation_pct && p.asset_allocation_pct[k])
      : (p.asset_allocation_value && p.asset_allocation_value[k])
    ) || 0));
    const stacks = values.map(() => new Array(n).fill(0));
    values.forEach((row, si) => row.forEach((v, pi) => {
      const prev = si > 0 ? stacks[si - 1][pi] : 0;
      stacks[si][pi] = prev + v;
    }));
    const vMax = mode === "pct" ? 100 : niceMax(Math.max(...stacks[stacks.length - 1], 1));
    const yAt = v => PAD_T + ih - (v / vMax) * ih;

    const paths = SPEC.map((k, si) => {
      const top = stacks[si];
      const bottom = si > 0 ? stacks[si - 1] : new Array(n).fill(0);
      const topPts = top.map((v, i) => `${xAt(i)},${yAt(v)}`).join(" L ");
      const botPts = bottom.slice().reverse().map((v, i) => `${xAt(n - 1 - i)},${yAt(v)}`).join(" L ");
      return { d: `M ${topPts} L ${botPts} Z`, color: specColor(k), label: specLabel(k), key: k };
    });
    const ticks = mode === "pct" ? [0, 25, 50, 75, 100] : [0, 0.25, 0.5, 0.75, 1].map(f => f * vMax);
    // Axis tick labels: include every annual period (p.period === "YYYY")
    // as well as any monthly period anchored on Jan-01 plus first/last.
    const yearStarts = periods.map((p, i) => ({ p, i })).filter(({ p, i }) =>
      p.period.length === 4 || p.period.endsWith("-01") || i === 0 || i === periods.length - 1
    );

    const [hoverIdx, setHoverIdx] = useState(null);
    const { handleMove, handleLeave } = makeChartHover(n, W, PAD_L, PAD_R, setHoverIdx);

    return React.createElement("div", { className: "liq-fc-chart" },
      React.createElement("div", { className: "liq-fc-chart-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "liq-fc-chart-title" },
            "Asset allocation over time" + (titleSuffix ? ` · ${titleSuffix}` : "")
          ),
          React.createElement("div", { className: "liq-fc-chart-sub" },
            "All 7 asset types stacked. Toggle % / $."
          )
        ),
        React.createElement("div", { className: "liq-fc-chart-tabs" },
          React.createElement("button", { type: "button", className: `pill ${mode === "pct" ? "is-active" : ""}`, onClick: () => setMode("pct") }, "%"),
          React.createElement("button", { type: "button", className: `pill ${mode === "value" ? "is-active" : ""}`, onClick: () => setMode("value") }, "$")
        )
      ),
      React.createElement("div", {
        className: "liq-fc-svg-wrap",
        onMouseMove: handleMove, onMouseLeave: handleLeave
      },
        React.createElement("svg", { className: "liq-fc-svg", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Asset allocation stacked area chart" },
          ticks.map((t, i) => React.createElement("g", { key: i },
            React.createElement("line", { x1: PAD_L, x2: W - PAD_R, y1: yAt(t), y2: yAt(t), className: "liq-fc-grid" }),
            React.createElement("text", { x: PAD_L - 6, y: yAt(t) + 3, textAnchor: "end", className: "liq-fc-axis" },
              mode === "pct" ? `${t.toFixed(0)}%` : fmtMoney(t))
          )),
          yearStarts.map(({ p, i }) => React.createElement("text", {
            key: i, x: xAt(i), y: H - 28, textAnchor: "middle", className: "liq-fc-axis"
          }, yearLabel(p.period))),
          paths.map(pt => React.createElement("path", {
            key: pt.key, d: pt.d, fill: pt.color, stroke: "#fff", strokeWidth: 0.5, opacity: 0.9
          })),
          hoverIdx !== null && React.createElement("line", {
            x1: xAt(hoverIdx), x2: xAt(hoverIdx), y1: PAD_T, y2: PAD_T + ih,
            stroke: "var(--ink)", strokeWidth: 1, strokeDasharray: "2 3", opacity: 0.55
          })
        ),
        hoverIdx !== null && React.createElement(Tooltip, {
          xPct: xAt(hoverIdx) / W * 100
        },
          React.createElement("div", { className: "liq-fc-tt-head" }, fmtDate(periods[hoverIdx].date)),
          SPEC.map(k => {
            const v = mode === "pct"
              ? (periods[hoverIdx].asset_allocation_pct && periods[hoverIdx].asset_allocation_pct[k]) || 0
              : (periods[hoverIdx].asset_allocation_value && periods[hoverIdx].asset_allocation_value[k]) || 0;
            return React.createElement("div", { key: k, className: "liq-fc-tt-row" },
              React.createElement("span", null,
                React.createElement("span", { className: "liq-fc-tt-swatch", style: { background: specColor(k) } }),
                specLabel(k)
              ),
              React.createElement("strong", null, mode === "pct" ? fmtPct(v) : fmtMoney(v))
            );
          })
        )
      ),
      React.createElement("div", { className: "liq-fc-legend" },
        SPEC.map(k => React.createElement("div", { key: k, className: "liq-fc-legend-item" },
          React.createElement("span", { className: "liq-fc-legend-swatch", style: { background: specColor(k) } }),
          React.createElement("span", null, specLabel(k))
        ))
      ),
      React.createElement("div", { className: "liq-fc-chart-table-wrap" },
        React.createElement("table", { className: "liq-fc-chart-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              React.createElement("th", null, "Period"),
              SPEC.map(k => React.createElement("th", { key: k }, specLabel(k)))
            )
          ),
          React.createElement("tbody", null,
            periods.map((p, i) => React.createElement("tr", { key: i },
              React.createElement("td", null, p.period),
              SPEC.map(k => {
                const v = mode === "pct"
                  ? (p.asset_allocation_pct && p.asset_allocation_pct[k]) || 0
                  : (p.asset_allocation_value && p.asset_allocation_value[k]) || 0;
                return React.createElement("td", { key: k },
                  mode === "pct" ? fmtPct(v) : fmtMoney(v));
              })
            ))
          )
        )
      )
    );
  }

  // ============ Chart 5: Capital Flows Over Time ============
  // Annual grouped bars: above axis = inflows (distributions, capital calls);
  // below axis = outflows (contributions, capital drawdowns).
  function ChartFlows({ periods, titleSuffix }) {
    const W = 640, H = 260, PAD_L = 54, PAD_R = 14, PAD_T = 14, PAD_B = 46;
    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const byYear = {};
    periods.forEach(p => {
      const y = p.period.slice(0, 4);
      const b = byYear[y] || { year: y, contrib: 0, distrib: 0, capCall: 0, capDraw: 0 };
      b.contrib += p.cashflow.contribution;
      b.distrib += p.cashflow.distribution;
      b.capCall += p.cashflow.capital_call;
      b.capDraw += p.cashflow.capital_drawdown;
      byYear[y] = b;
    });
    const rows = Object.values(byYear);
    const posMax = Math.max(...rows.map(r => Math.max(r.distrib, r.capCall)), 1);
    const negMax = Math.max(...rows.map(r => Math.max(r.contrib, r.capDraw)), 1);
    const vMax = niceMax(Math.max(posMax, negMax));
    const yAt = v => PAD_T + ih / 2 - (v / vMax) * (ih / 2);
    const zeroY = PAD_T + ih / 2;
    const n = rows.length;
    const groupW = iw / Math.max(n, 1);
    const barW = Math.max(3, (groupW - 6) / 4);

    const [hoverIdx, setHoverIdx] = useState(null);
    const handleMove = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      if (rect.width <= 0) return;
      const ratio = W / rect.width;
      const sx = (e.clientX - rect.left) * ratio;
      if (sx < PAD_L || sx > W - PAD_R) { setHoverIdx(null); return; }
      const i = Math.max(0, Math.min(n - 1, Math.floor((sx - PAD_L) / groupW)));
      setHoverIdx(i);
    };
    const handleLeave = () => setHoverIdx(null);
    const cur = hoverIdx !== null ? rows[hoverIdx] : null;
    const hoverX = hoverIdx !== null ? (PAD_L + hoverIdx * groupW + groupW / 2) : 0;

    return React.createElement("div", { className: "liq-fc-chart" },
      React.createElement("div", { className: "liq-fc-chart-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "liq-fc-chart-title" },
            "Capital flows over time" + (titleSuffix ? ` · ${titleSuffix}` : "")
          ),
          React.createElement("div", { className: "liq-fc-chart-sub" },
            "Annual totals. Above axis: inflows. Below axis: outflows."
          )
        )
      ),
      React.createElement("div", {
        className: "liq-fc-svg-wrap",
        onMouseMove: handleMove, onMouseLeave: handleLeave
      },
        React.createElement("svg", { className: "liq-fc-svg", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Capital flows grouped bar chart" },
          [-vMax, -vMax/2, 0, vMax/2, vMax].map((t, i) => React.createElement("g", { key: i },
            React.createElement("line", { x1: PAD_L, x2: W - PAD_R, y1: yAt(t), y2: yAt(t), className: "liq-fc-grid" }),
            React.createElement("text", { x: PAD_L - 6, y: yAt(t) + 3, textAnchor: "end", className: "liq-fc-axis" }, fmtMoney(t))
          )),
          React.createElement("line", { x1: PAD_L, x2: W - PAD_R, y1: zeroY, y2: zeroY, stroke: "var(--ink)", strokeWidth: 1 }),
          rows.map((r, i) => {
            const gx = PAD_L + i * groupW + 3;
            return React.createElement("g", { key: r.year },
              React.createElement("rect", { x: gx, y: yAt(r.distrib), width: barW, height: Math.max(0, zeroY - yAt(r.distrib)), fill: "#4CAF50" }),
              React.createElement("rect", { x: gx + barW, y: yAt(r.capCall), width: barW, height: Math.max(0, zeroY - yAt(r.capCall)), fill: "#7FCCC8" }),
              React.createElement("rect", { x: gx + 2 * barW, y: zeroY, width: barW, height: Math.max(0, yAt(-r.contrib) - zeroY), fill: "#2196F3" }),
              React.createElement("rect", { x: gx + 3 * barW, y: zeroY, width: barW, height: Math.max(0, yAt(-r.capDraw) - zeroY), fill: "#E5A36F" }),
              React.createElement("text", { x: gx + 2 * barW, y: H - 28, textAnchor: "middle", className: "liq-fc-axis" }, r.year)
            );
          }),
          hoverIdx !== null && React.createElement("rect", {
            x: PAD_L + hoverIdx * groupW, y: PAD_T,
            width: groupW, height: ih,
            fill: "var(--ink)", opacity: 0.06, pointerEvents: "none"
          })
        ),
        hoverIdx !== null && cur && React.createElement(Tooltip, {
          xPct: hoverX / W * 100
        },
          React.createElement("div", { className: "liq-fc-tt-head" }, cur.year),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null,
              React.createElement("span", { className: "liq-fc-tt-swatch", style: { background: "#4CAF50" } }),
              "Distributions"
            ),
            React.createElement("strong", { className: "liq-fc-tt-pos" }, `+${fmtMoney(cur.distrib)}`)
          ),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null,
              React.createElement("span", { className: "liq-fc-tt-swatch", style: { background: "#7FCCC8" } }),
              "Capital calls"
            ),
            React.createElement("strong", { className: "liq-fc-tt-pos" }, `+${fmtMoney(cur.capCall)}`)
          ),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null,
              React.createElement("span", { className: "liq-fc-tt-swatch", style: { background: "#2196F3" } }),
              "Contributions"
            ),
            React.createElement("strong", { className: "liq-fc-tt-neg" }, `-${fmtMoney(cur.contrib)}`)
          ),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null,
              React.createElement("span", { className: "liq-fc-tt-swatch", style: { background: "#E5A36F" } }),
              "Capital drawdowns"
            ),
            React.createElement("strong", { className: "liq-fc-tt-neg" }, `-${fmtMoney(cur.capDraw)}`)
          ),
          React.createElement("div", { className: "liq-fc-tt-row" },
            React.createElement("span", null, "Net"),
            React.createElement("strong", {
              className: (cur.distrib + cur.capCall - cur.contrib - cur.capDraw) >= 0 ? "liq-fc-tt-pos" : "liq-fc-tt-neg"
            }, `${(cur.distrib + cur.capCall - cur.contrib - cur.capDraw) >= 0 ? "+" : ""}${fmtMoney(cur.distrib + cur.capCall - cur.contrib - cur.capDraw)}`)
          )
        )
      ),
      React.createElement("div", { className: "liq-fc-legend" },
        [
          { label: "Distributions",      color: "#4CAF50" },
          { label: "Capital calls",      color: "#7FCCC8" },
          { label: "Contributions",      color: "#2196F3" },
          { label: "Capital drawdowns",  color: "#E5A36F" }
        ].map(it => React.createElement("div", { key: it.label, className: "liq-fc-legend-item" },
          React.createElement("span", { className: "liq-fc-legend-swatch", style: { background: it.color } }),
          React.createElement("span", null, it.label)
        ))
      ),
      React.createElement("div", { className: "liq-fc-chart-table-wrap" },
        React.createElement("table", { className: "liq-fc-chart-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              ["Year","Distributions","Capital calls","Contributions","Capital drawdowns","Net"].map((h, i) =>
                React.createElement("th", { key: i }, h))
            )
          ),
          React.createElement("tbody", null,
            rows.map((r, i) => {
              const net = r.distrib + r.capCall - r.contrib - r.capDraw;
              return React.createElement("tr", { key: i },
                React.createElement("td", null, r.year),
                React.createElement("td", { className: "num-pos" }, `+${fmtMoney(r.distrib)}`),
                React.createElement("td", { className: "num-pos" }, `+${fmtMoney(r.capCall)}`),
                React.createElement("td", { className: "num-neg" }, `-${fmtMoney(r.contrib)}`),
                React.createElement("td", { className: "num-neg" }, `-${fmtMoney(r.capDraw)}`),
                React.createElement("td", { className: net >= 0 ? "num-pos" : "num-neg" },
                  `${net >= 0 ? "+" : ""}${fmtMoney(net)}`)
              );
            })
          )
        )
      )
    );
  }

  // ============ KPI Cards (6 top-level metrics) ============
  function KpiCards({ summary, currency }) {
    const cur = currency || "USD";
    const cards = [
      { label: "Current portfolio value", value: fmtMoney(summary.currentPortfolioValue), hint: cur },
      { label: "Current cash balance",    value: fmtMoney(summary.currentCashBalance),   hint: cur },
      { label: "End-of-period value",     value: fmtMoney(summary.endOfPeriodValue),     hint: cur },
      { label: "Minimum cash during period", value: fmtMoney(summary.minCashDuringPeriod),
        hint: summary.minCashPeriod ? `on ${summary.minCashPeriod}` : "",
        kind: summary.insolvencyPeriods > 0 ? "bad" : (summary.minCashDuringPeriod < summary.minCashTarget ? "warn" : "ok")
      },
      { label: "Rebalancing events", value: `${summary.rebalancingEventCount}`, hint: summary.rebalancingEventCount > 0 ? "projected" : "none projected" },
      { label: "Strategy compliance", value: summary.complianceStatus,
        kind: summary.complianceStatus === "On target" ? "ok" : "warn"
      }
    ];
    return React.createElement("div", { className: "liq-fc-kpis" },
      cards.map((c, i) => React.createElement("div", {
        key: i, className: `liq-fc-kpi ${c.kind ? `is-${c.kind}` : ""}`
      },
        React.createElement("div", { className: "liq-fc-kpi-label" }, c.label),
        React.createElement("div", { className: "liq-fc-kpi-value" }, c.value),
        c.hint && React.createElement("div", { className: "liq-fc-kpi-hint" }, c.hint)
      ))
    );
  }

  // ============ Cashflow Table (Paginated, always shown) ============
  function CashflowTable({ periods }) {
    const [page, setPage] = useState(0);
    const pageSize = 20;
    const totalPages = Math.max(1, Math.ceil(periods.length / pageSize));
    const slice = periods.slice(page * pageSize, (page + 1) * pageSize);

    return React.createElement("div", { className: "liq-fc-table-wrap" },
      React.createElement("div", { className: "liq-fc-table-body" },
        React.createElement("table", { className: "liq-fc-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              ["Period", "Start value", "Contributions", "Distributions", "Capital calls", "Capital drawdowns", "Rebalancing", "End value"]
                .map((h, i) => React.createElement("th", { key: i }, h))
            )
          ),
          React.createElement("tbody", null,
            slice.map((p, i) => React.createElement("tr", { key: i },
              React.createElement("td", null, p.period),
              React.createElement("td", null, fmtMoney(p.start_value)),
              React.createElement("td", { className: "num-neg" }, p.cashflow.contribution ? `-${fmtMoney(p.cashflow.contribution)}` : "–"),
              React.createElement("td", { className: "num-pos" }, p.cashflow.distribution ? fmtMoney(p.cashflow.distribution) : "–"),
              React.createElement("td", { className: "num-pos" }, p.cashflow.capital_call ? fmtMoney(p.cashflow.capital_call) : "–"),
              React.createElement("td", { className: "num-neg" }, p.cashflow.capital_drawdown ? `-${fmtMoney(p.cashflow.capital_drawdown)}` : "–"),
              React.createElement("td", null, p.rebalancing_occurred
                ? React.createElement("span", { className: "tag tag-gold" }, "Yes")
                : "–"),
              React.createElement("td", null, fmtMoney(p.end_value))
            ))
          )
        ),
        totalPages > 1 && React.createElement("div", { className: "liq-fc-pager" },
          React.createElement("button", { type: "button", disabled: page === 0, onClick: () => setPage(p => Math.max(0, p - 1)) }, "◂ Prev"),
          React.createElement("span", null, `Page ${page + 1} of ${totalPages}`),
          React.createElement("button", { type: "button", disabled: page >= totalPages - 1, onClick: () => setPage(p => Math.min(totalPages - 1, p + 1)) }, "Next ▸")
        )
      )
    );
  }

  // ============ Unified results tab bar ============
  // Top-level switcher between "Liquidity Management" and "Performance"
  // results. Renders a centered segmented-pill control (view-seg pattern) —
  // matches Portfolio Detail's Table/Universe/Liquidity selector for visual
  // consistency. Subtitles intentionally omitted to keep the bar compact.
  function UnifiedResultsTabs({ active, onChange }) {
    const tabs = [
      { key: "liquidity",   label: "Liquidity Management", icon: PI.Icon.Target },
      { key: "performance", label: "Performance",          icon: PI.Icon.BarChart }
    ];
    return React.createElement("div", { className: "unified-tabs-bar" },
      React.createElement("div", { className: "view-seg unified-tabs-seg" },
        tabs.map(t => React.createElement("button", {
          key: t.key, type: "button",
          className: `view-seg-btn${active === t.key ? " is-active" : ""}`,
          onClick: () => onChange(t.key)
        },
          React.createElement(t.icon, { size: 13 }),
          React.createElement("span", null, t.label)
        ))
      )
    );
  }

  // Renders the Performance (portfolio-level) results body inline. Synthesises
  // a portfolio + funds + config so PI.ResultsPage can render embedded.
  function EmbeddedPerformancePane({ forecastSrc, kind }) {
    if (!PI.ResultsPage) {
      return React.createElement("div", { className: "liq-fc-embedded-empty" },
        "Performance results unavailable (ResultsPage not loaded)."
      );
    }
    const portfolio = (PI_DATA.PORTFOLIOS || [])[0] || { id: "cepres-example", name: "Cepres Example Portfolio" };
    const funds = PI_DATA.FUNDS || [];
    const config = {
      type: kind === "simulation" ? "simulation" : "forecast",
      name: forecastSrc.request_params?.simulation_name || `Forecast — ${forecastSrc.vehicleName || forecastSrc.vehicleId}`,
      depth: forecastSrc.request_params?.depth || "fast",
      granularity: "monthly",
      assetTypes: (PI_DATA.ASSET_TYPES || []).map(t => t.id),
      stressIds: forecastSrc.request_params?.stress_test_id ? [forecastSrc.request_params.stress_test_id] : []
    };
    return React.createElement(PI.ResultsPage, {
      portfolio, funds, config,
      onDone: () => {}, onShowModal: () => {}, onToast: () => {},
      embedded: true
    });
  }

  // Renders the Liquidity Management results body inline. Vehicle selection is
  // owned by the parent (ResultsPage) — the page-level scope picker passes
  // the chosen vehicleId down. Falls back to "V-01" if nothing was picked.
  function EmbeddedLiquidityPane({ portfolio, config, vehicleId }) {
    const vid = vehicleId || (portfolio && portfolio.primaryVehicleId) || "V-01";
    const isSim = config && config.type === "simulation";
    const computed = useMemo(() => {
      try {
        if (isSim) {
          return PI_DATA.projectSimulation(vid, {
            depth: config.depth || "fast",
            simulationName: config.name || "Embedded simulation",
            stressTestId: (config.stressIds && config.stressIds[0]) || null
          });
        }
        return PI_DATA.projectLiquidityForecast(vid, {
          stressTestId: (config && config.stressIds && config.stressIds[0]) || null
        });
      } catch (e) {
        return null;
      }
    }, [vid, isSim, config && config.depth, (config && config.stressIds || []).join(",")]);

    if (!computed) {
      return React.createElement("div", { className: "liq-fc-embedded-empty" },
        "Liquidity results unavailable for this vehicle.");
    }
    if (isSim && PI.LiquiditySimulationResults) {
      return React.createElement(PI.LiquiditySimulationResults, {
        simulation: computed, embedded: true
      });
    }
    return React.createElement(LiquidityForecastBody, { forecast: computed });
  }

  // ============ Vehicle Relationship Explorer ============
  // SVG bubble diagram mirroring the Universe view: parent (top), current
  // (middle, highlighted), children (bottom). Each vehicle is a circle with
  // its direct asset holdings rendered as a grid of colored dots beneath it.
  // Clicking parent or a child opens a deep-dive pane with cashflow details.
  function VehicleRelationshipExplorer({ vehicleId, vehicleName, relationships }) {
    const { parent, children } = relationships || { parent: null, children: [] };
    const hasRelations = !!parent || (children && children.length > 0);
    const [sel, setSel] = useState(null);

    // --- Interactivity (drag + double-click) shared pattern from Universe view ---
    const [nodeOffsets, setNodeOffsets] = useState({});
    const svgRef = PI.useRef(null);
    const dragRef = PI.useRef(null);
    useEffect(() => {
      function onMove(ev) {
        const d = dragRef.current;
        if (!d) return;
        const dxCss = ev.clientX - d.startX;
        const dyCss = ev.clientY - d.startY;
        if (Math.abs(dxCss) > 3 || Math.abs(dyCss) > 3) d.moved = true;
        if (d.moved) {
          const nx = d.origDx + dxCss * d.scaleX;
          const ny = d.origDy + dyCss * d.scaleY;
          setNodeOffsets(o => ({ ...o, [d.id]: { dx: nx, dy: ny } }));
        }
      }
      function onUp() {
        const d = dragRef.current;
        if (!d) return;
        if (d.moved) {
          d.justDragged = true;
          setTimeout(() => { d.justDragged = false; }, 50);
        }
        dragRef.current = d.moved ? d : null;
      }
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup",   onUp);
      return () => {
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup",   onUp);
      };
    }, []);
    function startDrag(id, e) {
      if (!svgRef.current) return;
      e.stopPropagation();
      const rect = svgRef.current.getBoundingClientRect();
      const vb = svgRef.current.viewBox.baseVal;
      const cur = nodeOffsets[id] || { dx: 0, dy: 0 };
      dragRef.current = {
        id,
        startX: e.clientX, startY: e.clientY,
        origDx: cur.dx, origDy: cur.dy,
        scaleX: vb.width  / Math.max(rect.width,  1),
        scaleY: vb.height / Math.max(rect.height, 1),
        moved: false, justDragged: false
      };
    }
    function guardedClick(handler) {
      return (e) => {
        if (dragRef.current && dragRef.current.justDragged) {
          e.preventDefault(); e.stopPropagation();
          dragRef.current.justDragged = false;
          return;
        }
        handler(e);
      };
    }
    function offsetOf(id) { return nodeOffsets[id] || { dx: 0, dy: 0 }; }

    const selected = sel === "parent" ? parent
      : (sel && sel.kind === "child") ? children[sel.idx]
      : null;

    // --- Layout constants (aligned with Universe view) ---
    const VEHICLE_R    = 22;
    const DOT_R        = 6;
    const DOT_GAP      = 4;
    const DOTS_TOP_PAD = 36;   // circle center → top row of dot grid
    const NODE_PAD_Y   = 22;   // bottom padding under the dot grid
    const MARGIN_X     = 28;
    const ROW_GAP      = 58;   // space between rows
    const SIBLING_GAP  = 28;   // horizontal space between sibling child nodes
    const ROLE_PAD_TOP = 18;   // space above the top of the circle for the role label

    function gridDims(n) {
      if (n <= 0) return { cols: 0, rows: 0, w: 0, h: 0 };
      let cols;
      if (n <= 2)       cols = n;
      else if (n <= 4)  cols = 2;
      else if (n <= 6)  cols = 3;
      else if (n <= 9)  cols = 3;
      else if (n <= 12) cols = 4;
      else if (n <= 16) cols = 5;
      else              cols = 6;
      const rows = Math.ceil(n / cols);
      const w = cols * (2 * DOT_R) + (cols - 1) * DOT_GAP;
      const h = rows * (2 * DOT_R) + (rows - 1) * DOT_GAP;
      return { cols, rows, w, h };
    }
    function assetsFor(vid) { return PI_DATA.assetsOfVehicle ? PI_DATA.assetsOfVehicle(vid) : []; }
    function nodeWidth(n) {
      const g = gridDims(n);
      return Math.max(2 * VEHICLE_R + 18, g.w + 18);
    }
    function nodeHeight(n) {
      const g = gridDims(n);
      // From circle top to bottom-edge of asset grid (or circle bottom if no assets)
      return 2 * VEHICLE_R + (g.h > 0 ? DOTS_TOP_PAD - VEHICLE_R + g.h : 0) + NODE_PAD_Y;
    }

    // Gather assets
    const parentAssets  = parent  ? assetsFor(parent.id) : [];
    const currentAssets = assetsFor(vehicleId);
    const childEntries  = (children || []).map(c => ({
      ...c, _assets: assetsFor(c.id)
    }));

    // Row widths → canvas width
    const parentRowW   = parent ? nodeWidth(parentAssets.length) : 0;
    const currentRowW  = nodeWidth(currentAssets.length);
    const childrenRowW = childEntries.length
      ? childEntries.reduce((s, c) => s + nodeWidth(c._assets.length), 0)
        + Math.max(0, childEntries.length - 1) * SIBLING_GAP
      : 0;
    const innerW = Math.max(parentRowW, currentRowW, childrenRowW, 360);
    const W      = innerW + 2 * MARGIN_X;
    const cxMid  = W / 2;

    // Row heights and vertical positions (circle centers)
    const parentRowH   = parent ? nodeHeight(parentAssets.length) : 0;
    const currentRowH  = nodeHeight(currentAssets.length);
    const childrenRowH = childEntries.length
      ? Math.max(...childEntries.map(c => nodeHeight(c._assets.length)))
      : 0;

    let cursorY = ROLE_PAD_TOP;
    const parentCy   = parent ? (cursorY + VEHICLE_R) : 0;
    if (parent) cursorY += parentRowH + ROW_GAP;
    const currentCy  = cursorY + VEHICLE_R;
    cursorY += currentRowH + ROW_GAP;
    const childrenCy = childEntries.length ? (cursorY + VEHICLE_R) : 0;
    if (childEntries.length) cursorY += childrenRowH;
    const H = cursorY + 16;

    // Horizontal positions for child nodes
    const childXs = [];
    {
      let cursorX = cxMid - childrenRowW / 2;
      childEntries.forEach(c => {
        const w = nodeWidth(c._assets.length);
        childXs.push(cursorX + w / 2);
        cursorX += w + SIBLING_GAP;
      });
    }

    function renderNode(key, id, name, role, nx0, ny0, assets, interactive, isSelected, isCurrent, onClick) {
      const g = gridDims(assets.length);
      const off = offsetOf(id);
      const nx = nx0 + off.dx, ny = ny0 + off.dy;
      const topY  = ny + DOTS_TOP_PAD;
      const leftX = nx - g.w / 2 + DOT_R;
      const cls = [
        "liq-fc-rel-svg-node", "uv-draggable",
        isCurrent ? "is-current" : "",
        interactive ? "is-interactive" : "",
        isSelected ? "is-selected" : ""
      ].filter(Boolean).join(" ");
      return React.createElement("g", {
        key,
        className: cls,
        onMouseDown: (ev) => startDrag(id, ev),
        onClick: interactive && onClick ? guardedClick(onClick) : undefined,
        onDoubleClick: interactive && onClick ? onClick : undefined,
        role: interactive ? "button" : undefined,
        tabIndex: interactive ? 0 : undefined
      },
        // Role label above circle
        React.createElement("text", {
          x: nx, y: ny - VEHICLE_R - 6,
          textAnchor: "middle",
          className: "liq-fc-rel-svg-role"
        }, role),
        // Circle
        React.createElement("circle", {
          cx: nx, cy: ny, r: VEHICLE_R,
          className: "liq-fc-rel-svg-vehicle"
        }),
        // Vehicle label inside circle
        React.createElement("text", {
          x: nx, y: ny + 4, textAnchor: "middle",
          className: "liq-fc-rel-svg-vehicle-lbl"
        }, name),
        // Vehicle id below circle, above the dot grid
        React.createElement("text", {
          x: nx, y: ny + VEHICLE_R + 14, textAnchor: "middle",
          className: "liq-fc-rel-svg-vehicle-id"
        }, id || ""),
        // Asset dots
        assets.map((a, i) => {
          const col = i % g.cols;
          const row = Math.floor(i / g.cols);
          const dx = leftX + col * (2 * DOT_R + DOT_GAP);
          const dy = topY  + row * (2 * DOT_R + DOT_GAP) + DOT_R;
          const meta = PI_DATA.assetTypeMeta(a.assetType);
          return React.createElement("g", {
            key: a.id,
            className: `liq-fc-rel-svg-dot at-${a.assetType}`
          },
            React.createElement("circle", {
              cx: dx, cy: dy, r: DOT_R,
              fill: meta.color, stroke: "#FFFFFF", strokeWidth: 1.25
            }),
            React.createElement("title", null, `${a.name} · ${meta.label}`)
          );
        }),
        // Interactive hit area (invisible rect covering node + dots)
        React.createElement("rect", {
          x: nx - nodeWidth(assets.length) / 2,
          y: ny - VEHICLE_R - 2,
          width: nodeWidth(assets.length),
          height: nodeHeight(assets.length) + 4,
          className: "liq-fc-rel-svg-hit",
          fill: "transparent"
        })
      );
    }

    function connectorPath(x1, y1, x2, y2) {
      const midY = y1 + (y2 - y1) * 0.55;
      return `M ${x1} ${y1} C ${x1} ${midY}, ${x2} ${midY}, ${x2} ${y2}`;
    }

    return React.createElement("div", { className: "liq-fc-rel" },
      React.createElement("div", { className: "liq-fc-rel-head" },
        React.createElement("h4", { className: "liq-fc-section-title" }, "Vehicle relationships"),
        React.createElement("div", { className: "liq-fc-rel-sub-desc" },
          hasRelations
            ? "Click or double-click a connected vehicle (parent or child) to open a deep-dive of the cashflows between it and the current vehicle. Drag any bubble to rearrange the layout. Each vehicle shows its direct holdings as colored dots."
            : "This vehicle has no parent or child vehicles in scope."
        )
      ),
      hasRelations && React.createElement("div", { className: "liq-fc-rel-svg-wrap" },
        React.createElement("svg", {
          className: "liq-fc-rel-svg",
          viewBox: `0 0 ${W} ${H}`,
          preserveAspectRatio: "xMidYMin meet",
          style: { width: "100%", height: H },
          ref: svgRef
        },
          // Connectors (drawn first, beneath nodes). Endpoints track drag offsets.
          parent && (() => {
            const pOff = offsetOf(parent.id);
            const cOff = offsetOf(vehicleId);
            return React.createElement("path", {
              key: "edge-parent",
              d: connectorPath(
                cxMid + pOff.dx, parentCy + VEHICLE_R + pOff.dy,
                cxMid + cOff.dx, currentCy - VEHICLE_R + cOff.dy
              ),
              className: "liq-fc-rel-svg-edge", fill: "none"
            });
          })(),
          childEntries.map((c, i) => {
            const cOff = offsetOf(vehicleId);
            const kOff = offsetOf(c.id);
            return React.createElement("path", {
              key: `edge-${c.id}`,
              d: connectorPath(
                cxMid + cOff.dx, currentCy + VEHICLE_R + cOff.dy,
                childXs[i] + kOff.dx, childrenCy - VEHICLE_R + kOff.dy
              ),
              className: "liq-fc-rel-svg-edge", fill: "none"
            });
          }),
          // Parent node
          parent && renderNode(
            "parent", parent.id, parent.name, "Parent",
            cxMid, parentCy, parentAssets,
            true, sel === "parent", false,
            () => setSel(s => s === "parent" ? null : "parent")
          ),
          // Current node (draggable but not selectable — no deep-dive on self)
          renderNode(
            "current", vehicleId, vehicleName, "Current vehicle",
            cxMid, currentCy, currentAssets,
            false, false, true, null
          ),
          // Child nodes
          childEntries.map((c, i) => renderNode(
            `child-${c.id}`, c.id, c.name, "Child",
            childXs[i], childrenCy, c._assets,
            true,
            sel && sel.kind === "child" && sel.idx === i,
            false,
            () => setSel(s => s && s.kind === "child" && s.idx === i ? null : { kind: "child", idx: i })
          ))
        ),
        // Legend (mirror of Universe legend)
        React.createElement("div", { className: "liq-fc-rel-legend" },
          PI_DATA.ASSET_TYPES.map(a => React.createElement("span", {
            key: a.id, className: "liq-fc-rel-legend-item"
          },
            React.createElement("span", {
              className: "liq-fc-rel-legend-dot", style: { background: a.color }
            }),
            React.createElement("span", null, a.label)
          ))
        )
      ),
      // Deep-dive pane
      selected && React.createElement(RelationshipDeepDive, {
        selection: sel, related: selected, vehicleName
      })
    );
  }

  function RelationshipDeepDive({ selection, related, vehicleName }) {
    const isParent = selection === "parent";
    const title = isParent ? `Flows between ${vehicleName} ↔ ${related.name} (parent)`
                           : `Flows between ${vehicleName} ↔ ${related.name} (child)`;
    const rows = related.periods || [];
    // Summary stats (compact)
    const stats = isParent
      ? [
          { label: "Capital calls to parent",       value: fmtMoney(related.capitalCallsMadeToParent) },
          { label: "Drawdowns from parent",         value: fmtMoney(related.capitalDrawdownsReceivedFromParent) }
        ]
      : [
          { label: "Contributions received", value: fmtMoney(related.contributionsReceived) },
          { label: "Distributions sent",     value: fmtMoney(related.distributionsSent) },
          { label: "Capital calls made",     value: fmtMoney(related.capitalCallsMade) },
          { label: "Capital drawdowns sent", value: fmtMoney(related.capitalDrawdownsSent) }
        ];

    // Table — if >24 rows, collapse by year for readability (paginated below).
    const aggByYear = {};
    rows.forEach(r => {
      const y = r.period.slice(0, 4);
      const b = aggByYear[y] || { year: y, contribution: 0, distribution: 0, capital_call: 0, capital_drawdown: 0 };
      b.contribution += r.contribution;
      b.distribution += r.distribution;
      b.capital_call += r.capital_call;
      b.capital_drawdown += r.capital_drawdown;
      aggByYear[y] = b;
    });
    const yearly = Object.values(aggByYear);

    const [groupBy, setGroupBy] = useState(rows.length > 24 ? "year" : "month");
    const tableRows = groupBy === "year" ? yearly : rows;

    return React.createElement("div", { className: "liq-fc-rel-deep" },
      React.createElement("div", { className: "liq-fc-rel-deep-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "liq-fc-rel-deep-title" }, title),
          React.createElement("div", { className: "liq-fc-chart-sub" },
            `${rows.length} period${rows.length === 1 ? "" : "s"} of cashflow data.`
          )
        ),
        React.createElement("div", { className: "liq-fc-chart-tabs" },
          React.createElement("button", {
            type: "button", className: `pill ${groupBy === "month" ? "is-active" : ""}`,
            onClick: () => setGroupBy("month")
          }, "Monthly"),
          React.createElement("button", {
            type: "button", className: `pill ${groupBy === "year" ? "is-active" : ""}`,
            onClick: () => setGroupBy("year")
          }, "Yearly")
        )
      ),
      React.createElement("div", { className: "liq-fc-rel-deep-stats" },
        stats.map((s, i) => React.createElement("div", { key: i, className: "liq-fc-rel-deep-stat" },
          React.createElement("div", { className: "liq-fc-rel-deep-stat-lbl" }, s.label),
          React.createElement("div", { className: "liq-fc-rel-deep-stat-val" }, s.value)
        ))
      ),
      React.createElement("div", { className: "liq-fc-rel-deep-table-wrap" },
        React.createElement("table", { className: "liq-fc-chart-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              ["Period","Contributions","Distributions","Capital calls","Capital drawdowns","Net"].map((h, i) =>
                React.createElement("th", { key: i }, h))
            )
          ),
          React.createElement("tbody", null,
            tableRows.map((r, i) => {
              const net = r.distribution + r.capital_call - r.contribution - r.capital_drawdown;
              return React.createElement("tr", { key: i },
                React.createElement("td", null, groupBy === "year" ? r.year : r.period),
                React.createElement("td", { className: r.contribution > 0 ? "num-neg" : null }, r.contribution ? `-${fmtMoney(r.contribution)}` : "–"),
                React.createElement("td", { className: r.distribution > 0 ? "num-pos" : null }, r.distribution ? fmtMoney(r.distribution) : "–"),
                React.createElement("td", { className: r.capital_call > 0 ? "num-pos" : null }, r.capital_call ? fmtMoney(r.capital_call) : "–"),
                React.createElement("td", { className: r.capital_drawdown > 0 ? "num-neg" : null }, r.capital_drawdown ? `-${fmtMoney(r.capital_drawdown)}` : "–"),
                React.createElement("td", { className: net >= 0 ? "num-pos" : "num-neg" },
                  `${net >= 0 ? "+" : ""}${fmtMoney(net)}`)
              );
            })
          )
        )
      )
    );
  }

  // ============ Forecast Configuration Modal ============
  function ForecastConfigModal({ vehicleId, onRun, onClose }) {
    const defaultStart = new Date().toISOString().slice(0, 10);
    const defaultEndDate = (() => {
      const d = new Date(); d.setFullYear(d.getFullYear() + 10); return d.toISOString().slice(0, 10);
    })();
    const [currency, setCurrency] = useState("USD");
    const [stressId, setStressId] = useState("");
    const [startDate, setStartDate] = useState(defaultStart);
    const [endDate, setEndDate] = useState(defaultEndDate);
    const [vid, setVid] = useState(vehicleId || "V-08");

    const vehicleOpts = useMemo(() => (PI_DATA.VEHICLE_TREE || [])
      .filter(v => !String(v.id).startsWith("CL-"))
      .map(v => ({ value: v.id, label: `${v.id} · ${v.name}` })), []);
    const stressOpts = useMemo(() => {
      const base = [{ value: "", label: "None" }];
      (PI_DATA.STRESS_TESTS || []).forEach(s => base.push({ value: s.id, label: s.name || s.id }));
      return base;
    }, []);

    const errors = {};
    if (!currency) errors.currency = "Currency is required.";
    if (!startDate) errors.startDate = "Start date is required.";
    if (!endDate) errors.endDate = "End date is required.";
    if (startDate && endDate && endDate <= startDate) errors.endDate = "End date must be after start date.";
    if (!vid) errors.vehicle = "Vehicle is required.";
    const canRun = Object.keys(errors).length === 0;

    const handleRun = () => {
      if (!canRun) return;
      onRun({ vehicleId: vid, currency, stressTestId: stressId || null, startDate, endDate });
    };

    return React.createElement(PI.Portal, null,
      React.createElement("div", { className: "scrim" }),
      React.createElement("div", { className: "modal-wrap", onClick: onClose },
        React.createElement("div", { className: "modal modal-md liq-fc-cfg", onClick: e => e.stopPropagation() },
          React.createElement("header", { className: "modal-head" },
            React.createElement("div", null,
              React.createElement("div", { className: "eyebrow" }, "Immediate forecast"),
              React.createElement("h2", { className: "modal-title" }, "Configure forecast")
            ),
            React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose, title: "Close" })
          ),
          React.createElement("div", { className: "modal-body liq-fc-cfg-body" },
            React.createElement("div", { className: "field-row" },
              React.createElement(PI.Field, { label: "Currency", required: true, error: errors.currency },
                React.createElement(PI.Dropdown, {
                  value: currency, onChange: setCurrency,
                  options: [{ value: "USD", label: "USD — US Dollar" }, { value: "EUR", label: "EUR — Euro" }, { value: "GBP", label: "GBP — British Pound" }],
                  minWidth: 220
                })
              ),
              React.createElement(PI.Field, { label: "Stress test", hint: "Leave empty for baseline scenario." },
                React.createElement(PI.Dropdown, {
                  value: stressId, onChange: setStressId,
                  options: stressOpts, minWidth: 220
                })
              )
            ),
            React.createElement("div", { className: "field-row" },
              React.createElement(PI.Field, { label: "Start date", required: true, error: errors.startDate },
                React.createElement("input", {
                  type: "date", className: "input", value: startDate,
                  onChange: e => setStartDate(e.target.value)
                })
              ),
              React.createElement(PI.Field, { label: "End date", required: true, error: errors.endDate, hint: "Default: 10 years from start." },
                React.createElement("input", {
                  type: "date", className: "input", value: endDate,
                  onChange: e => setEndDate(e.target.value)
                })
              )
            ),
            React.createElement(PI.Field, { label: "Vehicle", required: true, error: errors.vehicle, wide: true },
              React.createElement(PI.Dropdown, {
                value: vid, onChange: setVid, options: vehicleOpts, minWidth: 320
              })
            )
          ),
          React.createElement("footer", { className: "modal-foot" },
            React.createElement("div", { className: "liq-fc-cfg-status" },
              canRun
                ? React.createElement("span", { className: "strat-foot-ok" },
                    React.createElement(PI.Icon.Check, { size: 13 }), " Ready to run.")
                : React.createElement("span", { className: "strat-foot-err" },
                    React.createElement(PI.Icon.Info, { size: 13 }), ` ${Object.keys(errors).length} field${Object.keys(errors).length === 1 ? "" : "s"} need attention.`)
            ),
            React.createElement("div", { style: { display: "flex", gap: 8 } },
              React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
              React.createElement(PI.Btn, {
                kind: "primary", icon: React.createElement(PI.Icon.Zap, { size: 13 }),
                onClick: handleRun, disabled: !canRun
              }, "Run forecast")
            )
          )
        )
      )
    );
  }

  // ============ Vehicle switcher (in-results) ============
  // Lets users flip between vehicles without leaving the results view.
  // Parent re-runs the forecast/simulation using the original request_params
  // but the newly-selected vehicleId.
  function VehicleSwitcher({ vehicleId, onChange }) {
    const opts = useMemo(() => (PI_DATA.VEHICLE_TREE || [])
      .filter(v => !String(v.id).startsWith("CL-"))
      .map(v => ({ value: v.id, label: `${v.id} · ${v.name}` })), []);
    return React.createElement("div", { className: "liq-fc-vehicle-switcher" },
      React.createElement("span", { className: "liq-fc-vehicle-switcher-lbl" }, "Viewing vehicle"),
      React.createElement(PI.Dropdown, {
        value: vehicleId, onChange, options: opts, minWidth: 280
      })
    );
  }

  // ============ Rebalancing Panel ============
  // Visualisation of *when* rebalancing occurred and *what* changed at each
  // event. Two parts:
  //   1. Timeline strip — every annual period as a chip; rebalancing years
  //      are highlighted (gold + diamond) and clickable to scroll to the
  //      matching event card below.
  //   2. Event cards — for each rebalancing year, show the drift that
  //      triggered it and a horizontal bar diff per asset (before → after,
  //      delta in pts, magnitude bar).
  // Empty state when the strategy never had to rebalance.
  function RebalancingPanel({ periods, summary, strategy, titleSuffix }) {
    const events = periods
      .map((p, i) => ({ p, i }))
      .filter(({ p }) => p.rebalancing_occurred && p.rebalancing_changes && p.rebalancing_changes.length > 0);
    const total = periods.length;
    const stratLabel = strategy ? strategy.name + (strategy.is_preset ? " (preset)" : "") : "Current strategy";

    if (events.length === 0) {
      return React.createElement("div", { className: "liq-fc-reb" },
        React.createElement("div", { className: "liq-fc-reb-head" },
          React.createElement("div", { className: "liq-fc-chart-title" },
            "Rebalancing events" + (titleSuffix ? ` · ${titleSuffix}` : "")
          ),
          React.createElement("div", { className: "liq-fc-chart-sub" },
            `Strategy: ${stratLabel}. No rebalancing was triggered across the ${total} annual period${total === 1 ? "" : "s"} — drift stayed within tolerance.`
          )
        ),
        React.createElement("div", { className: "liq-fc-reb-empty" },
          React.createElement(PI.Icon.Check, { size: 16 }),
          React.createElement("span", null, "Allocation stayed on target throughout the window.")
        )
      );
    }

    // Sort events chronologically (already in order, but be safe).
    events.sort((a, b) => a.i - b.i);
    const eventIdxSet = new Set(events.map(e => e.i));

    function jumpToCard(period) {
      const id = `liq-fc-reb-card-${period}`;
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    return React.createElement("div", { className: "liq-fc-reb" },
      React.createElement("div", { className: "liq-fc-reb-head" },
        React.createElement("div", { className: "liq-fc-chart-title" },
          "Rebalancing events" + (titleSuffix ? ` · ${titleSuffix}` : "")
        ),
        React.createElement("div", { className: "liq-fc-chart-sub" },
          `Strategy: ${stratLabel}. ${events.length} rebalancing event${events.length === 1 ? "" : "s"} triggered across ${total} annual period${total === 1 ? "" : "s"}. Click a highlighted year to jump to the diff.`
        )
      ),
      // Timeline
      React.createElement("div", { className: "liq-fc-reb-timeline" },
        periods.map((p, i) => {
          const isReb = eventIdxSet.has(i);
          return React.createElement("button", {
            key: i, type: "button",
            className: `liq-fc-reb-chip${isReb ? " is-reb" : ""}`,
            disabled: !isReb,
            onClick: isReb ? () => jumpToCard(p.period) : undefined,
            title: isReb ? `Click to view rebalancing diff for ${yearLabel(p.period)}` : `${yearLabel(p.period)} — no rebalancing`
          },
            isReb && React.createElement("span", { className: "liq-fc-reb-chip-marker" }, "◆"),
            React.createElement("span", { className: "liq-fc-reb-chip-year" }, yearLabel(p.period))
          );
        })
      ),
      // Event cards
      React.createElement("div", { className: "liq-fc-reb-cards" },
        events.map(({ p }) => {
          const changes = (p.rebalancing_changes || []).slice()
            .sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
          const maxAbs = changes.reduce((m, c) => Math.max(m, Math.abs(c.delta)), 1);
          return React.createElement("div", {
            key: p.period, id: `liq-fc-reb-card-${p.period}`,
            className: "liq-fc-reb-card"
          },
            React.createElement("div", { className: "liq-fc-reb-card-head" },
              React.createElement("div", { className: "liq-fc-reb-card-year" }, yearLabel(p.period)),
              React.createElement("div", { className: "liq-fc-reb-card-meta" },
                React.createElement("span", null, `Drift ${(p.drift_pct || 0).toFixed(1)}%`),
                React.createElement("span", { className: "divider-dot" }, "·"),
                React.createElement("span", null, `${changes.length} adjustment${changes.length === 1 ? "" : "s"}`)
              )
            ),
            React.createElement("div", { className: "liq-fc-reb-card-rows" },
              changes.map(c => {
                const isUp = c.delta > 0;
                const isFlat = Math.abs(c.delta) < 0.05;
                const sign = isFlat ? "neutral" : (isUp ? "pos" : "neg");
                const barW = (Math.abs(c.delta) / maxAbs) * 100;
                return React.createElement("div", {
                  key: c.assetType, className: `liq-fc-reb-row liq-fc-reb-row-${sign}`
                },
                  React.createElement("span", {
                    className: "liq-fc-reb-row-swatch",
                    style: { background: specColor(c.assetType) }
                  }),
                  React.createElement("span", { className: "liq-fc-reb-row-lbl" }, specLabel(c.assetType)),
                  React.createElement("span", { className: "liq-fc-reb-row-from" },
                    `${c.fromPct.toFixed(1)}%`),
                  React.createElement("span", { className: "liq-fc-reb-row-arrow" }, "→"),
                  React.createElement("span", { className: "liq-fc-reb-row-to" },
                    `${c.toPct.toFixed(1)}%`),
                  React.createElement("span", { className: "liq-fc-reb-row-bar-wrap" },
                    React.createElement("span", {
                      className: "liq-fc-reb-row-bar",
                      style: { width: `${barW}%`, background: isUp ? "var(--green)" : (isFlat ? "var(--rule)" : "#C25450") }
                    })
                  ),
                  React.createElement("span", { className: "liq-fc-reb-row-delta" },
                    `${isUp ? "+" : ""}${c.delta.toFixed(1)}pt`
                  )
                );
              })
            )
          );
        })
      )
    );
  }

  // ============ Liquidity Hero ============
  // Summary banner shown above the charts. Mirrors the Performance hero
  // (res-hero-v2) so both views feel part of the same page. Shows a punchy
  // headline + 6 KPI cards derived from the forecast/simulation summary.
  // ============ Scrollspy section nav ============
  // Sticky anchor bar mirrored from ResultsPage (.res-anchor-nav). Highlights
  // the section currently on-screen as the user scrolls, and jumps to it on
  // click. Sections are identified by id="liq-section-<key>".
  function LiquiditySectionNav({ sections, activeKey, onJump }) {
    return React.createElement("nav", { className: "res-anchor-nav liq-fc-anchor-nav" },
      React.createElement("div", { className: "res-anchor-nav-inner" },
        sections.map(s => React.createElement("button", {
          key: s.key,
          className: "res-anchor-item" + (activeKey === s.key ? " is-active" : ""),
          onClick: () => onJump(s.key)
        },
          React.createElement("span", { className: "res-anchor-num" }, s.num),
          React.createElement("span", { className: "res-anchor-text" },
            React.createElement("span", { className: "res-anchor-lbl" }, s.label)
          )
        ))
      )
    );
  }

  // Wrap a section's charts in a header-prefixed block (mirrors .res-section
  // from the Performance view so they share the visual language).
  function LiquiditySection({ skey, num, title, children }) {
    return React.createElement("section", {
      id: "liq-section-" + skey,
      className: "res-section liq-fc-section"
    },
      React.createElement("header", { className: "res-section-head" },
        React.createElement("div", { className: "res-section-num" }, num),
        React.createElement("div", { className: "res-section-text" },
          React.createElement("h2", { className: "res-section-title" }, title)
        )
      ),
      React.createElement("div", { className: "res-section-body" }, children)
    );
  }

  // ============ Shared body layout ============
  // Drives the full liquidity-results body for both the Immediate Forecast
  // and the Simulation. Sticky scrollspy nav + 6 numbered sections — the
  // Allocation section also embeds the RebalancingPanel right below the
  // chart so "what changed when" sits next to the strategy.
  function LiquidityBodyLayout({
    periods, summary, relationships, vehicleId, vehicleName,
    titleSuffix, minCashTarget, extraTop, strategy
  }) {
    const [activeSection, setActiveSection] = useState("value-cash");

    const sections = [
      { key: "value-cash",    num: "01", label: "Value & cash" },
      { key: "allocation",    num: "02", label: "Allocation" },
      { key: "per-asset",     num: "03", label: "Per-asset" },
      { key: "flows",         num: "04", label: "Cashflows" },
      { key: "relationships", num: "05", label: "Vehicles" },
      { key: "detail",        num: "06", label: "Detail" }
    ];

    const jumpTo = (key) => {
      setActiveSection(key);
      const el = document.getElementById("liq-section-" + key);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    };

    // Scrollspy — updates activeSection as the user scrolls.
    useEffect(() => {
      const handler = () => {
        let current = sections[0].key;
        for (const s of sections) {
          const el = document.getElementById("liq-section-" + s.key);
          if (!el) continue;
          const top = el.getBoundingClientRect().top;
          if (top - 140 <= 0) current = s.key;
        }
        if (current && current !== activeSection) setActiveSection(current);
      };
      window.addEventListener("scroll", handler, { passive: true });
      handler();
      return () => window.removeEventListener("scroll", handler);
    }, [activeSection]);

    const effectiveMinCashTarget = (minCashTarget !== undefined && minCashTarget !== null)
      ? minCashTarget : summary.minCashTarget;

    return React.createElement(React.Fragment, null,
      extraTop || null,
      React.createElement(LiquiditySectionNav, {
        sections, activeKey: activeSection, onJump: jumpTo
      }),
      React.createElement("div", { className: "liq-fc-sections" },
        React.createElement(LiquiditySection, {
          skey: "value-cash", num: "01", title: "Value & cash"
        },
          React.createElement("div", { className: "liq-fc-charts-grid" },
            React.createElement(ChartValue, { periods, titleSuffix }),
            React.createElement(ChartCash,  { periods, minCashTarget: effectiveMinCashTarget, titleSuffix })
          )
        ),
        React.createElement(LiquiditySection, {
          skey: "allocation", num: "02", title: "Allocation & rebalancing"
        },
          React.createElement("div", { className: "liq-fc-charts-grid liq-fc-charts-grid-single" },
            React.createElement(ChartAllocation, { periods, titleSuffix })
          ),
          React.createElement(RebalancingPanel, { periods, summary, strategy, titleSuffix })
        ),
        React.createElement(LiquiditySection, {
          skey: "per-asset", num: "03", title: "Per-asset breakdown"
        },
          React.createElement(ChartsNonCashPerAsset, { periods, titleSuffix })
        ),
        React.createElement(LiquiditySection, {
          skey: "flows", num: "04", title: "Cashflows"
        },
          React.createElement("div", { className: "liq-fc-charts-grid liq-fc-charts-grid-single" },
            React.createElement(ChartFlows, { periods, titleSuffix })
          )
        ),
        React.createElement(LiquiditySection, {
          skey: "relationships", num: "05", title: "Vehicle relationships"
        },
          React.createElement(VehicleRelationshipExplorer, {
            vehicleId, vehicleName, relationships
          })
        ),
        React.createElement(LiquiditySection, {
          skey: "detail", num: "06", title: "Detail"
        },
          React.createElement(CashflowTable, { periods })
        )
      )
    );
  }

  // ============ Results root ============
  // Inner content of the liquidity forecast page (no page chrome). Reused both
  // standalone and embedded inside ResultsPage's "Liquidity Management" tab.
  function LiquidityForecastBody({ forecast }) {
    const { periods, summary, relationships, vehicleName, vehicleId, strategy } = forecast;
    return React.createElement(LiquidityBodyLayout, {
      periods, summary, relationships, vehicleId, vehicleName, strategy,
      minCashTarget: summary.minCashTarget
    });
  }

  function LiquidityForecastResults({ forecast, onBack, onReconfigure, embedded }) {
    if (!forecast) return null;
    // Top-level tab: which results view to show. Unifies Liquidity Management
    // and Performance (portfolio) results in one page (per user request).
    const [topTab, setTopTab] = useState("liquidity");
    // Currently-viewed vehicle (can be switched without leaving the results view).
    const [viewVid, setViewVid] = useState(forecast.vehicleId);

    // Recompute the forecast for the newly-selected vehicle, re-using the
    // original request parameters (currency, dates, stress test). If viewVid
    // matches the original forecast's vehicle, reuse the pre-computed result.
    const activeForecast = useMemo(() => {
      if (viewVid === forecast.vehicleId) return forecast;
      try {
        return PI_DATA.projectLiquidityForecast(viewVid, {
          currency:     forecast.request_params.currency,
          stressTestId: forecast.request_params.stress_test_id,
          startDate:    forecast.request_params.startDate,
          endDate:      forecast.request_params.endDate
        });
      } catch (e) {
        return forecast;
      }
    }, [viewVid, forecast]);

    const { vehicleName, vehicleId, strategy, request_params } = activeForecast;
    const vehicleLabel = `${vehicleId} · ${vehicleName}`;

    if (embedded) {
      // When embedded inside ResultsPage's Liquidity tab — only the body.
      return React.createElement(LiquidityForecastBody, { forecast: activeForecast });
    }

    return React.createElement("div", { className: "liq-fc-results", "data-screen-label": "02d Immediate Forecast Results" },
      // ========== Page header ==========
      // Top row: back link + page-level actions. Title row: eyebrow + title +
      // metadata pills. Splitting nav vs. title makes the hierarchy obvious
      // even when the strategy meta gets long. (Vehicle picker lives in the
      // always-visible hierarchy panel below — no dropdown duplicate here.)
      React.createElement("header", { className: "liq-fc-head" },
        React.createElement("div", { className: "liq-fc-head-top" },
          React.createElement(PI.Btn, {
            kind: "ghost", size: "sm", onClick: onBack,
            icon: React.createElement(PI.Icon.ChevronLeft, { size: 13 })
          }, "Back to Liquidity"),
          React.createElement("div", { className: "liq-fc-head-actions" },
            React.createElement(PI.Btn, { kind: "ghost", onClick: onReconfigure,
              icon: React.createElement(PI.Icon.Settings, { size: 13 }) }, "Reconfigure")
          )
        ),
        React.createElement("div", { className: "liq-fc-head-title-block" },
          React.createElement("div", { className: "eyebrow liq-fc-head-eyebrow" }, "Immediate forecast"),
          React.createElement("h2", { className: "liq-fc-head-title" }, `Liquidity forecast — ${vehicleLabel}`),
          React.createElement("div", { className: "liq-fc-head-meta" },
            strategy && React.createElement("span", { className: "liq-fc-meta-pill" },
              React.createElement(PI.Icon.Target, { size: 11 }),
              `${strategy.name}${strategy.is_preset ? " · preset" : ""}`
            ),
            React.createElement("span", { className: "liq-fc-meta-pill" }, request_params.currency),
            React.createElement("span", { className: "liq-fc-meta-pill" },
              `${request_params.startDate} → ${request_params.endDate}`),
            request_params.stress_test_id && React.createElement("span", { className: "liq-fc-meta-pill is-warn" },
              `Stress: ${request_params.stress_test_id}`)
          )
        )
      ),

      // Unified results tab bar (Liquidity ↔ Performance)
      React.createElement(UnifiedResultsTabs, {
        active: topTab, onChange: setTopTab,
        defaultTab: "liquidity"
      }),

      topTab === "liquidity"
        ? React.createElement(LiquidityForecastBody, { forecast: activeForecast })
        : React.createElement(EmbeddedPerformancePane, {
            forecastSrc: activeForecast, kind: "forecast"
          })
    );
  }

  // ============ Public exports ============
  window.PI.LiquidityForecastConfigModal = ForecastConfigModal;
  window.PI.LiquidityForecastResults = LiquidityForecastResults;
  // Shared chart components + helpers for the simulation view.
  window.PI.LiqCharts = {
    ChartValue, ChartCash, ChartNonCashAssets, ChartAllocation, ChartFlows,
    ChartPerAssetBar, ChartsNonCashPerAsset,
    KpiCards, CashflowTable, VehicleRelationshipExplorer,
    fmtMoney, fmtPct, fmtDate, niceMax, yearLabel, specLabel, specColor,
    LiquidityForecastBody, UnifiedResultsTabs, VehicleSwitcher,
    LiquiditySectionNav, LiquiditySection, LiquidityBodyLayout,
    EmbeddedPerformancePane, EmbeddedLiquidityPane
  };
  // Direct exports for cross-file consumers.
  window.PI.UnifiedResultsTabs = UnifiedResultsTabs;
  window.PI.EmbeddedLiquidityPane = EmbeddedLiquidityPane;
  window.PI.EmbeddedPerformancePane = EmbeddedPerformancePane;
})();
