/* Forecast charts — shared by Immediate Forecast (inline) and Simulation Results.
   Generates synthetic, deterministic year-by-year contribution / distribution /
   net / NAV data for a portfolio with a historical vs simulated split.

   Public exports on window.PI:
     FC_DIMS, FC_PALETTE, FC_COL       → constants
     fcBuildForecast(portfolio, opts)  → full data package
     FCCashflowsSection   ({ data, showUncertainty })
     FCCompositionSection ({ data, showUncertainty })
     FCDetailSection      ({ data })
     ForecastChartsBlock  ({ portfolio, showUncertainty })  → convenience wrapper

   Colours follow the Cepres design system:
     dawn  #2F3E55  contributions
     teal  #7FCCC8  distributions
     green #058F8A  net cashflow
     gold  #E5AD00  NAV
*/

(function(){
  const COL = {
    contrib:   "#2F3E55",
    contribHx: "#5A6B82",
    distrib:   "#7FCCC8",
    distribHx: "#B0DDDA",
    net:       "#058F8A",
    netHx:     "#6BBBB7",
    nav:       "#E5AD00",
    navHx:     "#F1CE66",
    axis:      "var(--black-60)",
    grid:      "var(--rule-soft)",
    simLine:   "#2F3E55",
    band:      "rgba(47,62,85,0.10)",
  };

  const DIMS = [
    { key: "none",      label: "No filter", values: [] },
    { key: "type",      label: "Type",      values: ["Primary","Secondary","Co-invest","Stock","Bond","ETF","Hedge"] },
    { key: "region",    label: "Region",    values: ["North America","Europe","Asia Pacific","Emerging Markets"] },
    { key: "subRegion", label: "Sub-region",values: ["USA","Northern America","Europe General","China","Asia General","Others"] },
    { key: "stage",     label: "Stage",     values: ["Buyout","Growth","Venture","Secondary","Credit","Infrastructure"] },
    { key: "subStage",  label: "Sub-stage", values: ["Early Venture","Late Venture","Large Buyout","Mid Buyout","Core Infra","Direct Lending"] },
    { key: "vintage",   label: "Vintage",   values: ["2011-2015","2016-2019","2020-2022","2023-2025","2026+"] },
  ];

  const PALETTE = [
    "#E5AD00","#C78A00","#A8742A","#8C5A27","#64501E","#B69030","#D49A1F","#F0C84A"
  ];

  // Per-metric chart defaults
  const METRIC = {
    nav:     { key: "nav",     label: "NAV",          color: COL.nav,     colorHx: COL.navHx,     stackNegative: false },
    contrib: { key: "contrib", label: "Contribution", color: COL.contrib, colorHx: COL.contribHx, stackNegative: true  },
    distrib: { key: "distrib", label: "Distribution", color: COL.distrib, colorHx: COL.distribHx, stackNegative: false },
    net:     { key: "net",     label: "Net",          color: COL.net,     colorHx: COL.netHx,     stackNegative: true  },
  };

  function hash(str){
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0) / 4294967296;
  }
  function cum(arr){ let s = 0; return arr.map(v => (s += v, s)); }

  function buildForecast(portfolio, opts={}){
    const startYear    = opts.startYear    || 2011;
    const simStartYear = opts.simStartYear || 2026;
    const endYear      = opts.endYear      || 2040;
    const years = [];
    for (let y = startYear; y <= endYear; y++) years.push(y);
    const simStartIdx = years.indexOf(simStartYear);
    const horizon = years.length;

    const seedKey = portfolio?.id || portfolio?.name || "cepres";
    const committedScale = (portfolio?.committed || 1800);

    const contrib = years.map((_y, i) => {
      const t = i / (horizon - 1);
      const tSim = (i - simStartIdx) / (horizon - simStartIdx);
      const prof = Math.exp(-Math.pow((t - 0.45) / 0.22, 2)) * 1.0
                 + Math.exp(-Math.pow((t - 0.56) / 0.10, 2)) * 0.35;
      const decay = i > simStartIdx ? Math.max(0, 1 - tSim * 1.4) : 1;
      const noise = 0.88 + hash(seedKey + "C" + i) * 0.24;
      return -(prof * decay * noise * committedScale * 0.12);
    });
    const distrib = years.map((_y, i) => {
      const t = i / (horizon - 1);
      const prof = Math.exp(-Math.pow((t - 0.62) / 0.14, 2)) * 1.30
                 + Math.exp(-Math.pow((t - 0.78) / 0.18, 2)) * 0.90;
      const noise = 0.88 + hash(seedKey + "D" + i) * 0.24;
      return prof * noise * committedScale * 0.20;
    });
    const net = years.map((_y, i) => +(contrib[i] + distrib[i]).toFixed(2));
    const cumContrib = cum(contrib);
    const cumDistrib = cum(distrib);
    const cumNet     = cum(net);

    const nav = [];
    let cc = 0, cd = 0;
    years.forEach((_y, i) => {
      cc += -contrib[i];
      cd += distrib[i];
      const t = i / (horizon - 1);
      const appr = 1 + Math.sin(Math.min(t, 0.6) * Math.PI / 0.6) * 0.55 + t * 0.1;
      const val = Math.max(0, cc * appr - cd);
      nav.push(val);
    });

    // Per-year distributions (used for prob charts AND the per-chart aligned table).
    function sigmaFor(mean, i, base){
      const sim = i >= simStartIdx;
      const t = sim ? (i - simStartIdx) / Math.max(1, horizon - simStartIdx) : 0;
      const scale = Math.abs(mean) * 0.06 + Math.abs(base) * 0.02;
      return sim ? scale * (1 + t * 2.8) : scale * 0.15;
    }
    function distSeries(arr, base){
      return arr.map((mean, i) => {
        const sigma = sigmaFor(mean, i, base);
        const p10 = mean - 1.28 * sigma;
        const p90 = mean + 1.28 * sigma;
        const min = mean - 3.0  * sigma;
        const max = mean + 3.0  * sigma;
        return { year: years[i], mean, std: sigma, p10, p90, min, max, isSim: i >= simStartIdx };
      });
    }
    const yearDist = {
      contrib: distSeries(contrib, committedScale * 0.05),
      distrib: distSeries(distrib, committedScale * 0.05),
      net:     distSeries(net,     committedScale * 0.04),
      nav:     distSeries(nav,     committedScale * 0.10),
    };

    // Flat p10/p90 arrays for easy chart consumption.
    const p10 = {
      contrib: yearDist.contrib.map(d => d.p10),
      distrib: yearDist.distrib.map(d => d.p10),
      net:     yearDist.net    .map(d => d.p10),
      nav:     yearDist.nav    .map(d => d.p10),
    };
    const p90 = {
      contrib: yearDist.contrib.map(d => d.p90),
      distrib: yearDist.distrib.map(d => d.p90),
      net:     yearDist.net    .map(d => d.p90),
      nav:     yearDist.nav    .map(d => d.p90),
    };
    const cumP10 = { contrib: cum(p10.contrib), distrib: cum(p10.distrib), net: cum(p10.net) };
    const cumP90 = { contrib: cum(p90.contrib), distrib: cum(p90.distrib), net: cum(p90.net) };

    // Per-dimension breakdowns (stacked composition).
    const byDim = {};
    DIMS.forEach(dim => {
      if (dim.key === "none") return;
      const vals = dim.values;
      const wRaw = vals.map((v, i) => 0.45 + hash(seedKey + dim.key + v + i) * 1.6);
      const wSum = wRaw.reduce((a,b) => a+b, 0);
      const weights = wRaw.map(w => w / wSum);
      byDim[dim.key] = vals.map((v, vi) => ({
        label: v,
        color: PALETTE[vi % PALETTE.length],
        contrib: years.map((_, i) => contrib[i] * weights[vi]),
        distrib: years.map((_, i) => distrib[i] * weights[vi]),
        net:     years.map((_, i) => net[i]     * weights[vi]),
        nav:     years.map((_, i) => nav[i]     * weights[vi]),
      }));
    });

    // "Key moments" for the quick summary strip.
    const peakNavIdx = nav.indexOf(Math.max(...nav));
    const firstPositiveCumNetIdx = cumNet.findIndex(v => v >= 0);
    const firstDistribIdx = distrib.findIndex(v => v > committedScale * 0.01);
    const keyMoments = {
      peakNavYear:     years[peakNavIdx],
      peakNavValue:    nav[peakNavIdx],
      breakevenYear:   firstPositiveCumNetIdx >= 0 ? years[firstPositiveCumNetIdx] : null,
      firstDistribYear: firstDistribIdx >= 0 ? years[firstDistribIdx] : null,
      totalContrib:    cumContrib[horizon - 1],
      totalDistrib:    cumDistrib[horizon - 1],
      totalNet:        cumNet[horizon - 1],
    };

    return {
      years, simStartIdx, simStartYear,
      contrib, distrib, net, nav,
      cumContrib, cumDistrib, cumNet,
      p10, p90, cumP10, cumP90,
      byDim, yearDist, keyMoments,
      COL, METRIC,
    };
  }

  // ---- Small utilities ----
  function niceTicks(lo, hi, target = 5){
    const span = hi - lo;
    if (span === 0) return [lo];
    const raw = span / target;
    const pow = Math.pow(10, Math.floor(Math.log10(raw)));
    const norm = raw / pow;
    const step = (norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10) * pow;
    const start = Math.floor(lo / step) * step;
    const ticks = [];
    for (let v = start; v <= hi + step * 0.001; v += step) ticks.push(+v.toFixed(10));
    return ticks;
  }
  function fmtM(v){
    if (!Number.isFinite(v)) return "—";
    const a = Math.abs(v);
    if (a >= 1000) return (v < 0 ? "-" : "") + (Math.abs(v)/1000).toFixed(1) + "k";
    return Math.round(v).toString();
  }
  function fmtMDetail(v){ return (v >= 0 ? "" : "-") + "$" + Math.abs(v).toFixed(0) + "M"; }

  function SimStartLine({ x, y0, y1 }){
    return React.createElement("g", { className: "fc-sim-line" },
      React.createElement("line", { x1: x, x2: x, y1: y0, y2: y1,
        stroke: COL.simLine, strokeWidth: 1, strokeDasharray: "3 3", opacity: 0.6 }),
      React.createElement("text", { x: x + 6, y: y0 + 12, fontSize: 11, fill: "var(--ink)" },
        "Simulation start")
    );
  }

  // ============================================================
  // Aligned footer — HTML table below each SVG that shares column widths
  // ============================================================
  function AlignedFooter({ years, simStartIdx, rows, padLeftPct, padRightPct, activeKey }){
    // rows: [{ key?, label, values: [...], tone?: "muted"|"accent"|"contrib"|"distrib" }, ...]
    // activeKey: when set, row with matching `key` gets an .is-active treatment
    return React.createElement("div", { className: "fc-aligned-footer",
      style: { paddingLeft: `${padLeftPct}%`, paddingRight: `${padRightPct}%` } },
      React.createElement("div", { className: "fc-af-year-row" },
        React.createElement("div", { className: "fc-af-label" }),
        React.createElement("div", { className: "fc-af-values",
          style: { gridTemplateColumns: `repeat(${years.length}, 1fr)` } },
          years.map((y, i) => React.createElement("div", {
            key: y,
            className: "fc-af-year" + (i === simStartIdx ? " is-sim-start" : "") +
                       (i >= simStartIdx ? " is-sim" : " is-hist")
          }, y))
        )
      ),
      rows.map((r, ri) => {
        const isActive = activeKey && r.key === activeKey;
        return React.createElement("div", {
          key: r.key || ri,
          className: "fc-af-row" + (r.tone ? " is-" + r.tone : "") + (isActive ? " is-active" : "")
        },
          React.createElement("div", { className: "fc-af-label" }, r.label),
          React.createElement("div", { className: "fc-af-values",
            style: { gridTemplateColumns: `repeat(${years.length}, 1fr)` } },
            r.values.map((v, i) => React.createElement("div", {
              key: i,
              className: "fc-af-val" + (i >= simStartIdx ? " is-sim" : " is-hist"),
              title: `${years[i]}: ${fmtMDetail(v)}`
            }, fmtM(v)))
          )
        );
      })
    );
  }

  // Small badge that tells the user which scenario (percentile) the chart is rendering.
  // When `pct` is "p50" the chart is neutral and the badge is hidden.
  function ScenarioBadge({ pct }){
    if (!pct || pct === "p50") return null;
    const isOpt = pct === "p90";
    return React.createElement("span", {
      className: "fc-scenario-badge " + (isOpt ? "is-opt" : "is-pess")
    },
      React.createElement("span", { className: "fc-scenario-badge-dot" }),
      isOpt ? "Optimistic · P90" : "Pessimistic · P10"
    );
  }

  // ============================================================
  // Percentile toggle (P10 / P50 / P90) — reuses .seg
  // ============================================================
  function PercentileSeg({ value, onChange }){
    return React.createElement("div", { className: "seg fc-pct-seg" },
      [["p10","P10"], ["p50","P50"], ["p90","P90"]].map(([k, lbl]) =>
        React.createElement("button", {
          key: k,
          className: value === k ? "is-active" : "",
          onClick: () => onChange(k)
        }, lbl)
      )
    );
  }

  // ============================================================
  // Primary cashflow bar charts (NAV / Cumulative / Annual)
  // Each accepts `percentile` prop; the selected series drives the bars,
  // the footer always shows all three rows.
  // ============================================================

  // NAV trajectory (gold bars)
  // `showUncertainty` controls whether the data table below the chart includes
  // P10/P90 rows. Immediate forecast = mean only; full simulation = all 3.
  function NAVBarChart({ data, percentile = "p50", height = 280, showUncertainty = true }){
    const { years, nav, simStartIdx } = data;
    const series = percentile === "p10" ? data.p10.nav
                 : percentile === "p90" ? data.p90.nav
                 : nav;

    const W = 1200, H = height;
    const padL = 52, padR = 16, padT = 22, padB = 42;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;

    const yMax = Math.max(...series, ...data.p90.nav) * 1.08 || 1;
    const ticks = niceTicks(0, yMax, 6);
    const groupW = innerW / years.length;
    const barW = Math.min(28, groupW * 0.62);
    const xs = (i) => padL + i * groupW + groupW / 2;
    const ys = (v) => padT + innerH - (v / yMax) * innerH;

    return React.createElement(React.Fragment, null,
      React.createElement("div", { className: "fc-chart-body" },
        React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height, style: { display: "block" } },
          ticks.map(t => React.createElement("g", { key: t },
            React.createElement("line", { x1: padL, x2: padL + innerW, y1: ys(t), y2: ys(t),
              stroke: COL.grid, strokeDasharray: t === 0 ? "" : "3 3" }),
            React.createElement("text", { x: padL - 8, y: ys(t) + 3, fontSize: 10, fill: COL.axis, textAnchor: "end" },
              fmtM(t))
          )),
          React.createElement(SimStartLine, {
            x: padL + simStartIdx * groupW + groupW / 2, y0: padT, y1: padT + innerH
          }),
          years.map((y, i) => {
            const v = series[i];
            const h = Math.max(1.5, (v / yMax) * innerH);
            const isSim = i >= simStartIdx;
            return React.createElement("g", { key: y },
              React.createElement("rect", {
                x: xs(i) - barW/2, y: ys(v), width: barW, height: h,
                fill: isSim ? COL.nav : COL.navHx, rx: 1.5
              }),
              v >= yMax * 0.04 && React.createElement("text", {
                x: xs(i), y: ys(v) - 4, fontSize: 9.5, fill: "var(--ink)", textAnchor: "middle"
              }, Math.round(v))
            );
          })
        )
      ),
      React.createElement(AlignedFooter, {
        years, simStartIdx, activeKey: percentile,
        padLeftPct:  (padL / W) * 100,
        padRightPct: (padR / W) * 100,
        rows: showUncertainty ? [
          { key: "p90", label: "P90",  values: data.p90.nav, tone: "muted" },
          { key: "p50", label: "Mean", values: data.nav,     tone: "accent" },
          { key: "p10", label: "P10",  values: data.p10.nav, tone: "muted" },
        ] : [
          { key: "p50", label: "Mean", values: data.nav, tone: "accent" },
        ]
      })
    );
  }

  // Cumulative cashflows (stacked negatives/positives + cum net line)
  function CumulativeCashflowChart({ data, percentile = "p50", height = 310 }){
    const { years, simStartIdx } = data;
    const cumContrib = percentile === "p10" ? data.cumP10.contrib
                     : percentile === "p90" ? data.cumP90.contrib
                     : data.cumContrib;
    const cumDistrib = percentile === "p10" ? data.cumP10.distrib
                     : percentile === "p90" ? data.cumP90.distrib
                     : data.cumDistrib;
    const cumNet     = percentile === "p10" ? data.cumP10.net
                     : percentile === "p90" ? data.cumP90.net
                     : data.cumNet;

    const W = 1200, H = height;
    const padL = 58, padR = 16, padT = 22, padB = 42;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;

    const yMax = Math.max(...data.cumP90.distrib, ...data.cumP90.net) * 1.10 || 1;
    const yMin = Math.min(...data.cumP10.contrib, ...data.cumP10.net) * 1.10 || -1;
    const ticks = niceTicks(yMin, yMax, 8);
    const groupW = innerW / years.length;
    const barW = Math.min(24, groupW * 0.58);

    const yScale = (v) => padT + innerH - ((v - yMin) / (yMax - yMin)) * innerH;
    const xs = (i) => padL + i * groupW + groupW / 2;
    const zero = yScale(0);

    const netPath = years.map((_, i) =>
      `${i === 0 ? "M" : "L"} ${xs(i)} ${yScale(cumNet[i])}`).join(" ");

    return React.createElement(React.Fragment, null,
      React.createElement("div", { className: "fc-chart-body" },
        React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height, style: { display: "block" } },
          ticks.map(t => React.createElement("g", { key: t },
            React.createElement("line", { x1: padL, x2: padL + innerW, y1: yScale(t), y2: yScale(t),
              stroke: t === 0 ? "var(--black-40)" : COL.grid,
              strokeDasharray: t === 0 ? "" : "3 3" }),
            React.createElement("text", { x: padL - 8, y: yScale(t) + 3, fontSize: 10, fill: COL.axis, textAnchor: "end" },
              (t < 0 ? "-" : "") + fmtM(Math.abs(t)))
          )),
          React.createElement(SimStartLine, {
            x: padL + simStartIdx * groupW + groupW / 2, y0: padT, y1: padT + innerH
          }),
          years.map((y, i) => {
            const cC = cumContrib[i];
            const cD = cumDistrib[i];
            return React.createElement("g", { key: y },
              React.createElement("rect", {
                x: xs(i) - barW/2, y: zero,
                width: barW, height: Math.max(1, yScale(cC) - zero),
                fill: COL.contrib, rx: 1.5
              }),
              React.createElement("rect", {
                x: xs(i) - barW/2, y: yScale(cD),
                width: barW, height: Math.max(1, zero - yScale(cD)),
                fill: COL.distrib, rx: 1.5
              })
            );
          }),
          React.createElement("path", { d: netPath, stroke: COL.net, strokeWidth: 2.25, fill: "none" }),
          years.map((_, i) => React.createElement("circle", {
            key: i, cx: xs(i), cy: yScale(cumNet[i]), r: 2, fill: COL.net
          }))
        )
      ),
      React.createElement(AlignedFooter, {
        years, simStartIdx,
        padLeftPct:  (padL / W) * 100,
        padRightPct: (padR / W) * 100,
        rows: [
          { label: "Cum. Contrib", values: cumContrib, tone: "contrib" },
          { label: "Cum. Distrib", values: cumDistrib, tone: "distrib" },
          { label: "Cum. Net",     values: cumNet,     tone: "accent" },
        ]
      })
    );
  }

  // Annual cashflows (paired bars + net line)
  function AnnualCashflowChart({ data, percentile = "p50", height = 280 }){
    const { years, simStartIdx } = data;
    const contrib = percentile === "p10" ? data.p10.contrib
                  : percentile === "p90" ? data.p90.contrib : data.contrib;
    const distrib = percentile === "p10" ? data.p10.distrib
                  : percentile === "p90" ? data.p90.distrib : data.distrib;
    const net     = percentile === "p10" ? data.p10.net
                  : percentile === "p90" ? data.p90.net : data.net;

    const W = 1200, H = height;
    const padL = 52, padR = 16, padT = 22, padB = 42;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;

    const yMax = Math.max(...data.p90.distrib, ...data.p90.net) * 1.15 || 1;
    const yMin = Math.min(...data.p10.contrib, ...data.p10.net) * 1.15 || -1;
    const ticks = niceTicks(yMin, yMax, 8);
    const groupW = innerW / years.length;
    const barW = Math.min(20, groupW * 0.40);

    const yScale = (v) => padT + innerH - ((v - yMin) / (yMax - yMin)) * innerH;
    const xs = (i) => padL + i * groupW + groupW / 2;
    const zero = yScale(0);
    const netPath = years.map((_, i) => `${i === 0 ? "M" : "L"} ${xs(i)} ${yScale(net[i])}`).join(" ");

    return React.createElement(React.Fragment, null,
      React.createElement("div", { className: "fc-chart-body" },
        React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height, style: { display: "block" } },
          ticks.map(t => React.createElement("g", { key: t },
            React.createElement("line", { x1: padL, x2: padL + innerW, y1: yScale(t), y2: yScale(t),
              stroke: t === 0 ? "var(--black-40)" : COL.grid,
              strokeDasharray: t === 0 ? "" : "3 3" }),
            React.createElement("text", { x: padL - 8, y: yScale(t) + 3, fontSize: 10, fill: COL.axis, textAnchor: "end" },
              (t < 0 ? "-" : "") + fmtM(Math.abs(t)))
          )),
          React.createElement(SimStartLine, {
            x: padL + simStartIdx * groupW + groupW / 2, y0: padT, y1: padT + innerH
          }),
          years.map((y, i) => {
            const c = contrib[i];
            const d = distrib[i];
            return React.createElement("g", { key: y },
              React.createElement("rect", {
                x: xs(i) - barW - 1, y: zero, width: barW, height: Math.max(1, yScale(c) - zero),
                fill: COL.contrib, rx: 1.5
              }),
              React.createElement("rect", {
                x: xs(i) + 1, y: yScale(d), width: barW, height: Math.max(1, zero - yScale(d)),
                fill: COL.distrib, rx: 1.5
              })
            );
          }),
          React.createElement("path", { d: netPath, stroke: COL.net, strokeWidth: 2.25, fill: "none" }),
          years.map((_, i) => React.createElement("circle", {
            key: i, cx: xs(i), cy: yScale(net[i]), r: 2, fill: COL.net
          }))
        )
      ),
      React.createElement(AlignedFooter, {
        years, simStartIdx,
        padLeftPct:  (padL / W) * 100,
        padRightPct: (padR / W) * 100,
        rows: [
          { label: "Contribution", values: contrib, tone: "contrib" },
          { label: "Distribution", values: distrib, tone: "distrib" },
          { label: "Net",          values: net,     tone: "accent" },
        ]
      })
    );
  }

  // ============================================================
  // Composition chart — generalized to any metric (nav/contrib/distrib)
  // Single chart component; dimension + metric passed in.
  // ============================================================
  function CompositionChart({ data, metric, dim = "none", height = 290, showUncertainty = true }){
    const { years, simStartIdx, byDim } = data;
    const metricSeries = data[metric];
    const series = dim === "none" ? null : byDim[dim];
    const meta = METRIC[metric];

    const W = 1200, H = height;
    const padL = 54, padR = 16, padT = 22, padB = 42;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;

    const isNeg = meta.stackNegative && metricSeries.some(v => v < 0);
    const totals = years.map((_, i) => metricSeries[i]);
    const yMax = Math.max(...totals.map(v => Math.max(0, v))) * 1.15 || 0;
    const yMin = isNeg ? Math.min(...totals.map(v => Math.min(0, v))) * 1.15 : 0;
    const ticks = niceTicks(yMin, yMax, 7);
    const groupW = innerW / years.length;
    const barW = Math.min(28, groupW * 0.62);
    const xs = (i) => padL + i * groupW + groupW / 2;
    const yScale = (v) => padT + innerH - ((v - yMin) / (yMax - yMin || 1)) * innerH;
    const zero = yScale(0);

    return React.createElement(React.Fragment, null,
      series && React.createElement("div", { className: "fc-legend-top" },
        series.map(s => React.createElement("span", { key: s.label, className: "fc-legend-item" },
          React.createElement("span", { className: "dot", style: { background: s.color } }),
          s.label
        ))
      ),
      React.createElement("div", { className: "fc-chart-body" },
        React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height, style: { display: "block" } },
          ticks.map(t => React.createElement("g", { key: t },
            React.createElement("line", { x1: padL, x2: padL + innerW, y1: yScale(t), y2: yScale(t),
              stroke: t === 0 ? "var(--black-40)" : COL.grid,
              strokeDasharray: t === 0 ? "" : "3 3" }),
            React.createElement("text", { x: padL - 8, y: yScale(t) + 3, fontSize: 10, fill: COL.axis, textAnchor: "end" },
              (t < 0 ? "-" : "") + fmtM(Math.abs(t)))
          )),
          React.createElement(SimStartLine, {
            x: padL + simStartIdx * groupW + groupW / 2, y0: padT, y1: padT + innerH
          }),
          years.map((y, i) => {
            const total = metricSeries[i];
            const isSim = i >= simStartIdx;
            if (!series) {
              return React.createElement("g", { key: y },
                React.createElement("rect", {
                  x: xs(i) - barW/2,
                  y: total >= 0 ? yScale(total) : zero,
                  width: barW,
                  height: Math.max(1, Math.abs(yScale(total) - zero)),
                  fill: isSim ? meta.color : meta.colorHx, rx: 1.5
                }),
                Math.abs(total) >= Math.abs(yMax - yMin) * 0.04 && React.createElement("text", {
                  x: xs(i), y: total >= 0 ? yScale(total) - 4 : yScale(total) + 11,
                  fontSize: 9.5, fill: "var(--ink)", textAnchor: "middle"
                }, Math.round(total))
              );
            }
            // stacked — handle both sign stacks (for contrib, all negative; for distrib/nav, all positive)
            let accPos = 0, accNeg = 0;
            return React.createElement("g", { key: y },
              series.map((s, si) => {
                const v = s[metric][i];
                if (v === 0) return null;
                if (v > 0) {
                  const top = yScale(accPos + v);
                  const segH = Math.max(0.5, yScale(accPos) - top);
                  accPos += v;
                  return React.createElement("rect", {
                    key: si, x: xs(i) - barW/2, y: top, width: barW, height: segH,
                    fill: s.color, stroke: "#fff", strokeWidth: 0.4
                  });
                } else {
                  const bot = yScale(accNeg + v);
                  const segH = Math.max(0.5, bot - yScale(accNeg));
                  const top = yScale(accNeg);
                  accNeg += v;
                  return React.createElement("rect", {
                    key: si, x: xs(i) - barW/2, y: top, width: barW, height: segH,
                    fill: s.color, stroke: "#fff", strokeWidth: 0.4
                  });
                }
              }),
              Math.abs(total) >= Math.abs(yMax - yMin) * 0.04 && React.createElement("text", {
                x: xs(i), y: total >= 0 ? yScale(total) - 4 : yScale(total) + 11,
                fontSize: 9.5, fill: "var(--ink)", textAnchor: "middle"
              }, Math.round(total))
            );
          })
        )
      ),
      React.createElement(AlignedFooter, {
        years, simStartIdx,
        padLeftPct:  (padL / W) * 100,
        padRightPct: (padR / W) * 100,
        rows: showUncertainty ? [
          { label: "P90",   values: data.p90[metric], tone: "muted" },
          { label: "Total", values: metricSeries, tone: "accent" },
          { label: "P10",   values: data.p10[metric], tone: "muted" },
        ] : [
          { label: "Total", values: metricSeries, tone: "accent" },
        ]
      })
    );
  }

  // Chip-segment filter (replaces old radio UX)
  function ChipFilter({ value, onChange }){
    return React.createElement("div", { className: "fc-chip-filter" },
      DIMS.map(d => React.createElement("button", {
        key: d.key,
        className: "fc-chip" + (value === d.key ? " is-on" : ""),
        onClick: () => onChange(d.key)
      }, d.label))
    );
  }

  // ============================================================
  // Detail table — shared between all consumers
  // ============================================================
  function DetailTable({ data }){
    const { years, simStartIdx, contrib, distrib, net, nav, cumContrib, cumDistrib, cumNet } = data;
    return React.createElement("div", { className: "fc-table-wrap" },
      React.createElement("table", { className: "fc-table fc-detail-table" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", { className: "sticky-col" }, "Year"),
            React.createElement("th", { className: "num" }, "Contribution"),
            React.createElement("th", { className: "num" }, "Distribution"),
            React.createElement("th", { className: "num" }, "Net"),
            React.createElement("th", { className: "num" }, "NAV"),
            React.createElement("th", { className: "num num-grouped" }, "Cum. Contrib."),
            React.createElement("th", { className: "num num-grouped" }, "Cum. Distrib."),
            React.createElement("th", { className: "num num-grouped" }, "Cum. Net")
          )
        ),
        React.createElement("tbody", null,
          years.map((y, i) => {
            const isSim = i >= simStartIdx;
            return React.createElement("tr", { key: y, className: isSim ? "is-sim" : "is-hist" },
              React.createElement("td", { className: "sticky-col year-cell" }, y,
                i === simStartIdx && React.createElement("span", { className: "sim-pill" }, "Sim start")),
              React.createElement("td", { className: "num neg" }, contrib[i].toFixed(1)),
              React.createElement("td", { className: "num pos" }, "+" + distrib[i].toFixed(1)),
              React.createElement("td", { className: "num strong", style: { color: net[i] >= 0 ? "var(--green)" : "#AF2323" } },
                (net[i] >= 0 ? "+" : "") + net[i].toFixed(1)),
              React.createElement("td", { className: "num" }, nav[i].toFixed(1)),
              React.createElement("td", { className: "num num-grouped neg" }, cumContrib[i].toFixed(1)),
              React.createElement("td", { className: "num num-grouped pos" }, "+" + cumDistrib[i].toFixed(1)),
              React.createElement("td", { className: "num num-grouped strong",
                style: { color: cumNet[i] >= 0 ? "var(--green)" : "#AF2323" } },
                (cumNet[i] >= 0 ? "+" : "") + cumNet[i].toFixed(1))
            );
          })
        )
      )
    );
  }

  // ============================================================
  // KEY MOMENTS strip — quick summary at the top of the cashflows tab
  // ============================================================
  function KeyMomentsStrip({ data }){
    const k = data.keyMoments;
    const items = [
      { lbl: "Peak NAV",        val: k.peakNavYear,   sub: "$" + Math.round(k.peakNavValue) + "M",
        icon: "▲", accent: COL.nav },
      { lbl: "First distribution", val: k.firstDistribYear || "—", sub: "positive distribution",
        icon: "→", accent: COL.distrib },
      { lbl: "Cum. net turns positive", val: k.breakevenYear || "—", sub: "break-even year",
        icon: "=", accent: COL.net },
      { lbl: "Total contribution", val: "$" + Math.round(Math.abs(k.totalContrib)) + "M", sub: "over horizon",
        icon: "↓", accent: COL.contrib },
      { lbl: "Total distribution", val: "$" + Math.round(k.totalDistrib) + "M", sub: "over horizon",
        icon: "↑", accent: COL.distrib },
      { lbl: "Net result",         val: "$" + Math.round(k.totalNet) + "M", sub: "cum. net at end",
        icon: "Σ", accent: COL.net },
    ];
    return React.createElement("div", { className: "fc-key-strip" },
      items.map((it, i) => React.createElement("div", { key: i, className: "fc-key-item" },
        React.createElement("div", { className: "fc-key-icon", style: { color: it.accent, borderColor: it.accent + "55" } }, it.icon),
        React.createElement("div", { className: "fc-key-text" },
          React.createElement("div", { className: "fc-key-lbl" }, it.lbl),
          React.createElement("div", { className: "fc-key-val" }, it.val),
          React.createElement("div", { className: "fc-key-sub" }, it.sub)
        )
      ))
    );
  }

  // ============================================================
  // CashflowsSection — 3 main charts, each with optional P10/P50/P90 toggle
  // ============================================================
  function ChartCard({ title, sub, badge, legend, toolbar, children }){
    return React.createElement("div", { className: "fc-card" },
      React.createElement("div", { className: "fc-card-head" },
        React.createElement("div", { className: "fc-card-head-left" },
          React.createElement("div", { className: "card-title" }, title, badge),
          sub && React.createElement("div", { className: "card-sub" }, sub)
        ),
        React.createElement("div", { className: "fc-card-head-right" },
          legend,
          toolbar
        )
      ),
      children
    );
  }

  function CashflowsSection({ data, showUncertainty = false }){
    const [navPct, setNavPct] = React.useState("p50");
    const [cumPct, setCumPct] = React.useState("p50");
    const [annPct, setAnnPct] = React.useState("p50");

    return React.createElement(React.Fragment, null,
      // Key moments strip at the top
      React.createElement(KeyMomentsStrip, { data }),

      // NAV trajectory
      React.createElement(ChartCard, {
        title: "NAV trajectory",
        sub: "Portfolio net asset value year by year — historical (lighter) vs simulated (gold)",
        badge: showUncertainty && React.createElement(ScenarioBadge, { pct: navPct }),
        legend: React.createElement("div", { className: "fc-legend-inline" },
          React.createElement("span", null,
            React.createElement("span", { className: "dot", style: { background: COL.nav } }),
            "NAV · " + (navPct === "p10" ? "pessimistic" : navPct === "p90" ? "optimistic" : "median scenario"))
        ),
        toolbar: showUncertainty && React.createElement(PercentileSeg, { value: navPct, onChange: setNavPct })
      },
        React.createElement(NAVBarChart, { data, percentile: navPct, showUncertainty })
      ),

      // Cumulative cashflow
      React.createElement(ChartCard, {
        title: "Cumulative cashflows",
        sub: "Running totals — contributions below zero, distributions above, cum. net as teal line",
        badge: showUncertainty && React.createElement(ScenarioBadge, { pct: cumPct }),
        legend: React.createElement("div", { className: "fc-legend-inline" },
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: COL.contrib } }), "Contrib"),
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: COL.distrib } }), "Distrib"),
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: COL.net } }), "Net")
        ),
        toolbar: showUncertainty && React.createElement(PercentileSeg, { value: cumPct, onChange: setCumPct })
      },
        React.createElement(CumulativeCashflowChart, { data, percentile: cumPct })
      ),

      // Annual cashflow
      React.createElement(ChartCard, {
        title: "Annual cashflows",
        sub: "Per-year contribution, distribution and net — the line traces annual net cashflow",
        badge: showUncertainty && React.createElement(ScenarioBadge, { pct: annPct }),
        legend: React.createElement("div", { className: "fc-legend-inline" },
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: COL.contrib } }), "Contrib"),
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: COL.distrib } }), "Distrib"),
          React.createElement("span", null, React.createElement("span", { className: "dot", style: { background: COL.net } }), "Net")
        ),
        toolbar: showUncertainty && React.createElement(PercentileSeg, { value: annPct, onChange: setAnnPct })
      },
        React.createElement(AnnualCashflowChart, { data, percentile: annPct })
      )
    );
  }

  // ============================================================
  // CompositionSection — 3 composition charts with per-chart chip filter
  // ============================================================
  function CompositionCard({ data, metric, title, sub, showUncertainty = true }){
    const [dim, setDim] = React.useState("none");
    const meta = METRIC[metric];
    return React.createElement("div", { className: "fc-card" },
      React.createElement("div", { className: "fc-card-head" },
        React.createElement("div", { className: "fc-card-head-left" },
          React.createElement("div", { className: "card-title" }, title),
          sub && React.createElement("div", { className: "card-sub" }, sub)
        )
      ),
      React.createElement("div", { className: "fc-comp-toolbar" },
        React.createElement("span", { className: "fc-comp-lbl" }, "Break down by"),
        React.createElement(ChipFilter, { value: dim, onChange: setDim })
      ),
      React.createElement(CompositionChart, { data, metric, dim, showUncertainty })
    );
  }

  function CompositionSection({ data, showUncertainty = true }){
    return React.createElement(React.Fragment, null,
      React.createElement(CompositionCard, {
        data, metric: "nav", showUncertainty,
        title: "NAV composition",
        sub: "Break NAV down by type, region, stage or vintage to see the drivers of portfolio value"
      }),
      React.createElement(CompositionCard, {
        data, metric: "contrib", showUncertainty,
        title: "Contribution composition",
        sub: "Where is capital being called? Split annual contributions by dimension."
      }),
      React.createElement(CompositionCard, {
        data, metric: "distrib", showUncertainty,
        title: "Distribution composition",
        sub: "Which parts of the portfolio are returning capital? Annual distributions by dimension."
      })
    );
  }

  // ============================================================
  // DetailSection — simple wrapper around the full table
  // ============================================================
  function DetailSection({ data }){
    return React.createElement("div", { className: "fc-card" },
      React.createElement("div", { className: "fc-card-head" },
        React.createElement("div", { className: "fc-card-head-left" },
          React.createElement("div", { className: "card-title" }, "Year-by-year detail"),
          React.createElement("div", { className: "card-sub" },
            "All cashflow metrics in $M — contribution, distribution, net, NAV, and cumulative counterparts")
        ),
        React.createElement(PI.Btn, { kind: "ghost", size: "sm",
          icon: React.createElement(PI.Icon.Download, { size: 13 }) }, "Export CSV")
      ),
      React.createElement(DetailTable, { data })
    );
  }

  // ============================================================
  // Legacy ForecastChartsBlock — used by detail.jsx (immediate forecast).
  // Renders cashflows + composition + detail, no uncertainty toggle by default.
  // ============================================================
  function ForecastChartsBlock({ portfolio, showUncertainty = false }){
    const data = React.useMemo(() => buildForecast(portfolio), [portfolio?.id]);
    return React.createElement(React.Fragment, null,
      React.createElement(CashflowsSection, { data, showUncertainty }),
      React.createElement("div", { style: { height: 16 } }),
      React.createElement(CompositionSection, { data, showUncertainty }),
      React.createElement("div", { style: { height: 16 } }),
      React.createElement(DetailSection, { data })
    );
  }

  // ============================================================
  // Legacy probability histogram (used by TVPI / IRR / DPI cards elsewhere)
  // ============================================================
  function ProbDistribution({ mean, p10, p90, unit = "x", title, accent = "var(--green)", height = 140, seed = 1 }){
    const bins = 26;
    const data = new Array(bins).fill(0);
    const seeded = (s) => { let x = s | 1; return () => { x = (x * 1664525 + 1013904223) >>> 0; return x / 4294967296; }; };
    const rng = seeded(seed);
    for (let i = 0; i < 8000; i++) {
      const u = (rng() + rng() + rng()) / 3;
      data[Math.min(bins - 1, Math.floor(u * bins))]++;
    }
    const max = Math.max(...data);
    const span = p90 - p10 || 1;
    const valAt = (i) => p10 - span * 0.2 + (i / (bins - 1)) * span * 1.4;
    const W = 380, H = height, padL = 8, padR = 8, padT = 6, padB = 24;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;
    const barW = innerW / bins;
    const meanIdx = Math.round(((mean - (p10 - span * 0.2)) / (span * 1.4)) * (bins - 1));
    const fmt = (v) => unit === "x" ? v.toFixed(2) + "×"
                    : unit === "%" ? (v * 100).toFixed(1) + "%"
                    : "$" + Math.round(v) + "M";
    return React.createElement("div", null,
      title && React.createElement("div", { className: "eyebrow", style: { marginBottom: 8 } }, title),
      React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height, style: { display: "block" } },
        data.map((v, i) => {
          const h = (v / max) * innerH;
          const x = padL + i * barW;
          const y = padT + innerH - h;
          const isMean = i === meanIdx;
          return React.createElement("rect", {
            key: i, x: x + 0.5, y, width: Math.max(1, barW - 1), height: h,
            fill: accent, opacity: isMean ? 1 : (0.35 + (1 - Math.abs(i - meanIdx) / bins) * 0.4)
          });
        }),
        React.createElement("line", {
          x1: padL + (meanIdx + 0.5) * barW, x2: padL + (meanIdx + 0.5) * barW,
          y1: padT, y2: padT + innerH, stroke: "var(--ink)", strokeWidth: 1, strokeDasharray: "3 2"
        })
      )
    );
  }

  // ---- Exports ----
  Object.assign(window.PI, {
    FC_DIMS: DIMS,
    FC_PALETTE: PALETTE,
    FC_COL: COL,
    FC_METRIC: METRIC,
    fcBuildForecast: buildForecast,
    FCCashflowsSection:   CashflowsSection,
    FCCompositionSection: CompositionSection,
    FCDetailSection:      DetailSection,
    FCKeyMomentsStrip:    KeyMomentsStrip,
    FCProbDistribution:   ProbDistribution,
    ForecastChartsBlock,
  });
})();
