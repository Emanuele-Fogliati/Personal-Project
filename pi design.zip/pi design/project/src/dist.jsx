/* Donut/pie distribution charts + aggregator */

// Heavy + light chart palettes — rotate so adjacent slices contrast
const CHART_COLORS = [
  "#00437F", "#058F8A", "#B56624", "#7B267F", "#025100",
  "#AF2323", "#B7D6E5", "#E5C279", "#E0B7E5", "#B7E2B5",
  "#858585", "#2F3E55"
];

function Donut({ segments, total, size=96 }) {
  const r = 38, cx = 48, cy = 48, stroke = 14;
  const circ = 2 * Math.PI * r;
  let offset = 0;
  const parts = segments.map((s, i) => {
    const frac = s.value / (total || 1);
    const len = circ * frac;
    const dasharray = `${len} ${circ - len}`;
    const dashoffset = -offset;
    offset += len;
    return React.createElement("circle", {
      key: i, cx, cy, r, fill: "none",
      stroke: CHART_COLORS[i % CHART_COLORS.length],
      strokeWidth: stroke, strokeDasharray: dasharray, strokeDashoffset: dashoffset,
      transform: `rotate(-90 ${cx} ${cy})`
    });
  });
  return React.createElement("svg", { viewBox: "0 0 96 96", width: size, height: size },
    React.createElement("circle", { cx, cy, r, fill: "none", stroke: "var(--warm)", strokeWidth: stroke }),
    ...parts
  );
}

function DistCard({ title, field, funds, mode, currency="USD" }) {
  const agg = {};
  funds.forEach(f => {
    const key = f[field] ?? "—";
    const val = mode === "value" ? (f.committed || 0) : 1;
    agg[key] = (agg[key] || 0) + val;
  });
  const entries = Object.entries(agg).sort((a,b) => b[1] - a[1]);
  const total = entries.reduce((s, [,v]) => s + v, 0);
  const shown = entries.slice(0, 5);
  const restSum = entries.slice(5).reduce((s, [,v]) => s + v, 0);
  const legendEntries = restSum > 0 ? [...shown, ["Other", restSum]] : shown;
  const segments = legendEntries.map(([k,v]) => ({ label: k, value: v }));

  return React.createElement("div", { className: "dist-card" },
    React.createElement("div", { className: "dist-head" },
      React.createElement("span", { className: "dist-title" }, title),
      React.createElement("span", { className: "dist-sum" },
        mode === "value" ? PI.fmt.money(total, currency) : `${total} funds`)
    ),
    React.createElement("div", { className: "dist-body" },
      React.createElement("div", { className: "dist-chart" },
        React.createElement(Donut, { segments, total })
      ),
      React.createElement("div", { className: "dist-legend" },
        legendEntries.map(([k, v], i) => React.createElement("div", { key: k, className: "dist-legend-row" },
          React.createElement("span", { className: "dist-legend-dot", style: { background: CHART_COLORS[i % CHART_COLORS.length] } }),
          React.createElement("span", { className: "dist-legend-label", title: k }, k),
          React.createElement("span", { className: "dist-legend-val" },
            mode === "value" ? PI.fmt.money(v, currency) : v)
        ))
      )
    )
  );
}

function DistStrip({ funds, mode, setMode, currency }) {
  const dims = [
    { title: "Vintage year", field: "vintage" },
    { title: "Region",       field: "geography" },
    { title: "Stage",        field: "stage" },
    { title: "Type",         field: "type" },
    { title: "Realization status", field: "status" },
  ];
  return React.createElement(PI.Fragment, null,
    React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 } },
      React.createElement("div", { className: "eyebrow" }, "Portfolio breakdown"),
      React.createElement("div", { className: "seg" },
        React.createElement("button", { className: mode === "count" ? "is-active" : "", onClick: () => setMode("count") }, "By number"),
        React.createElement("button", { className: mode === "value" ? "is-active" : "", onClick: () => setMode("value") }, "By total contribution")
      )
    ),
    React.createElement("div", { className: "dist-strip" },
      dims.map(d => React.createElement(DistCard, { key: d.field, ...d, funds, mode, currency }))
    )
  );
}

window.PI.DistStrip = DistStrip;
