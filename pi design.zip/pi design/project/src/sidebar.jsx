/* Sidebar navigation — collapsible */

function Sidebar({ route, onNavigate, collapsed, setCollapsed }) {
  const items = [
    { key: "portfolios",   icon: React.createElement(PI.Icon.Folder, { size: 16 }),   label: "Portfolios" },
    { key: "simulations",  icon: React.createElement(PI.Icon.Beaker, { size: 16 }),   label: "Simulations" },
    { key: "stress-tests", icon: React.createElement(PI.Icon.Zap, { size: 16 }),      label: "Stress tests" },
    { key: "benchmarks",   icon: React.createElement(PI.Icon.BarChart, { size: 16 }), label: "Benchmarks" },
    { key: "predictions",  icon: React.createElement(PI.Icon.Sparkles, { size: 16 }), label: "Predictions" },
  ];
  const admin = [
    { key: "team",     icon: React.createElement(PI.Icon.Users, { size: 16 }), label: "Team" },
    { key: "settings", icon: React.createElement(PI.Icon.Settings, { size: 16 }), label: "Settings" },
  ];

  const primary = route.startsWith("portfolios") ? "portfolios"
                : route.startsWith("simulations") ? "simulations"
                : route.startsWith("forecast") ? "portfolios"
                : route.startsWith("results") ? "simulations"
                : route.startsWith("compare") ? "simulations"
                : route;

  const renderItem = (it, onClick) => React.createElement("button", {
    key: it.key,
    className: `sb-item${primary === it.key ? " is-active" : ""}`,
    onClick,
    title: collapsed ? it.label : undefined
  }, it.icon, !collapsed && React.createElement("span", null, it.label));

  return React.createElement("aside", { className: `sidebar${collapsed ? " is-collapsed" : ""}` },
    React.createElement("div", { className: "sb-brand" },
      collapsed
        ? React.createElement("img", { className: "sb-brand-icon", src: "assets/CEPRES logo chiuso.png", alt: "Cepres" })
        : React.createElement(PI.Fragment, null,
            React.createElement("div", { className: "sb-brand-stack" },
              React.createElement("img", { className: "sb-brand-wordmark", src: "assets/CEPRES logo aperto.png", alt: "Cepres" }),
              React.createElement("div", { className: "sb-brand-product" }, "Predictive Intelligence")
            )
          ),
      !collapsed && React.createElement("button", {
        className: "sb-collapse-btn", onClick: () => setCollapsed(true), title: "Collapse sidebar"
      }, React.createElement(PI.Icon.ChevronLeft, { size: 14 }))
    ),
    collapsed && React.createElement("button", {
      className: "sb-expand-btn", onClick: () => setCollapsed(false), title: "Expand sidebar"
    }, React.createElement(PI.Icon.ChevronRight, { size: 14 })),
    !collapsed && React.createElement("div", { className: "sb-section-label" }, "Workspace"),
    React.createElement("nav", { className: "sb-nav" },
      items.map(it => renderItem(it, () => onNavigate(it.key)))
    ),
    !collapsed && React.createElement("div", { className: "sb-section-label" }, "Admin"),
    React.createElement("nav", { className: "sb-nav" },
      admin.map(it => renderItem(it, () => {}))
    ),
    React.createElement("div", { className: "sb-foot" },
      React.createElement("div", { className: "sb-user" },
        React.createElement("div", { className: "sb-avatar" }, "SR"),
        !collapsed && React.createElement("div", { style: { flex: 1, minWidth: 0 } },
          React.createElement("div", { className: "sb-user-name" }, "Sarah Reiter"),
          React.createElement("div", { className: "sb-user-org" }, "Kirkwood Capital")
        ),
        !collapsed && React.createElement(PI.Icon.ChevronRight, { size: 14 })
      )
    )
  );
}

window.PI.Sidebar = Sidebar;
