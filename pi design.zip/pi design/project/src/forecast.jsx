/* Forecasting launch modal + Fine-tuning + Results */

function MultiSelect({ options, values, onChange, placeholder }) {
  const [input, setInput] = PI.useState("");
  const [open, setOpen] = PI.useState(false);
  const ref = PI.useClickOutside(() => setOpen(false));
  const avail = options.filter(o => !values.includes(o.id) && (o.name.toLowerCase().includes(input.toLowerCase()) || input === ""));
  return React.createElement("div", { ref, style: { position: "relative" } },
    React.createElement("div", { className: "multiselect", onClick: () => setOpen(true) },
      values.map(v => {
        const o = options.find(x => x.id === v);
        return React.createElement("span", { key: v, className: "ms-chip" },
          o?.name || v,
          React.createElement("button", { onClick: e => { e.stopPropagation(); onChange(values.filter(x => x !== v)); } }, "×")
        );
      }),
      React.createElement("input", {
        placeholder: values.length === 0 ? placeholder : "",
        value: input, onChange: e => setInput(e.target.value),
        onFocus: () => setOpen(true)
      })
    ),
    open && avail.length > 0 && React.createElement("div", { className: "dd-menu", style: { position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, maxHeight: 240, overflowY: "auto" } },
      avail.map(o => React.createElement("div", {
        key: o.id, className: "dd-item",
        onClick: () => { onChange([...values, o.id]); setInput(""); }
      },
        React.createElement("div", null,
          React.createElement("div", { style: { fontWeight: 500 } }, o.name),
          React.createElement("div", { style: { fontSize: 11, color: "var(--black-60)" } }, o.desc)
        )
      ))
    )
  );
}

function ForecastLauncher({ portfolio, onClose, onRun, onFineTune, initialPath }) {
  const path = "simulation";
  const [simName, setSimName] = PI.useState(`${portfolio.name} — ${new Date().toISOString().slice(0,10)}`);
  const [stressIds, setStressIds] = PI.useState([]);
  const [depth, setDepth] = PI.useState("full");
  const [currency, setCurrency] = PI.useState("USD");
  const [fineTune, setFineTune] = PI.useState("no");
  const [granularity, setGranularity] = PI.useState("monthly");
  const [assetTypes, setAssetTypes] = PI.useState(new Set(PI_DATA.ASSET_TYPES.map(a => a.id)));
  const [realStates, setRealStates] = PI.useState(new Set(["active", "future"]));  // realized excluded by default
  const [excluded, setExcluded] = PI.useState(new Set());
  const [showPicker, setShowPicker] = PI.useState(false);

  const allFunds = PI_DATA.FUNDS;
  // Filtered by asset type + realization
  const eligible = allFunds.filter(f => assetTypes.has(f.assetType) && realStates.has(f.realization));
  const included = eligible.filter(f => !excluded.has(f.id));

  function toggleAssetType(id) {
    const n = new Set(assetTypes);
    n.has(id) ? n.delete(id) : n.add(id);
    setAssetTypes(n);
  }
  function toggleReal(id) {
    const n = new Set(realStates);
    n.has(id) ? n.delete(id) : n.add(id);
    setRealStates(n);
  }
  function toggleExclude(id) {
    const n = new Set(excluded);
    n.has(id) ? n.delete(id) : n.add(id);
    setExcluded(n);
  }

  function run() {
    const config = {
      type: "simulation", name: simName, stressIds, depth, currency, fineTune,
      granularity,
      assetTypes: [...assetTypes],
      realStates: [...realStates],
      includedIds: included.map(f => f.id),
      excludedIds: [...excluded],
    };
    if (fineTune === "yes") onFineTune(config); else onRun(config);
  }

  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: onClose }),
    React.createElement("div", { className: "modal-wrap", onClick: onClose },
      React.createElement("div", { className: "modal modal-lg", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" }, "New simulation"),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 500 } }, portfolio.name)
          ),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),
        React.createElement("div", { className: "modal-body" },
          // Config form (simulation only — immediate forecast is handled inline on detail page)
          React.createElement("div", { style: { marginTop: 4 } },
                React.createElement("div", { className: "form-grid" },
                  React.createElement(PI.Field, { label: "Simulation name", required: true, wide: true },
                    React.createElement("input", { className: "input", value: simName, onChange: e => setSimName(e.target.value) })
                  ),
                  React.createElement(PI.Field, { label: "Stress tests (optional)", wide: true, hint: "Multi-select. Leave empty for a baseline simulation." },
                    React.createElement(MultiSelect, { options: PI_DATA.STRESS_TESTS, values: stressIds, onChange: setStressIds, placeholder: "Add stress scenarios…" })
                  ),
                  React.createElement(PI.Field, { label: "Simulation depth", wide: true },
                    React.createElement("div", { className: "fx-depth" },
                      React.createElement("div", {
                        className: `fx-depth-opt${depth === "fast" ? " is-selected" : ""}`,
                        onClick: () => setDepth("fast")
                      },
                        React.createElement("input", { type: "radio", className: "rdo", checked: depth === "fast", readOnly: true, style: {marginTop: 2} }),
                        React.createElement("div", null,
                          React.createElement("div", { className: "fx-depth-title" }, "Fast"),
                          React.createElement("div", { className: "fx-depth-sub" }, "1,000 iterations — rough shape of outcomes"),
                          React.createElement("div", { className: "fx-depth-time" }, "~8 seconds")
                        )
                      ),
                      React.createElement("div", {
                        className: `fx-depth-opt${depth === "full" ? " is-selected" : ""}`,
                        onClick: () => setDepth("full")
                      },
                        React.createElement("input", { type: "radio", className: "rdo", checked: depth === "full", readOnly: true, style: {marginTop: 2} }),
                        React.createElement("div", null,
                          React.createElement("div", { className: "fx-depth-title" }, "Full ", React.createElement("span", { className: "tag tag-gold", style: {marginLeft: 6} }, "Recommended")),
                          React.createElement("div", { className: "fx-depth-sub" }, "50,000 iterations — smooth distribution, precise tails"),
                          React.createElement("div", { className: "fx-depth-time" }, "~2 minutes")
                        )
                      )
                    )
                  ),
                  React.createElement(PI.Field, { label: "Currency" },
                    React.createElement("select", { className: "select", value: currency, onChange: e => setCurrency(e.target.value) },
                      ["USD","EUR","GBP"].map(c => React.createElement("option", { key: c, value: c }, c))
                    )
                  ),
                  React.createElement(PI.Field, { label: "Results granularity", hint: "Time step for Monte-Carlo output." },
                    React.createElement("div", { className: "yn-switch" },
                      ["monthly","quarterly","yearly"].map(g => React.createElement("button", {
                        key: g, className: granularity === g ? "is-active" : "",
                        onClick: () => setGranularity(g)
                      }, g.charAt(0).toUpperCase() + g.slice(1)))
                    )
                  ),
                  React.createElement(PI.Field, { label: "Fine-tune parameters?", hint: "Edit fund data on-the-fly before running." },
                    React.createElement("div", { className: "yn-switch" },
                      React.createElement("button", { className: fineTune === "no" ? "is-active" : "", onClick: () => setFineTune("no") }, "No"),
                      React.createElement("button", { className: fineTune === "yes" ? "is-active" : "", onClick: () => setFineTune("yes") }, "Yes")
                    )
                  ),

                  // Asset types to include
                  React.createElement(PI.Field, { label: "Asset types", wide: true, hint: "Include only these asset classes in the simulation." },
                    React.createElement("div", { className: "fl-chips" },
                      PI_DATA.ASSET_TYPES.map(a => {
                        const on = assetTypes.has(a.id);
                        return React.createElement("label", {
                          key: a.id,
                          className: `fl-chip${on ? " is-on" : ""}`,
                          style: { "--c": a.color }
                        },
                          React.createElement("input", {
                            type: "checkbox", className: "chk", checked: on,
                            onChange: () => toggleAssetType(a.id)
                          }),
                          React.createElement("span", { className: "fl-chip-dot" }),
                          React.createElement("span", null, a.label)
                        );
                      })
                    )
                  ),

                  // Fund status
                  React.createElement(PI.Field, { label: "Investment status", wide: true, hint: "Realized positions are excluded by default (already closed)." },
                    React.createElement("div", { className: "fl-status" },
                      PI_DATA.REALIZATIONS.map(r => {
                        const on = realStates.has(r.id);
                        return React.createElement("label", {
                          key: r.id,
                          className: `fl-status-chip fl-st-${r.id}${on ? " is-on" : ""}`
                        },
                          React.createElement("input", {
                            type: "checkbox", className: "chk", checked: on,
                            onChange: () => toggleReal(r.id)
                          }),
                          React.createElement("span", null, r.label)
                        );
                      })
                    )
                  ),

                  // Fund picker
                  React.createElement(PI.Field, { label: "Funds to include", wide: true,
                    hint: `${included.length} of ${eligible.length} eligible funds selected · ${excluded.size} excluded` },
                    React.createElement("button", {
                      className: "fl-picker-toggle",
                      onClick: (e) => { e.preventDefault(); setShowPicker(p => !p); }
                    },
                      React.createElement(PI.Icon.Filter, { size: 12 }),
                      React.createElement("span", null, showPicker ? "Hide fund list" : "Review / exclude funds"),
                      React.createElement(PI.Icon.ChevronDown, { size: 12,
                        className: showPicker ? "is-open" : "" })
                    ),
                    showPicker && React.createElement("div", { className: "fl-picker" },
                      React.createElement("div", { className: "fl-picker-head" },
                        React.createElement("span", null, `${eligible.length} eligible · select to exclude`),
                        React.createElement("div", { style: { display: "flex", gap: 6 } },
                          React.createElement("button", {
                            className: "fl-picker-linkbtn",
                            onClick: (e) => { e.preventDefault(); setExcluded(new Set()); }
                          }, "Include all"),
                          React.createElement("button", {
                            className: "fl-picker-linkbtn",
                            onClick: (e) => { e.preventDefault(); setExcluded(new Set(eligible.map(f => f.id))); }
                          }, "Exclude all")
                        )
                      ),
                      React.createElement("div", { className: "fl-picker-list" },
                        eligible.map(f => {
                          const meta = PI_DATA.assetTypeMeta(f.assetType);
                          const isExcl = excluded.has(f.id);
                          return React.createElement("label", {
                            key: f.id,
                            className: `fl-picker-row${isExcl ? " is-excluded" : ""}`
                          },
                            React.createElement("input", {
                              type: "checkbox", className: "chk", checked: !isExcl,
                              onChange: () => toggleExclude(f.id)
                            }),
                            React.createElement("span", { className: "fl-picker-dot", style: { background: meta.color } }),
                            React.createElement("span", { className: "fl-picker-name" }, f.name),
                            React.createElement("span", { className: "fl-picker-meta" },
                              `${meta.label} · ${f.realization} · $${Math.round(f.nav)}M`)
                          );
                        })
                      )
                    )
                  )
                )
              )
        ),
        React.createElement("footer", { className: "modal-foot" },
          React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
          React.createElement(PI.Btn, {
            kind: "primary",
            icon: React.createElement(PI.Icon.Play, {size:13}),
            onClick: run
          }, fineTune === "yes" ? "Continue to fine-tune" : "Run simulation")
        )
      )
    )
  );
}

// Fine-tuning page — editable table
function FineTunePage({ portfolio, funds, config, setFunds, onCancel, onRun, onShowModal, onToast }) {
  const [valid, setValid] = PI.useState(false);
  const [validating, setValidating] = PI.useState(false);
  return React.createElement("div", null,
    React.createElement("div", { className: "ft-bar" },
      React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
        React.createElement(PI.Icon.Warning, { size: 14 }),
        React.createElement("div", null,
          React.createElement("strong", null, "Fine-tuning mode · " + config.name),
          React.createElement("span", { style: { marginLeft: 10, color: "#7A5A00" } }, `Edit any fund or cash flow below. Changes apply to this simulation run only.`)
        )
      ),
      React.createElement("div", { style: { display: "flex", gap: 8 } },
        React.createElement(PI.Btn, { kind: "ghost", size: "sm", onClick: onCancel }, "Discard & exit"),
        React.createElement(PI.Btn, {
          kind: "ghost", size: "sm",
          icon: React.createElement(PI.Icon.Check, { size: 13 }),
          onClick: () => {
            setValidating(true);
            setTimeout(() => { setValidating(false); setValid(true); onToast(`Validated ${funds.length} funds · 0 errors · 2 warnings`, "ok"); }, 700);
          }
        }, validating ? "Validating…" : (valid ? "Re-validate" : "Validate changes")),
        React.createElement(PI.Btn, {
          kind: "primary", size: "sm",
          icon: React.createElement(PI.Icon.Play, { size: 13 }),
          disabled: !valid,
          onClick: onRun
        }, "Run simulation")
      )
    ),
    React.createElement("div", { className: "main-inner" },
      React.createElement("div", { className: "page-head" },
        React.createElement("div", null,
          React.createElement("div", { className: "page-crumb" },
            React.createElement("a", { href: "#", onClick: e => { e.preventDefault(); onCancel(); } }, "Portfolios"),
            React.createElement(PI.Icon.ChevronRight, { size: 12, className: "sep" }),
            React.createElement("span", null, portfolio.name),
            React.createElement(PI.Icon.ChevronRight, { size: 12, className: "sep" }),
            React.createElement("span", null, "Fine-tune")
          ),
          React.createElement("h1", { className: "page-title" }, "Fine-tune parameters"),
          React.createElement("div", { className: "page-sub" },
            "Override fund-level projections before simulation. Double-click any cell; cash flows are editable per fund."
          )
        ),
        React.createElement("div", { className: "head-actions" },
          React.createElement("span", { className: "tag tag-gold" }, `${config.depth === "full" ? "50,000" : "1,000"} iterations`),
          config.stressIds?.length > 0 && React.createElement("span", { className: "tag tag-outline" }, `${config.stressIds.length} stress scenarios`),
        )
      ),
      React.createElement("div", { className: "eyebrow", style: { marginBottom: 8 } }, "Editable investments"),
      React.createElement(PI.InvestmentsTable, {
        funds,
        onOpenCashflows: (f) => onShowModal({ kind: "cashflows", fund: f }),
        onEdit: (f) => onShowModal({ kind: "edit", fund: f }),
        onDelete: (f) => onShowModal({ kind: "confirm-delete", fund: f }),
        onAdd: () => onShowModal({ kind: "add" }),
      })
    )
  );
}

// Progress overlay
function SimProgress({ depth, onDone }) {
  const [pct, setPct] = PI.useState(0);
  const [iter, setIter] = PI.useState(0);
  const target = depth === "full" ? 50000 : 1000;
  const duration = depth === "full" ? 3600 : 1800;
  const logs = PI.useRef([]);
  const [logLines, setLogLines] = PI.useState([]);
  PI.useEffect(() => {
    const start = Date.now();
    const timer = setInterval(() => {
      const elapsed = Date.now() - start;
      const p = Math.min(1, elapsed / duration);
      setPct(p);
      setIter(Math.floor(target * p));
      if (p < 1 && Math.random() < 0.22) {
        const phases = [
          "Loading look-through deal set…",
          "Calibrating J-curve per fund…",
          "Sampling exit timing distributions…",
          "Applying stress: rate shock +200bps",
          "Aggregating fund → portfolio NAV path",
          "Resolving cross-fund correlation matrix",
          "Running iteration batch…",
          "Bootstrapping confidence bands"
        ];
        const line = `[${new Date().toLocaleTimeString()}] ${phases[Math.floor(Math.random() * phases.length)]}`;
        logs.current = [...logs.current.slice(-3), line];
        setLogLines([...logs.current]);
      }
      if (p >= 1) { clearInterval(timer); setTimeout(onDone, 260); }
    }, 60);
    return () => clearInterval(timer);
  }, []);
  return React.createElement("div", { className: "sim-progress" },
    React.createElement("div", { className: "sim-progress-card" },
      React.createElement("div", { style: { display: "flex", justifyContent: "center", marginBottom: 12 } },
        React.createElement("div", { style: { width: 44, height: 44, borderRadius: 999, background: "var(--warm-3)", display: "grid", placeItems: "center", color: "var(--green)" } },
          React.createElement(PI.Icon.Beaker, { size: 22, stroke: 2 })
        )
      ),
      React.createElement("div", { className: "sim-progress-title" }, "Running Monte Carlo simulation"),
      React.createElement("div", { className: "sim-progress-sub" },
        depth === "full" ? "50,000 iterations · 12,400 look-through deals" : "1,000 iterations · 12,400 look-through deals"),
      React.createElement("div", { className: "sim-progress-bar" },
        React.createElement("div", { className: "sim-progress-fill", style: { width: `${pct * 100}%` } })
      ),
      React.createElement("div", { className: "sim-progress-meta" },
        React.createElement("span", null, `${iter.toLocaleString()} / ${target.toLocaleString()} iterations`),
        React.createElement("span", null, `${Math.round(pct * 100)}%`)
      ),
      React.createElement("div", { className: "sim-progress-log" },
        logLines.length === 0 ? "Starting engine…" : logLines.map((l, i) => React.createElement("div", { key: i }, l))
      )
    )
  );
}

window.PI.ForecastLauncher = ForecastLauncher;
window.PI.FineTunePage = FineTunePage;
window.PI.SimProgress = SimProgress;
