/* Main App — router & state */
const PI_DATA = window.PI_DATA;

function App() {
  const [route, setRoute] = PI.useState(() => {
    try { return localStorage.getItem("pi.route") || "portfolios"; } catch (e) { return "portfolios"; }
  });
  const [sbCollapsed, setSbCollapsed] = PI.useState(() => {
    try { return localStorage.getItem("pi.sbCollapsed") === "1"; } catch (e) { return false; }
  });
  const [selectedPortfolioId, setSelectedPortfolioId] = PI.useState("cepres-example");
  const [portfolios, setPortfolios] = PI.useState(PI_DATA.PORTFOLIOS);
  const [archived, setArchived] = PI.useState(PI_DATA.ARCHIVED_PORTFOLIOS || []);
  const [simulations, setSimulations] = PI.useState(PI_DATA.SIMULATIONS || []);
  const [compareIds, setCompareIds] = PI.useState(null);
  const [funds, setFunds] = PI.useState(PI_DATA.FUNDS);
  const [modal, setModal] = PI.useState(null);
  const [toasts, setToasts] = PI.useState([]);
  const [forecastConfig, setForecastConfig] = PI.useState(null);
  const [running, setRunning] = PI.useState(false);
  const [simPortfolioFilter, setSimPortfolioFilter] = PI.useState(null);

  PI.useEffect(() => { try { localStorage.setItem("pi.route", route); } catch (e) {} }, [route]);
  PI.useEffect(() => { try { localStorage.setItem("pi.sbCollapsed", sbCollapsed ? "1" : "0"); } catch (e) {} }, [sbCollapsed]);

  // Auto-open New Portfolio modal if list empty
  PI.useEffect(() => {
    if (route === "portfolios" && portfolios.length === 0 && !modal) {
      setModal({ kind: "new-portfolio", canClose: false });
    }
  }, [route, portfolios.length]);

  const portfolio = portfolios.find(p => p.id === selectedPortfolioId) || portfolios[0];

  function showToast(text, kind="ok") {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, text, kind }]);
  }
  function dismissToast(id) { setToasts(t => t.filter(x => x.id !== id)); }

  function openPortfolio(id) { setSelectedPortfolioId(id); setRoute("portfolios/detail"); }

  function openNewPortfolio() { setModal({ kind: "new-portfolio" }); }
  function createFromUpload(name, fileName) {
    const id = "uploaded-" + Date.now();
    setPortfolios(ps => [{
      id, name, owner: "You", updatedAt: new Date().toISOString().slice(0,10),
      funds: 22, committed: 1850, nav: 2100, tvpi: 1.42, simCount: 0
    }, ...ps]);
    setSelectedPortfolioId(id);
    setModal(null);
    showToast(`Portfolio "${name}" created from ${fileName}`, "ok");
    setRoute("portfolios/detail");
  }
  function createFromExample() {
    const n = portfolios.filter(p => p.name.startsWith("Cepres Example Portfolio")).length;
    const name = n > 0 ? `Cepres Example Portfolio (${n+1})` : "Cepres Example Portfolio";
    const id = "example-" + Date.now();
    setPortfolios(ps => [{
      id, name, owner: "You", updatedAt: new Date().toISOString().slice(0,10),
      funds: 22, committed: 1850, nav: 2100, tvpi: 1.42, simCount: 0
    }, ...ps]);
    setSelectedPortfolioId(id);
    setModal(null);
    showToast(`Copy "${name}" created`, "ok");
    setRoute("portfolios/detail");
  }

  function archivePortfolio(p) {
    setModal({ kind: "confirm-archive", portfolio: p });
  }
  function restorePortfolio(p) {
    setModal({ kind: "confirm-restore", portfolio: p });
  }
  function permanentlyDeletePortfolio(p) {
    setModal({ kind: "confirm-perm-delete", portfolio: p });
  }

  function handleRunForecast(config) {
    setForecastConfig(config);
    setModal(null);
    setRunning(true);
  }
  function handleFineTune(config) {
    setForecastConfig(config);
    setModal(null);
    setRoute("forecast/fine-tune");
  }

  const mainContent = (() => {
    if (route === "portfolios") {
      return React.createElement(PI.PortfoliosPage, {
        portfolios, archived,
        onSelect: setSelectedPortfolioId,
        onOpen: openPortfolio,
        onOpenSims: (p) => { setSimPortfolioFilter(p.name); showToast(`Showing simulations for ${p.name}`); setRoute("simulations"); },
        onNewModal: openNewPortfolio,
        onArchive: archivePortfolio,
        onRestore: restorePortfolio,
        onDelete: permanentlyDeletePortfolio,
        onToast: showToast,
      });
    }
    if (route === "portfolios/detail") {
      return React.createElement(PI.PortfolioDetail, {
        portfolio, funds,
        onBack: () => setRoute("portfolios"),
        onStartForecast: () => setModal({ kind: "forecast-launch", initialPath: "simulation" }),
        onImmediateForecast: () => setModal({ kind: "forecast-launch", initialPath: "immediate" }),
        onImmediateForecastRun: (stressIds) => {
          // Route to the dedicated results page (same structure as the
          // simulation results page minus probability distributions). The
          // forecast itself is "immediate" (no SimProgress modal — runs
          // synchronously when the route mounts).
          const stressNames = (stressIds || []).map(id => PI_DATA.STRESS_TESTS.find(s => s.id === id)?.name).filter(Boolean);
          setForecastConfig({
            type: "immediate",
            name: stressNames.length > 0 ? `Immediate forecast · Base + ${stressNames.join(", ")}` : "Immediate forecast · Base scenario",
            stressIds: stressIds || [],
            stressTests: stressNames,
            depth: "fast",
            granularity: "monthly",
            assetTypes: (PI_DATA.ASSET_TYPES || []).map(t => t.id)
          });
          setRoute("results");
        },
        onToast: showToast,
        onShowModal: setModal,
        setFunds,
      });
    }
    if (route === "forecast/fine-tune") {
      return React.createElement(PI.FineTunePage, {
        portfolio, funds, config: forecastConfig,
        setFunds,
        onCancel: () => setRoute("portfolios/detail"),
        onRun: () => { setRunning(true); },
        onShowModal: setModal,
        onToast: showToast,
      });
    }
    if (route === "results") {
      return React.createElement(PI.ResultsPage, {
        portfolio, funds, config: forecastConfig,
        onDone: () => setRoute("portfolios/detail"),
        onShowModal: setModal,
        onToast: showToast,
      });
    }
    if (route === "simulations") {
      return React.createElement(PI.SimulationsPage, {
        simulations, portfolios,
        initialPortfolioFilter: simPortfolioFilter,
        onOpen: (s) => { setForecastConfig({ name: s.name, depth: s.depth, stressTests: s.stressTests }); setRoute("results"); },
        onCompare: (ids) => { setCompareIds(ids); setRoute("compare"); },
        onNewSim: () => setModal({ kind: "pick-portfolio-for-sim" }),
        onPickPortfolio: () => {},
        onToast: showToast,
      });
    }
    if (route === "compare") {
      return React.createElement(PI.CompareView, {
        simulations, ids: compareIds || [simulations[0].id, simulations[1].id],
        onBack: () => setRoute("simulations"),
        onToast: showToast,
      });
    }
    return React.createElement("div", { className: "main-inner" },
      React.createElement("div", { className: "page-head" },
        React.createElement("div", null,
          React.createElement("h1", { className: "page-title" }, route.charAt(0).toUpperCase() + route.slice(1).replace("-", " "))
        )
      ),
      React.createElement("div", { className: "card" },
        React.createElement("div", { className: "empty" }, "This section is outside the scope of this round.")
      )
    );
  })();

  const m = modal;
  let modalEl = null;
  if (m) {
    if (m.kind === "cashflows") {
      modalEl = React.createElement(PI.CashflowsModal, {
        fund: m.fund,
        onClose: () => setModal(null),
        onSaveCashflows: () => {},
        showToast,
      });
    } else if (m.kind === "edit") {
      modalEl = React.createElement(PI.EditFundModal, {
        fund: m.fund, isAdd: false,
        onSave: (draft) => {
          setFunds(fs => fs.map(f => f.id === m.fund.id ? { ...f, ...draft } : f));
          setModal(null);
          showToast("Fund updated", "ok");
        },
        onClose: () => setModal(null),
        onOpenCashflows: (f) => setModal({ kind: "cashflows", fund: f }),
        onOpenGoalSeek: (f, kind) => setModal({ kind: "goal-seek", fund: f, gsKind: kind, returnTo: { kind: "edit", fund: f } }),
        showToast,
      });
    } else if (m.kind === "add") {
      modalEl = React.createElement(PI.EditFundModal, {
        fund: m.fund || null, isAdd: true,
        onSave: (draft) => {
          const newFund = { ...draft, id: draft.id || "FND-" + Math.floor(Math.random() * 9000 + 1000) };
          setFunds(fs => [newFund, ...fs]);
          setModal(null);
          showToast("Fund added", "ok");
        },
        onClose: () => setModal(null),
        onOpenCashflows: () => {},
        onOpenGoalSeek: (f, kind) => setModal({ kind: "goal-seek", fund: f, gsKind: kind, returnTo: { kind: "add", fund: f } }),
        showToast,
      });
    } else if (m.kind === "confirm-delete") {
      modalEl = React.createElement(PI.ConfirmDialog, {
        title: `Delete "${m.fund.name}"?`,
        message: "This removes the investment and its cash flow history from this portfolio. This action cannot be undone.",
        onConfirm: () => { setFunds(fs => fs.filter(f => f.id !== m.fund.id)); setModal(null); showToast("Fund deleted", "ok"); },
        onClose: () => setModal(null)
      });
    } else if (m.kind === "confirm-perm-delete") {
      modalEl = React.createElement(PI.ConfirmDialog, {
        title: `Permanently delete "${m.portfolio.name}"?`,
        message: "The portfolio and all associated simulations will be removed. This cannot be undone.",
        onConfirm: () => { setArchived(xs => xs.filter(x => x.id !== m.portfolio.id)); setModal(null); showToast("Portfolio deleted permanently", "ok"); },
        onClose: () => setModal(null)
      });
    } else if (m.kind === "confirm-archive") {
      modalEl = React.createElement(PI.ConfirmDialog, {
        title: `Archive "${m.portfolio.name}"?`,
        message: "The portfolio is moved to the Archived tab. You can restore it at any time.",
        confirmLabel: "Archive",
        confirmKind: "primary",
        onConfirm: () => {
          setPortfolios(ps => ps.filter(x => x.id !== m.portfolio.id));
          setArchived(xs => [{ ...m.portfolio }, ...xs]);
          setModal(null);
          showToast(`Archived "${m.portfolio.name}"`, "ok");
        },
        onClose: () => setModal(null)
      });
    } else if (m.kind === "confirm-restore") {
      modalEl = React.createElement(PI.ConfirmDialog, {
        title: `Restore "${m.portfolio.name}"?`,
        message: "The portfolio is moved back to the Active tab.",
        confirmLabel: "Restore",
        confirmKind: "primary",
        onConfirm: () => {
          setArchived(xs => xs.filter(x => x.id !== m.portfolio.id));
          setPortfolios(ps => [{ ...m.portfolio, updatedAt: new Date().toISOString().slice(0,10) }, ...ps]);
          setModal(null);
          showToast(`Restored "${m.portfolio.name}"`, "ok");
        },
        onClose: () => setModal(null)
      });
    } else if (m.kind === "forecast-launch") {
      modalEl = React.createElement(PI.ForecastLauncher, {
        portfolio, onClose: () => setModal(null),
        initialPath: m.initialPath,
        onRun: (config) => {
          if (config.type === "immediate") {
            // Route to the dedicated results page — same structure as the
            // simulation results page minus the probability-distribution
            // sections. Skip SimProgress (immediate forecast is synchronous).
            setForecastConfig(config);
            setModal(null);
            setRoute("results");
          } else {
            handleRunForecast(config);
          }
        },
        onFineTune: handleFineTune
      });
    } else if (m.kind === "new-portfolio") {
      modalEl = React.createElement(PI.NewPortfolioModal, {
        canClose: m.canClose !== false,
        onClose: () => setModal(null),
        onCreateFromUpload: createFromUpload,
        onCreateFromExample: createFromExample,
        onDownloadTemplate: () => { showToast("Template downloaded: cepres-portfolio-template.xlsx"); setModal(null); },
      });
    } else if (m.kind === "pick-portfolio-for-sim") {
      modalEl = React.createElement(PI.PickPortfolioModal, {
        portfolios,
        onClose: () => setModal(null),
        onPick: (id) => {
          setSelectedPortfolioId(id);
          setModal({ kind: "forecast-launch" });
        }
      });
    } else if (m.kind === "goal-seek") {
      modalEl = React.createElement(PI.GoalSeekModal, {
        fund: m.fund, kind: m.gsKind,
        onClose: () => setModal(m.returnTo || null),
        onAccept: ({ price, date }) => {
          const updates = m.gsKind === "purchase"
            ? { purchasePrice: price, purchaseDate: date }
            : { salesPrice: price, salesDate: date };
          if (m.returnTo) {
            // Came from Add/Edit popup — reopen it with the draft pre-filled.
            // Don't commit to funds here; the user still has to click Save/Add on the popup.
            setModal({ ...m.returnTo, fund: { ...m.fund, ...updates } });
          } else {
            // Came from the table — persist immediately.
            setFunds(fs => fs.map(f => f.id === m.fund.id ? { ...f, ...updates } : f));
            setModal(null);
          }
        },
        onToast: showToast,
      });
    }
  }

  return React.createElement("div", { className: `app${sbCollapsed ? " is-collapsed" : ""}` },
    React.createElement(PI.Sidebar, {
      route, onNavigate: setRoute,
      collapsed: sbCollapsed, setCollapsed: setSbCollapsed
    }),
    React.createElement("main", { className: "main" }, mainContent),
    modalEl,
    running && React.createElement(PI.SimProgress, {
      depth: forecastConfig?.depth || "fast",
      onDone: () => {
        // Persist the sim
        const name = forecastConfig?.name || "Immediate forecast";
        const newSim = {
          id: "sim-" + Date.now(), name,
          portfolio: portfolio.name, created: new Date().toISOString().slice(0,10),
          depth: forecastConfig?.depth || "fast", status: "Completed",
          stressTests: forecastConfig?.stressTests || [],
          headlineTvpi: 1.62 + (Math.random() - 0.5) * 0.3,
          p10Tvpi: 1.18 + (Math.random() - 0.5) * 0.2,
          p90Tvpi: 2.05 + (Math.random() - 0.5) * 0.2,
          meanIrr: 0.148 + (Math.random() - 0.5) * 0.04,
          meanDpi: 1.28 + (Math.random() - 0.5) * 0.2,
          probLoss: 0.06 + (Math.random() - 0.5) * 0.04,
        };
        setSimulations(ss => [newSim, ...ss]);
        setPortfolios(ps => ps.map(p => p.id === portfolio.id ? { ...p, simCount: (p.simCount || 0) + 1 } : p));
        setRunning(false); setRoute("results");
      }
    }),
    toasts.map(t => React.createElement(PI.Toast, {
      key: t.id, kind: t.kind, onDone: () => dismissToast(t.id)
    }, t.text))
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(React.createElement(App));
