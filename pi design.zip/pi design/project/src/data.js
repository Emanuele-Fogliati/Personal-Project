/* Seed data for Predictive Intelligence prototype */
(function(){
  const GP_NAMES = [
    "Blackstone Capital Partners", "KKR Americas", "Carlyle Partners", "Vista Equity",
    "Advent International", "Apax Partners", "EQT Partners", "Permira",
    "Silver Lake Partners", "Hellman & Friedman", "Thoma Bravo", "TPG Growth",
    "Bain Capital", "Cinven Partners", "CVC Capital", "General Atlantic",
    "Warburg Pincus", "Insight Venture Partners", "Ardian", "Nordic Capital",
    "Bridgepoint", "PAI Partners", "Providence Equity", "L Catterton",
    "Francisco Partners"
  ];
  const REGIONS = ["North America", "Europe", "Asia Pacific", "Emerging Markets"];
  const STAGES = ["Buyout", "Growth", "Venture", "Secondary", "Credit", "Infrastructure"];
  const TYPES = ["Primary", "Secondary", "Co-investment", "Fund-of-Funds"];
  const STATUSES = ["Active", "Harvesting", "Winding Down", "Realized"];
  const CURRENCIES = ["USD", "EUR", "GBP"];
  const CF_PATTERNS = ["J-Curve Standard", "J-Curve Accelerated", "Late Distributor", "Front-loaded", "Steady-state"];

  // ---------- Asset-type taxonomy ----------
  // Internal IDs kept for back-compat with existing code. The Liquidity
  // Management Module spec (descrizione.md §3) uses slightly different names
  // (cash, bonds, stocks, etfs, hedge_funds, secondary_funds, primary_funds);
  // see SPEC_ASSET_TYPES and the two translation maps below.
  const ASSET_TYPES = [
    { id: "cash",         label: "Cash",                 group: "Liquidity",      color: "#7FCCC8", icon: "Target",    liquidity: "instant" },
    { id: "bond",         label: "Bond",                 group: "Public Market",  color: "#3D6E8F", icon: "TrendingUp", liquidity: "t+1-3" },
    { id: "stock",        label: "Stock",                group: "Public Market",  color: "#058F8A", icon: "TrendingUp", liquidity: "t+1-3" },
    { id: "etf",          label: "ETF",                  group: "Public Market",  color: "#5AA0A0", icon: "TrendingUp", liquidity: "t+1-3" },
    { id: "hedge",        label: "Hedge Fund",           group: "Alternatives",   color: "#B56624", icon: "Beaker",     liquidity: "gated"   },
    { id: "secondary",    label: "Secondary Investment", group: "Private Market", color: "#7B267F", icon: "Layers",     liquidity: "years"   },
    { id: "primary",      label: "Primary Investment",   group: "Private Market", color: "#2F3E55", icon: "Layers",     liquidity: "locked"  },
    { id: "coinvestment", label: "Co-Investment",        group: "Private Market", color: "#00437F", icon: "Users",      liquidity: "locked"  },
  ];

  // Liquidity module spec canonical order of the 7 public-facing types.
  const SPEC_ASSET_TYPES = ["cash", "bonds", "stocks", "etfs", "hedge_funds", "secondary_funds", "primary_funds"];
  // spec id -> internal id
  const SPEC_TO_INTERNAL = {
    cash: "cash", bonds: "bond", stocks: "stock", etfs: "etf",
    hedge_funds: "hedge", secondary_funds: "secondary", primary_funds: "primary"
  };
  // internal id -> spec id (coinvestment is rolled into primary for the Liquidity view)
  const INTERNAL_TO_SPEC = {
    cash: "cash", bond: "bonds", stock: "stocks", etf: "etfs",
    hedge: "hedge_funds", secondary: "secondary_funds",
    primary: "primary_funds", coinvestment: "primary_funds"
  };

  // ---------- Realization status (user-facing) ----------
  const REALIZATIONS = [
    { id: "active",   label: "Active" },
    { id: "realized", label: "Realized" },
    { id: "future",   label: "Future" },
  ];

  function seeded(seed) {
    let s = seed;
    return () => {
      s = (s * 1664525 + 1013904223) % 4294967296;
      return s / 4294967296;
    };
  }
  const rand = seeded(42);
  const pick = (a) => a[Math.floor(rand() * a.length)];
  const rint = (lo, hi) => Math.floor(rand() * (hi - lo + 1)) + lo;
  const rnum = (lo, hi, d=2) => +(rand() * (hi - lo) + lo).toFixed(d);

  // ---------- Vehicle hierarchy ----------
  // Tree: Portfolio root > Vehicle hierarchy (V1 … V14) > Investments at leaves
  const CLIENTS = [
    { id: "CL-ROOT", name: "Cepres Example Portfolio", kind: "portfolio", parentId: null }
  ];
  const VEHICLE_TREE = [
    // Level 1 — under the portfolio
    { id: "V-01", name: "V1", desc: "Master Fund of Funds",       kind: "master-fund", parentId: "CL-ROOT" },
    { id: "V-02", name: "V2", desc: "Public & Alternatives",      kind: "sleeve",      parentId: "CL-ROOT" },
    // Level 2 — sleeves under V1
    { id: "V-03", name: "V3", desc: "Private Equity FoF",         kind: "sleeve",      parentId: "V-01" },
    { id: "V-04", name: "V4", desc: "Venture FoF",                kind: "sleeve",      parentId: "V-01" },
    // Level 3 — sub-sleeves under V3 / V4
    { id: "V-05", name: "V5", desc: "NA Buyout Mandate",          kind: "sleeve",      parentId: "V-03" },
    { id: "V-06", name: "V6", desc: "EU Buyout Mandate",          kind: "sleeve",      parentId: "V-03" },
    { id: "V-07", name: "V7", desc: "Global Venture Mandate",     kind: "sleeve",      parentId: "V-04" },
    // Level 4 — leaf vehicles that hold investments
    { id: "V-08", name: "V8",  desc: "NA Large Cap Sleeve",       kind: "sleeve",      parentId: "V-05" },
    { id: "V-09", name: "V9",  desc: "NA Mid Market Sleeve",      kind: "sleeve",      parentId: "V-05" },
    { id: "V-10", name: "V10", desc: "EU Growth Sleeve",          kind: "sleeve",      parentId: "V-06" },
    { id: "V-11", name: "V11", desc: "NA Venture Sleeve",         kind: "sleeve",      parentId: "V-07" },
    // Leaf vehicles under V2 (public & alternatives)
    { id: "V-12", name: "V12", desc: "Equity Mandate",            kind: "sleeve",      parentId: "V-02" },
    { id: "V-13", name: "V13", desc: "Fixed Income Mandate",      kind: "sleeve",      parentId: "V-02" },
    { id: "V-14", name: "V14", desc: "Hedge & Co-invest Mandate", kind: "sleeve",      parentId: "V-02" },
  ];
  // Flat list of vehicle names for back-compat
  const VEHICLES = VEHICLE_TREE.map(v => v.name);

  // Leaf vehicles that receive private-market fund allocations (v8, v9, v10, v11).
  // Plus V-01 which holds a handful of direct primary investments at the top of the tree.
  const PRIVATE_LEAF_VEHICLES = ["V-08", "V-09", "V-10", "V-11"];
  // Private-market fund allocation plan (one vehicleId per fund, in order).
  const PRIVATE_VEHICLE_PLAN = [
    ...Array(4).fill("V-01"),   // 4 direct primaries at V1
    ...Array(18).fill("V-08"),  // NA Large Cap
    ...Array(18).fill("V-09"),  // NA Mid Market
    ...Array(18).fill("V-10"),  // EU Growth
    ...Array(6).fill("V-11"),   // NA Venture
  ];

  // ---------- Build Private Market funds (distributed across leaf vehicles) ----------
  const FUNDS = [];
  for (let i = 0; i < PRIVATE_VEHICLE_PLAN.length; i++) {
    const gp = pick(GP_NAMES);
    const vintage = rint(2014, 2023);
    const stage = pick(STAGES);
    const region = pick(REGIONS);
    const type = pick(TYPES);
    const vehicleId = PRIVATE_VEHICLE_PLAN[i];
    const vehicle = VEHICLE_TREE.find(v => v.id === vehicleId).name;
    const currency = pick(CURRENCIES);
    const status = vintage < 2017 ? pick(["Harvesting", "Realized", "Winding Down"]) : pick(STATUSES);
    const realization = status === "Realized" ? "realized" : (rand() < 0.08 ? "future" : "active");
    const committed = rint(5, 75) * 5;
    const paidIn = +(committed * rnum(0.55, 0.95)).toFixed(1);
    const distributed = +(paidIn * rnum(0.1, 1.4)).toFixed(1);
    const nav = status === "Realized" ? 0 : +(paidIn * rnum(0.8, 1.8)).toFixed(1);
    const tvpiInterim = +((distributed + nav) / Math.max(paidIn, 0.1)).toFixed(2);
    const tgtCepres = +(tvpiInterim + rnum(-0.1, 0.4)).toFixed(2);
    const tgtClient = +(tgtCepres + rnum(-0.15, 0.2)).toFixed(2);
    const tvpiMin = +(tgtCepres - rnum(0.3, 0.6)).toFixed(2);
    const tvpiMax = +(tgtCepres + rnum(0.4, 0.9)).toFixed(2);
    const pod = +rnum(0.02, 0.18, 3);
    const hasSale = status === "Realized" || (rand() < 0.25 && vintage < 2020);
    const salesDate = hasSale ? `${vintage + rint(3, 6)}-06-30` : null;
    const salesPrice = hasSale ? +((nav || paidIn) * rnum(0.85, 1.15)).toFixed(1) : null;
    // Map legacy `type` onto the new unified asset-type taxonomy
    const assetTypeFromLegacy =
      type === "Secondary"     ? "secondary" :
      type === "Co-investment" ? "coinvestment" :
                                 "primary"; // Primary and Fund-of-Funds both land here
    FUNDS.push({
      id: `FND-${String(1000 + i)}`,
      assetType: assetTypeFromLegacy,
      realization,
      clientId: `CL-${String(200 + i).padStart(4,'0')}`,
      name: `${gp} Fund ${["I","II","III","IV","V","VI","VII"][Math.floor(rand()*7)]}`,
      gp,
      cfPattern: pick(CF_PATTERNS),
      cepresTvpi: tgtCepres,
      cepresTvpiStd: +rnum(0.12, 0.28),
      clientTvpi: tgtClient,
      clientTvpiStd: +rnum(0.10, 0.26),
      comment: ["High conviction","Under review","Benchmark position","Monitor Q4","—"][rint(0,4)],
      committed,
      contributed: paidIn,
      currency,
      dateFirstProj: `${vintage+1}-Q2`,
      dateInitialCf: `${vintage}-09-15`,
      dateNav: "2026-03-31",
      distributedBefore: +(distributed * rnum(0.0, 0.2)).toFixed(1),
      distributed,
      exitDate: status === "Realized" ? `${vintage+8}-06-30` : `${vintage+10}-12-31`,
      fundManager: gp,
      geography: region,
      interimTvpi: tvpiInterim,
      investmentManager: ["S. Reiter","M. Chen","A. Okafor","L. Moreau","K. Wald"][rint(0,4)],
      nav,
      openCommitment: +(committed - paidIn).toFixed(1),
      paidInBefore: +(paidIn * rnum(0.0, 0.2)).toFixed(1),
      pod,
      purchaseDate: `${vintage}-11-30`,
      purchasePrice: +(paidIn * rnum(0.95, 1.05)).toFixed(1),
      salesDate,
      salesPrice,
      status,
      remainingContribDate: `${vintage+5}-12-31`,
      stage,
      tvpiMax,
      tvpiMin,
      type,
      vehicle,
      vehicleId,
      vintage
    });
  }

  // ---------- Public Market & other asset types ----------
  const PUB = [];
  function pubAsset(id, assetType, name, ticker, sector, region, value, cost, vehicleId, extra={}) {
    const realization = extra.realization || "active";
    PUB.push({
      id, assetType, realization,
      name, ticker, sector, geography: region,
      currency: "USD",
      vehicle: VEHICLE_TREE.find(v=>v.id===vehicleId)?.name,
      vehicleId,
      nav: value,                      // market value stands in for NAV
      committed: cost,                  // treat purchase cost as committed
      contributed: cost,
      distributed: extra.distributed || 0,
      openCommitment: 0,
      interimTvpi: +((value + (extra.distributed || 0)) / Math.max(cost, 0.01)).toFixed(2),
      cepresTvpi: extra.cepresTvpi ?? null,
      cepresTvpiStd: extra.cepresTvpiStd ?? null,
      clientTvpi: null,
      clientTvpiStd: null,
      tvpiMin: null, tvpiMax: null,
      pod: null,
      gp: extra.gp || null,
      fundManager: extra.gp || null,
      investmentManager: extra.investmentManager || "K. Wald",
      vintage: extra.vintage || 2024,
      stage: extra.stage || "-",
      type: extra.type || "-",
      comment: extra.comment || "—",
      status: realization === "realized" ? "Realized" : "Active",
      purchaseDate: extra.purchaseDate || "2024-09-15",
      purchasePrice: cost,
      salesDate: null,
      salesPrice: null,
      paidInBefore: 0, distributedBefore: 0,
      dateInitialCf: extra.purchaseDate || "2024-09-15",
      dateFirstProj: "2026-Q2",
      dateNav: "2026-03-31",
      remainingContribDate: "-",
      exitDate: "-",
      cfPattern: "-",
      clientId: "CL-" + id,
      ...extra
    });
  }

  // Stocks + ETFs live in V-12 (Equity Mandate)
  pubAsset("STK-AAPL", "stock", "Apple Inc.",        "AAPL",  "Tech",        "North America",  92.4, 64.0,  "V-12", { gp: "Listed" });
  pubAsset("STK-MSFT", "stock", "Microsoft Corp.",   "MSFT",  "Tech",        "North America", 138.2, 96.0,  "V-12", { gp: "Listed" });
  pubAsset("STK-NVDA", "stock", "NVIDIA Corp.",      "NVDA",  "Semis",       "North America",  85.6, 38.0,  "V-12", { gp: "Listed" });
  pubAsset("STK-LVMH", "stock", "LVMH SE",           "MC.PA", "Luxury",      "Europe",         44.8, 42.0,  "V-12", { gp: "Listed" });
  pubAsset("STK-ASML", "stock", "ASML Holding",      "ASML",  "Semis",       "Europe",         68.1, 50.5,  "V-12", { gp: "Listed" });
  pubAsset("STK-TSM",  "stock", "TSMC ADR",          "TSM",   "Semis",       "Asia Pacific",   52.0, 41.0,  "V-12", { gp: "Listed" });
  pubAsset("ETF-VTI",  "etf",   "Vanguard Total Market",  "VTI", "Equity",   "Global",        210.0, 148.0, "V-12", { gp: "Vanguard" });
  pubAsset("ETF-VWO",  "etf",   "Vanguard Emerging Mkts", "VWO", "Equity",   "Emerging",       58.0,  61.0, "V-12", { gp: "Vanguard" });

  // Bonds live in V-13 (Fixed Income). Per Liquidity module spec §3.2.2, bonds
  // carry acquisition_details with maturity_date, coupon_rate, coupon_frequency
  // (see §11.1.2). The cashflow projection service uses these to auto-derive
  // coupon payments and principal return at maturity.
  pubAsset("BND-UST10", "bond", "US Treasury 10Y",          "UST10",   "Sovereign", "North America", 120.0, 118.2, "V-13",
    { gp: "US Treasury", acquisition_details: { maturity_date: "2033-11-15", coupon_rate: 0.0425, coupon_frequency: "semi-annual", ytm: 0.043 } });
  pubAsset("BND-BUND",  "bond", "German Bund 10Y",          "DE10Y",   "Sovereign", "Europe",         80.0,  77.9, "V-13",
    { gp: "Bundesbank", acquisition_details: { maturity_date: "2033-08-15", coupon_rate: 0.025, coupon_frequency: "annual", ytm: 0.028 } });
  pubAsset("BND-IGCORP","bond", "Global IG Corporate",      "LQD",     "IG Credit", "Global",         62.5,  60.1, "V-13",
    { gp: "iShares", acquisition_details: { maturity_date: "2030-06-01", coupon_rate: 0.0475, coupon_frequency: "semi-annual", ytm: 0.051 } });
  pubAsset("BND-HY",    "bond", "US High Yield",            "HYG",     "HY Credit", "North America",  45.0,  47.4, "V-13",
    { gp: "iShares", acquisition_details: { maturity_date: "2029-03-15", coupon_rate: 0.068, coupon_frequency: "semi-annual", ytm: 0.074 } });
  pubAsset("ETF-VNQ",   "etf",  "Vanguard REIT",            "VNQ",     "Real Est.", "North America",  42.0,  38.5, "V-13", { gp: "Vanguard" });

  // Cash balances seeded across the leaf vehicles that the Liquidity module
  // will treat as the apex of their cash accounts. Amounts in $M.
  pubAsset("CSH-V08", "cash", "USD Operating Cash",     null, "Cash",   "Global",  18.0, 18.0, "V-08", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V09", "cash", "USD Operating Cash",     null, "Cash",   "Global",  12.0, 12.0, "V-09", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V10", "cash", "EUR Operating Cash",     null, "Cash",   "Europe",  11.0, 11.0, "V-10", { gp: "Treasury", currency: "EUR" });
  pubAsset("CSH-V11", "cash", "USD Operating Cash",     null, "Cash",   "Global",   8.5,  8.5, "V-11", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V12", "cash", "Public Equity Sweep",    null, "Cash",   "Global",   6.0,  6.0, "V-12", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V13", "cash", "Fixed Income Sweep",     null, "Cash",   "Global",   4.2,  4.2, "V-13", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V14", "cash", "Alternatives Sweep",     null, "Cash",   "Global",   9.5,  9.5, "V-14", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V01", "cash", "Master Fund Reserve",    null, "Cash",   "Global",  22.0, 22.0, "V-01", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V02", "cash", "Public & Alts Reserve",  null, "Cash",   "Global",  14.0, 14.0, "V-02", { gp: "Treasury", currency: "USD" });

  // Hedge Funds + a couple of co-investments in V-14
  pubAsset("HF-BRIDGE", "hedge","Bridgewater Pure Alpha",   null,      "Macro",     "Global",         120.0, 100.0, "V-14", { gp: "Bridgewater" });
  pubAsset("HF-CITAD",  "hedge","Citadel Wellington",       null,      "Multi-strat","Global",         90.0,  75.0, "V-14", { gp: "Citadel" });
  pubAsset("HF-DEMI",   "hedge","DE Shaw Composite",        null,      "Quant",     "Global",         70.0,  60.0, "V-14", { gp: "DE Shaw" });
  pubAsset("CO-STRIPE", "coinvestment","Stripe Series I",   null,      "Fintech",   "North America",  65.0,  48.0, "V-14", { gp: "Co-invest" });
  pubAsset("CO-DATADOG","coinvestment","Databricks Late",   null,      "SaaS",      "North America",  52.0,  40.0, "V-14", { gp: "Co-invest" });

  // ---------- Diversification overlay (spread every asset type across vehicles) ----------
  // The private-market plan above concentrates primaries/secondaries in V-08…V-11
  // and public assets in V-12…V-14. To give every leaf a realistic multi-asset
  // mix (per user request: "in ogni vehicle aggiungi molti piu asset di tutti i
  // tipi"), we sprinkle stocks, ETFs, bonds and hedge-fund sleeves into the
  // private leaves, and add cash reserves to the intermediate sleeves.

  // Stocks — spread across all leaf vehicles
  pubAsset("STK-GOOG", "stock", "Alphabet Inc.",           "GOOG",  "Tech",        "North America",  78.4, 52.0,  "V-08", { gp: "Listed" });
  pubAsset("STK-META", "stock", "Meta Platforms",          "META",  "Tech",        "North America",  62.1, 41.5,  "V-08", { gp: "Listed" });
  pubAsset("STK-AMZN", "stock", "Amazon.com",              "AMZN",  "Retail",      "North America",  88.0, 60.2,  "V-09", { gp: "Listed" });
  pubAsset("STK-BRKB", "stock", "Berkshire Hathaway B",    "BRK.B", "Conglomerate","North America",  95.4, 84.3,  "V-09", { gp: "Listed" });
  pubAsset("STK-SAP",  "stock", "SAP SE",                  "SAP",   "Tech",        "Europe",         54.2, 45.9,  "V-10", { gp: "Listed" });
  pubAsset("STK-NESN", "stock", "Nestlé SA",               "NESN",  "Staples",     "Europe",         48.6, 44.1,  "V-10", { gp: "Listed" });
  pubAsset("STK-TSLA", "stock", "Tesla Inc.",              "TSLA",  "Auto",        "North America",  71.8, 58.5,  "V-11", { gp: "Listed" });
  pubAsset("STK-BABA", "stock", "Alibaba Group",           "BABA",  "Tech",        "Asia Pacific",   34.7, 42.0,  "V-11", { gp: "Listed" });
  pubAsset("STK-SHOP", "stock", "Shopify",                 "SHOP",  "Tech",        "North America",  42.3, 30.8,  "V-12", { gp: "Listed" });
  pubAsset("STK-RIO",  "stock", "Rio Tinto",               "RIO",   "Materials",   "Global",         38.9, 35.1,  "V-12", { gp: "Listed" });
  pubAsset("STK-BP",   "stock", "BP plc",                  "BP",    "Energy",      "Europe",         26.5, 28.0,  "V-14", { gp: "Listed" });
  pubAsset("STK-SONY", "stock", "Sony Group",              "SONY",  "Tech",        "Asia Pacific",   31.4, 27.2,  "V-14", { gp: "Listed" });

  // ETFs — spread into private leaves and V-13
  pubAsset("ETF-QQQ",  "etf",   "Invesco QQQ Trust",       "QQQ",   "Tech",        "North America", 120.0, 98.5,  "V-08", { gp: "Invesco" });
  pubAsset("ETF-SPY",  "etf",   "SPDR S&P 500",            "SPY",   "Equity",      "North America", 145.2, 122.0, "V-09", { gp: "SSgA" });
  pubAsset("ETF-IEFA", "etf",   "iShares MSCI EAFE",       "IEFA",  "Equity",      "Developed",      72.6, 68.0,  "V-10", { gp: "iShares" });
  pubAsset("ETF-IEMG", "etf",   "iShares Emerging Mkts",   "IEMG",  "Equity",      "Emerging",       54.1, 58.5,  "V-11", { gp: "iShares" });
  pubAsset("ETF-AGG",  "etf",   "iShares Core Aggregate",  "AGG",   "Fixed Inc.",  "North America",  68.0, 71.2,  "V-13", { gp: "iShares" });
  pubAsset("ETF-GLD",  "etf",   "SPDR Gold Trust",         "GLD",   "Commodity",   "Global",         46.5, 38.2,  "V-13", { gp: "SSgA" });
  pubAsset("ETF-SCHD", "etf",   "Schwab US Dividend",      "SCHD",  "Equity",      "North America",  58.2, 51.0,  "V-14", { gp: "Schwab" });
  pubAsset("ETF-VXUS", "etf",   "Vanguard Intl Stock",     "VXUS",  "Equity",      "Global",         62.8, 59.0,  "V-12", { gp: "Vanguard" });

  // Bonds — spread into private leaves, with full acquisition_details
  pubAsset("BND-UST2",  "bond", "US Treasury 2Y",          "UST2",  "Sovereign",   "North America",  50.0, 49.4,  "V-08",
    { gp: "US Treasury", acquisition_details: { maturity_date: "2027-11-15", coupon_rate: 0.0425, coupon_frequency: "semi-annual", ytm: 0.044 } });
  pubAsset("BND-UST30", "bond", "US Treasury 30Y",         "UST30", "Sovereign",   "North America",  38.5, 40.2,  "V-09",
    { gp: "US Treasury", acquisition_details: { maturity_date: "2053-08-15", coupon_rate: 0.046,  coupon_frequency: "semi-annual", ytm: 0.049 } });
  pubAsset("BND-BTP",   "bond", "BTP Italy 10Y",           "BTP10", "Sovereign",   "Europe",         42.0, 41.1,  "V-10",
    { gp: "Italian Treasury", acquisition_details: { maturity_date: "2033-09-01", coupon_rate: 0.035, coupon_frequency: "annual", ytm: 0.041 } });
  pubAsset("BND-JGB",   "bond", "JGB 10Y",                 "JGB10", "Sovereign",   "Asia Pacific",   28.0, 28.3,  "V-11",
    { gp: "Bank of Japan", acquisition_details: { maturity_date: "2034-03-31", coupon_rate: 0.006, coupon_frequency: "semi-annual", ytm: 0.009 } });
  pubAsset("BND-MBS",   "bond", "Agency MBS Pool",         "MBS",   "MBS",         "North America",  55.4, 54.8,  "V-13",
    { gp: "Fannie/Freddie", acquisition_details: { maturity_date: "2045-12-01", coupon_rate: 0.052, coupon_frequency: "monthly", ytm: 0.058 } });
  pubAsset("BND-EMBI",  "bond", "EM Sovereign Composite",  "EMBI",  "EM Debt",     "Emerging",       32.8, 34.0,  "V-13",
    { gp: "JP Morgan", acquisition_details: { maturity_date: "2032-06-15", coupon_rate: 0.063, coupon_frequency: "semi-annual", ytm: 0.069 } });

  // Hedge funds — sprinkle into private leaves
  pubAsset("HF-MILL",  "hedge", "Millennium Partners",     null, "Multi-strat", "Global",         95.0,  82.5, "V-08", { gp: "Millennium" });
  pubAsset("HF-RENA",  "hedge", "Renaissance Medallion",   null, "Quant",       "Global",         75.6,  58.0, "V-09", { gp: "Renaissance" });
  pubAsset("HF-TWOS",  "hedge", "Two Sigma Spectrum",      null, "Quant",       "Global",         66.0,  55.0, "V-10", { gp: "Two Sigma" });
  pubAsset("HF-BAUP",  "hedge", "Baupost Value Fund",      null, "Value",       "Global",         48.5,  45.2, "V-11", { gp: "Baupost" });
  pubAsset("HF-ELLI",  "hedge", "Elliott Management",      null, "Activist",    "Global",         88.0,  72.0, "V-14", { gp: "Elliott" });
  pubAsset("HF-BRE",   "hedge", "Brevan Howard Macro",     null, "Macro",       "Global",         52.0,  49.0, "V-14", { gp: "Brevan Howard" });

  // Co-investments across private leaves
  pubAsset("CO-FANATICS","coinvestment","Fanatics Series H", null, "E-commerce",  "North America",  44.0, 32.0,  "V-08", { gp: "Co-invest" });
  pubAsset("CO-KLARNA", "coinvestment","Klarna Series D",    null, "Fintech",     "Europe",         38.5, 29.5,  "V-09", { gp: "Co-invest" });
  pubAsset("CO-CANVA",  "coinvestment","Canva Late Growth",  null, "SaaS",        "Asia Pacific",   46.2, 35.0,  "V-10", { gp: "Co-invest" });
  pubAsset("CO-SPACEX", "coinvestment","SpaceX Series J",    null, "Aerospace",   "North America",  68.0, 42.5,  "V-11", { gp: "Co-invest" });

  // Additional cash reserves for intermediate sleeves that had none
  pubAsset("CSH-V03", "cash", "PE FoF Reserve",    null, "Cash", "Global",  5.0,  5.0,  "V-03", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V04", "cash", "VC FoF Reserve",    null, "Cash", "Global",  3.5,  3.5,  "V-04", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V05", "cash", "NA Buyout Reserve", null, "Cash", "Global",  3.0,  3.0,  "V-05", { gp: "Treasury", currency: "USD" });
  pubAsset("CSH-V06", "cash", "EU Buyout Reserve", null, "Cash", "Global",  2.8,  2.8,  "V-06", { gp: "Treasury", currency: "EUR" });
  pubAsset("CSH-V07", "cash", "Venture Reserve",   null, "Cash", "Global",  2.4,  2.4,  "V-07", { gp: "Treasury", currency: "USD" });

  FUNDS.push(...PUB);

  // ---------- Portfolio headline aggregates ----------
  const countByType = FUNDS.reduce((m,f) => { m[f.assetType] = (m[f.assetType] || 0) + 1; return m; }, {});

  const PORTFOLIOS = [
    {
      id: "cepres-example",
      name: "Cepres Example Portfolio",
      owner: "Demo",
      updatedAt: "2026-04-12",
      funds: FUNDS.length,
      investments: FUNDS.length,
      byType: countByType,
      committed: FUNDS.reduce((s,f)=>s+f.committed,0),
      openCommitment: FUNDS.reduce((s,f)=>s+(f.openCommitment||0),0),
      nav: FUNDS.reduce((s,f)=>s+f.nav,0),
      tvpi: 1.42,
      simCount: 8,
    },
    {
      id: "gp-look-through-2025",
      name: "GP Look-Through 2025",
      owner: "S. Reiter",
      updatedAt: "2026-04-09",
      funds: 14, investments: 18, byType: { primary: 10, secondary: 2, coinvestment: 2, stock: 3, bond: 1 },
      committed: 1_220, openCommitment: 380, nav: 1_480, tvpi: 1.38, simCount: 3,
    },
    {
      id: "nordic-endowment-2024q4",
      name: "Nordic Endowment — Q4 2024",
      owner: "M. Chen",
      updatedAt: "2026-03-28",
      funds: 9, investments: 16, byType: { primary: 7, secondary: 2, stock: 4, bond: 2 },
      committed: 640, openCommitment: 210, nav: 720, tvpi: 1.31, simCount: 1,
    },
    {
      id: "kirkwood-families",
      name: "Kirkwood Family Office",
      owner: "L. Moreau",
      updatedAt: "2026-03-15",
      funds: 18, investments: 28, byType: { primary: 12, coinvestment: 4, secondary: 2, stock: 6, etf: 2, bond: 1 },
      committed: 950, openCommitment: 295, nav: 1_040, tvpi: 1.29, simCount: 0,
    },
  ];

  const ARCHIVED_PORTFOLIOS = [
    { id: "arch-1", name: "Legacy Fund-of-Funds 2019", owner: "S. Reiter", updatedAt: "2025-12-02",
      funds: 11, investments: 11, byType: { primary: 11 }, committed: 720, openCommitment: 0, nav: 180, tvpi: 1.58, simCount: 12 },
    { id: "arch-2", name: "Asia Growth Sleeve (closed)", owner: "K. Wald", updatedAt: "2025-09-18",
      funds: 6, investments: 8, byType: { primary: 5, coinvestment: 1, stock: 2 }, committed: 310, openCommitment: 48, nav: 64, tvpi: 1.22, simCount: 4 },
  ];

  const SIMULATIONS = [
    { id: "sim-1", name: "Base case Q2 2026", portfolio: "Cepres Example Portfolio", owner: "S. Reiter", created: "2026-04-10",
      depth: "full", status: "Completed", stressTests: [],
      headlineTvpi: 1.78, p10Tvpi: 1.34, p90Tvpi: 2.21, meanIrr: 0.168, meanDpi: 1.42, probLoss: 0.038 },
    { id: "sim-2", name: "Rate shock scenario", portfolio: "Cepres Example Portfolio", owner: "S. Reiter", created: "2026-04-11",
      depth: "full", status: "Completed", stressTests: ["Rate shock +200bps"],
      headlineTvpi: 1.54, p10Tvpi: 1.12, p90Tvpi: 1.96, meanIrr: 0.128, meanDpi: 1.21, probLoss: 0.082 },
    { id: "sim-3", name: "Deep recession stress", portfolio: "Cepres Example Portfolio", owner: "M. Chen", created: "2026-04-12",
      depth: "full", status: "Completed", stressTests: ["Deep recession (-5% GDP)","Illiquidity premium spike"],
      headlineTvpi: 1.31, p10Tvpi: 0.88, p90Tvpi: 1.74, meanIrr: 0.094, meanDpi: 0.98, probLoss: 0.184 },
    { id: "sim-4", name: "GP LT quick scan", portfolio: "GP Look-Through 2025", owner: "L. Moreau", created: "2026-04-08",
      depth: "fast", status: "Completed", stressTests: [],
      headlineTvpi: 1.52, p10Tvpi: 1.18, p90Tvpi: 1.86, meanIrr: 0.132, meanDpi: 1.18, probLoss: 0.072 },
    { id: "sim-5", name: "Nordic — base + FX", portfolio: "Nordic Endowment — Q4 2024", owner: "M. Chen", created: "2026-04-05",
      depth: "full", status: "Completed", stressTests: ["USD +15% vs G10"],
      headlineTvpi: 1.42, p10Tvpi: 1.09, p90Tvpi: 1.79, meanIrr: 0.118, meanDpi: 1.06, probLoss: 0.091 },
    { id: "sim-6", name: "Re-run with higher NAV", portfolio: "Cepres Example Portfolio", owner: "S. Reiter", created: "2026-04-12",
      depth: "fast", status: "In progress", stressTests: [],
      headlineTvpi: null, p10Tvpi: null, p90Tvpi: null, meanIrr: null, meanDpi: null, probLoss: null },
  ];

  // Cash flows for the featured fund (first fund)
  function buildCashflows(fund, seed) {
    const r = seeded(seed);
    const rows = [];
    const start = new Date(`${fund.vintage}-09-15`);
    const quarters = 28;
    let paidIn = 0;
    let distributed = 0;
    const targetPaid = fund.contributed;
    const targetDist = fund.distributed;
    for (let q = 0; q < quarters; q++) {
      const d = new Date(start);
      d.setMonth(d.getMonth() + q * 3);
      const iso = d.toISOString().slice(0,10);
      if (q < 16 && paidIn < targetPaid && r() < 0.55) {
        const amt = Math.min(targetPaid - paidIn, +(r() * targetPaid * 0.12 + 0.5).toFixed(1));
        paidIn += amt;
        rows.push({ id: `CF-${q}-C`, type: "Contribution", date: iso, amount: -amt });
      }
      if (q > 6 && distributed < targetDist && r() < 0.45) {
        const amt = +(r() * targetDist * 0.14 + 0.2).toFixed(1);
        distributed += amt;
        rows.push({ id: `CF-${q}-D`, type: "Distribution", date: iso, amount: amt });
      }
    }
    rows.push({ id: "CF-NAV", type: "Valuation", date: fund.dateNav, amount: fund.nav });
    return rows.sort((a,b)=> a.date < b.date ? -1 : 1);
  }

  // ---------- Monthly vehicle cashflow series (mock) ----------
  // For each vehicle, generate 36 months of: capital calls in (from parent),
  // capital drawdowns out (to parent), contributions out (to children),
  // distributions in (from children), plus ending cash & portfolio value.
  function buildVehicleSeries(vehicleId, opts={}) {
    const r = seeded(opts.seed || 1);
    const months = 36;
    const rows = [];
    let cash = opts.cashStart || 20;
    let value = opts.valueStart || 120;
    const start = new Date(2024, 0, 1);
    for (let i = 0; i < months; i++) {
      const d = new Date(start); d.setMonth(d.getMonth() + i);
      const iso = d.toISOString().slice(0,7); // YYYY-MM
      const capCall    = r() < 0.22 ? +(r() * 10 + 2).toFixed(1) : 0;   // +
      const capDraw    = r() < 0.15 ? -+(r() * 8 + 2).toFixed(1) : 0;    // -
      const contrib    = r() < 0.26 ? -+(r() * 6 + 1).toFixed(1) : 0;    // - (out to child)
      const distrib    = r() < 0.30 ? +(r() * 6 + 1).toFixed(1) : 0;     // + (in from child)
      const netCf      = +(capCall + capDraw + contrib + distrib).toFixed(2);
      cash = Math.max(0, +(cash + netCf).toFixed(2));
      // Portfolio value drifts with a tiny positive monthly return + noise
      const ret = (r() - 0.48) * 0.02 + 0.006;
      value = +(value * (1 + ret) + (capCall + contrib) * 0.1).toFixed(2);
      rows.push({
        month: iso, capCall, capDraw, contrib, distrib, netCf, cash, value
      });
    }
    return rows;
  }
  const VEHICLE_SERIES = {};
  VEHICLE_TREE.forEach((v, i) => {
    VEHICLE_SERIES[v.id] = buildVehicleSeries(v.id, {
      seed: 7 + i * 13,
      cashStart: v.kind === "cash-pool" ? 85 : (10 + i * 4),
      valueStart: v.kind === "master-fund" ? 2100 : v.kind === "cash-pool" ? 85 : 120 + i * 40
    });
  });

  // ---------- Monte-Carlo model parameter defaults per asset class ----------
  const MC_PARAMS = [
    { assetType: "primary",      model: "Pacing × Beta-LN", params: [
      { key: "targetTvpi",  label: "Target TVPI",       cepres: 1.68, unit: "×" },
      { key: "tvpiSigma",   label: "TVPI σ",            cepres: 0.22, unit: "×" },
      { key: "paceYears",   label: "Pacing (years)",    cepres: 5.0,  unit: "y" },
      { key: "beta",        label: "Beta to markets",   cepres: 0.45, unit: "" },
      { key: "copulaRho",   label: "Copula ρ to public",cepres: 0.38, unit: "" }
    ]},
    { assetType: "secondary",    model: "Pacing × Beta-LN (secondaries)", params: [
      { key: "targetTvpi",  label: "Target TVPI",       cepres: 1.52, unit: "×" },
      { key: "tvpiSigma",   label: "TVPI σ",            cepres: 0.18, unit: "×" },
      { key: "paceYears",   label: "Pacing (years)",    cepres: 3.5,  unit: "y" },
      { key: "beta",        label: "Beta to markets",   cepres: 0.42, unit: "" },
      { key: "copulaRho",   label: "Copula ρ to public",cepres: 0.35, unit: "" }
    ]},
    { assetType: "coinvestment", model: "Pacing × Beta-LN (co-inv)", params: [
      { key: "targetTvpi",  label: "Target TVPI",       cepres: 2.05, unit: "×" },
      { key: "tvpiSigma",   label: "TVPI σ",            cepres: 0.34, unit: "×" },
      { key: "paceYears",   label: "Pacing (years)",    cepres: 4.5,  unit: "y" },
      { key: "beta",        label: "Beta to markets",   cepres: 0.58, unit: "" },
      { key: "copulaRho",   label: "Copula ρ to public",cepres: 0.44, unit: "" }
    ]},
    { assetType: "stock",     model: "GBM + regime copula", params: [
      { key: "mu",          label: "Drift (annual)",    cepres: 0.085, unit: "%" },
      { key: "sigma",       label: "Volatility (ann.)", cepres: 0.188, unit: "%" },
      { key: "beta",        label: "Beta to MSCI",      cepres: 1.02,  unit: "" },
      { key: "copulaRho",   label: "Copula ρ to credit",cepres: -0.18, unit: "" }
    ]},
    { assetType: "bond",      model: "Vasicek + spread", params: [
      { key: "meanRate",    label: "Mean reversion rate", cepres: 0.034, unit: "%" },
      { key: "kappa",       label: "Speed κ",           cepres: 0.62,  unit: "" },
      { key: "sigmaR",      label: "Rate σ",            cepres: 0.010, unit: "" },
      { key: "spread",      label: "Avg spread",        cepres: 0.011, unit: "%" },
      { key: "copulaRho",   label: "Copula ρ to equity",cepres: -0.22, unit: "" }
    ]},
    { assetType: "etf",       model: "Index GBM",  params: [
      { key: "mu",          label: "Drift (annual)",    cepres: 0.072, unit: "%" },
      { key: "sigma",       label: "Volatility (ann.)", cepres: 0.154, unit: "%" },
      { key: "tracking",    label: "Tracking error",    cepres: 0.004, unit: "" },
      { key: "copulaRho",   label: "Copula ρ to equity",cepres: 0.95,  unit: "" }
    ]},
    { assetType: "hedge",     model: "Cornish-Fisher + factor",  params: [
      { key: "mu",          label: "Drift (annual)",    cepres: 0.061, unit: "%" },
      { key: "sigma",       label: "Volatility (ann.)", cepres: 0.082, unit: "%" },
      { key: "skew",        label: "Skewness",          cepres: -0.31, unit: "" },
      { key: "kurtosis",    label: "Excess kurtosis",   cepres: 1.44,  unit: "" }
    ]},
  ];

  // ---------- Strategy presets (rebalancing targets) ----------
  const STRATEGY_PRESETS = [
    { id: "conservative", name: "Conservative",     tgt: { bond: 0.45, stock: 0.25, primary: 0.15, secondary: 0.05, coinvestment: 0.05, hedge: 0.05 },
      desc: "Cover worst-case liquidity needs (P5). Prioritize capital preservation." },
    { id: "balanced",     name: "Balanced",         tgt: { bond: 0.25, stock: 0.25, primary: 0.25, secondary: 0.10, coinvestment: 0.05, hedge: 0.10 },
      desc: "Balance return and liquidity. Target ~P10 coverage." },
    { id: "growth",       name: "Growth",           tgt: { bond: 0.10, stock: 0.25, primary: 0.35, secondary: 0.10, coinvestment: 0.10, hedge: 0.10 },
      desc: "Maximize TVPI, accept higher capital-call risk." },
    { id: "auto",         name: "Auto-optimize",    tgt: null,
      desc: "Let Cepres find the strategy for your objective (e.g. P10 liquidity + max TVPI)." }
  ];

  const STRESS_TESTS = [
    { id: "rate-shock", name: "Rate shock +200bps", desc: "Parallel upward rate shift, 2Y horizon" },
    { id: "recession-mild", name: "Mild recession (-2% GDP)", desc: "2-year drawdown scenario, slow recovery" },
    { id: "recession-deep", name: "Deep recession (-5% GDP)", desc: "3-year drawdown, credit spreads widen 400bps" },
    { id: "tech-rerate", name: "Tech re-rating -30%", desc: "Multiple compression in growth stage exits" },
    { id: "fx-usd-strength", name: "USD +15% vs G10", desc: "Translation losses for non-USD funds" },
    { id: "illiquidity", name: "Illiquidity premium spike", desc: "Secondary NAV haircut of 15%" },
  ];

  // ---------- Helpers ----------
  function assetTypeMeta(id) { return ASSET_TYPES.find(a => a.id === id) || ASSET_TYPES[0]; }
  function vehicleById(id)  { return VEHICLE_TREE.find(v => v.id === id); }
  function childrenOf(id)   { return VEHICLE_TREE.filter(v => v.parentId === id); }
  function assetsOfVehicle(id) { return FUNDS.filter(f => f.vehicleId === id); }
  function descendantVehicles(id) {
    const out = [];
    const stack = [id];
    while (stack.length) {
      const cur = stack.pop();
      childrenOf(cur).forEach(c => { out.push(c); stack.push(c.id); });
    }
    return out;
  }
  // Sum NAV of everything under a vehicle (direct assets + all descendants' assets)
  function aggregateVehicleValue(id) {
    const direct = assetsOfVehicle(id).reduce((s, a) => s + (a.nav || 0), 0);
    const desc = descendantVehicles(id).reduce(
      (s, v) => s + assetsOfVehicle(v.id).reduce((ss, a) => ss + (a.nav || 0), 0), 0
    );
    return direct + desc;
  }

  // ---------- Liquidity Module repository / service layer ----------
  // Frontend-only prototype: "repositories" are in-memory mutations over the
  // PI_DATA arrays above. In a real backend these would map 1:1 to REST
  // endpoints (see checklist.md §1.2). Each helper mirrors the signature
  // requested by the spec (descrizione.md §11).

  // --- Vehicle repository (checklist 1.1.4) ---
  function getVehicleById(id) { return vehicleById(id); }
  function getVehiclesByPortfolioId(portfolioId) {
    // Root client IDs (e.g. "CL-ROOT") are parents of the top-level vehicles.
    // Return every vehicle in the subtree rooted at the portfolio node.
    const roots = VEHICLE_TREE.filter(v => v.parentId === portfolioId);
    const out = [...roots];
    roots.forEach(r => descendantVehicles(r.id).forEach(d => out.push(d)));
    return out;
  }
  // Returns a nested tree: { id, name, parent_id, children: [...], children_count }
  function getVehicleHierarchy(rootId) {
    const root = rootId.startsWith("CL-") ? CLIENTS.find(c => c.id === rootId) : vehicleById(rootId);
    if (!root) return null;
    const build = (node) => {
      const kids = childrenOf(node.id).map(build);
      return {
        id: node.id,
        name: node.name,
        desc: node.desc || null,
        kind: node.kind || (node.id.startsWith("CL-") ? "portfolio" : "sleeve"),
        parent_id: node.parentId || null,
        children: kids,
        children_count: kids.length
      };
    };
    return build(root);
  }
  let __vehicleSeq = VEHICLE_TREE.length + 1;
  function createVehicle(portfolioId, parentId, name, desc) {
    const id = `V-${String(__vehicleSeq++).padStart(2, "0")}`;
    const v = { id, name: name || id, desc: desc || "", kind: "sleeve", parentId: parentId || portfolioId };
    VEHICLE_TREE.push(v);
    VEHICLES.push(v.name);
    return v;
  }
  function updateVehicle(id, name, desc) {
    const v = vehicleById(id);
    if (!v) return null;
    if (name !== undefined) v.name = name;
    if (desc !== undefined) v.desc = desc;
    return v;
  }
  function deleteVehicle(id) {
    if (childrenOf(id).length > 0) throw new Error("Cannot delete vehicle with children");
    if (assetsOfVehicle(id).length > 0) throw new Error("Cannot delete vehicle with asset positions");
    const i = VEHICLE_TREE.findIndex(v => v.id === id);
    if (i < 0) return false;
    VEHICLE_TREE.splice(i, 1);
    return true;
  }

  // --- AssetPosition repository (checklist 1.1.5) ---
  function getAssetPositionsByVehicleId(id) { return assetsOfVehicle(id); }
  let __positionSeq = 9000;
  function createAssetPosition(vehicleId, assetType, symbolOrName, quantity, currentValue, extra) {
    const id = `POS-${__positionSeq++}`;
    const v = vehicleById(vehicleId);
    const row = {
      id,
      assetType,
      realization: "active",
      name: symbolOrName,
      ticker: symbolOrName,
      sector: extra?.sector || "-",
      geography: extra?.geography || "Global",
      currency: extra?.currency || "USD",
      vehicle: v?.name, vehicleId,
      nav: currentValue, committed: extra?.cost_basis ?? currentValue,
      contributed: extra?.cost_basis ?? currentValue,
      distributed: 0, openCommitment: 0,
      interimTvpi: 1, cepresTvpi: null, cepresTvpiStd: null, clientTvpi: null, clientTvpiStd: null,
      tvpiMin: null, tvpiMax: null, pod: null,
      gp: extra?.gp || "—", fundManager: extra?.gp || "—",
      investmentManager: extra?.investmentManager || "—",
      vintage: extra?.vintage || new Date().getFullYear(),
      stage: "-", type: "-", comment: "—", status: "Active",
      purchaseDate: extra?.acquisition_date || new Date().toISOString().slice(0, 10),
      purchasePrice: extra?.cost_basis ?? currentValue,
      salesDate: null, salesPrice: null,
      paidInBefore: 0, distributedBefore: 0,
      dateInitialCf: extra?.acquisition_date || new Date().toISOString().slice(0, 10),
      dateFirstProj: "2026-Q2",
      dateNav: new Date().toISOString().slice(0, 10),
      remainingContribDate: "-", exitDate: "-", cfPattern: "-", clientId: `CL-${id}`,
      quantity,
      acquisition_details: extra?.acquisition_details || null
    };
    FUNDS.push(row);
    return row;
  }
  function updateAssetPosition(id, patch) {
    const p = FUNDS.find(f => f.id === id);
    if (!p) return null;
    if (patch.quantity !== undefined) p.quantity = patch.quantity;
    if (patch.current_value !== undefined) p.nav = patch.current_value;
    if (patch.acquisition_details !== undefined) p.acquisition_details = patch.acquisition_details;
    return p;
  }
  function deleteAssetPosition(id) {
    const i = FUNDS.findIndex(f => f.id === id);
    if (i < 0) return false;
    FUNDS.splice(i, 1);
    return true;
  }
  // Compose by spec asset type (7 buckets). Looks at the vehicle + all
  // descendants' direct positions. Returns { totalValue, bySpecType, byInternalType }.
  function calculateVehicleComposition(vehicleId) {
    const ids = [vehicleId, ...descendantVehicles(vehicleId).map(v => v.id)];
    const positions = FUNDS.filter(f => ids.includes(f.vehicleId));
    const total = positions.reduce((s, p) => s + (p.nav || 0), 0);
    const bySpec = Object.fromEntries(SPEC_ASSET_TYPES.map(t => [t, 0]));
    const byInternal = Object.fromEntries(ASSET_TYPES.map(t => [t.id, 0]));
    positions.forEach(p => {
      const specKey = INTERNAL_TO_SPEC[p.assetType] || "primary_funds";
      bySpec[specKey] += p.nav || 0;
      byInternal[p.assetType] = (byInternal[p.assetType] || 0) + (p.nav || 0);
    });
    const pctSpec = Object.fromEntries(
      SPEC_ASSET_TYPES.map(t => [t, total > 0 ? bySpec[t] / total : 0])
    );
    return { totalValue: total, valueBySpecType: bySpec, pctBySpecType: pctSpec, valueByInternalType: byInternal, positions };
  }

  // --- Ancestry helpers (checklist 1.4.3) ---
  function getParentVehicleId(id) { const v = vehicleById(id); return v ? v.parentId : null; }
  function getChildVehicles(id) { return childrenOf(id); }
  function getVehicleAncestry(id) {
    // Returns [root, ..., parent, self]
    const out = [];
    let cur = vehicleById(id);
    while (cur) {
      out.unshift({ id: cur.id, name: cur.name, kind: cur.kind });
      if (!cur.parentId) break;
      if (cur.parentId.startsWith("CL-")) {
        const c = CLIENTS.find(x => x.id === cur.parentId);
        if (c) out.unshift({ id: c.id, name: c.name, kind: c.kind });
        break;
      }
      cur = vehicleById(cur.parentId);
    }
    return out;
  }

  // ---------- Liquidity strategies (Phase 2 — checklist §2) ----------
  // Canonical spec data model per descrizione.md §11.1.3 / §11.1.4.
  // Uses spec asset-type keys (cash / bonds / stocks / etfs / hedge_funds /
  // secondary_funds / primary_funds). Stored alongside, not replacing, the
  // existing `STRATEGY_PRESETS` (which drives the Universe view and uses
  // internal asset ids).

  const DEFAULT_LIQ_PRIORITY = ["cash", "bonds", "stocks", "etfs", "hedge_funds", "secondary_funds", "primary_funds"];
  const NOW_ISO = new Date().toISOString();

  // Standard HF constraints applied to every preset (checklist §2.2.1:
  // quarterly redemptions, 30 days notice, 20% per period, no annual cap).
  const STD_HEDGE_CONSTRAINT = {
    asset_type: "hedge_funds",
    redemption_frequency: "quarterly", notice_period_days: 30,
    max_redemption_pct_per_period: 20,
    annual_redemption_cap_by_year: null,
    estimated_liquidation_timeline_months: null,
    max_liquidation_pct_per_year: null,
    exclude_from_liquidation: null,
  };
  const STD_SECONDARY_CONSTRAINT = {
    asset_type: "secondary_funds",
    redemption_frequency: null, notice_period_days: null,
    max_redemption_pct_per_period: null, annual_redemption_cap_by_year: null,
    estimated_liquidation_timeline_months: 48, max_liquidation_pct_per_year: 25,
    exclude_from_liquidation: null,
  };
  const STD_PRIMARY_CONSTRAINT = {
    asset_type: "primary_funds",
    redemption_frequency: null, notice_period_days: null,
    max_redemption_pct_per_period: null, annual_redemption_cap_by_year: null,
    estimated_liquidation_timeline_months: null, max_liquidation_pct_per_year: null,
    exclude_from_liquidation: null,
  };

  const LIQUIDITY_STRATEGIES = [
    {
      id: "STRAT-CONS", vehicle_id: null,
      name: "Conservative",
      description: "Cover worst-case liquidity needs. Cash 30%, Bonds 40%, Stocks 20%, Hedge Funds 10%.",
      is_preset: true, is_reusable: true,
      liquidation_priority: DEFAULT_LIQ_PRIORITY.slice(),
      is_proportional: false,
      rebalancing_frequency: "annual", rebalancing_trigger: "fixed",
      rebalancing_target_allocation: { cash: 30, bonds: 40, stocks: 20, etfs: 0, hedge_funds: 10, secondary_funds: 0, primary_funds: 0 },
      rebalancing_tolerance_pct: null,
      min_cash_reserve_pct: null, min_cash_reserve_percentile: null,
      created_at: NOW_ISO, updated_at: NOW_ISO,
    },
    {
      id: "STRAT-BAL", vehicle_id: null,
      name: "Balanced",
      description: "Balance return and liquidity. Cash 15%, Bonds 35%, Stocks 35%, Hedge Funds 15%.",
      is_preset: true, is_reusable: true,
      liquidation_priority: DEFAULT_LIQ_PRIORITY.slice(),
      is_proportional: false,
      rebalancing_frequency: "annual", rebalancing_trigger: "fixed",
      rebalancing_target_allocation: { cash: 15, bonds: 35, stocks: 35, etfs: 0, hedge_funds: 15, secondary_funds: 0, primary_funds: 0 },
      rebalancing_tolerance_pct: null,
      min_cash_reserve_pct: null, min_cash_reserve_percentile: null,
      created_at: NOW_ISO, updated_at: NOW_ISO,
    },
    {
      id: "STRAT-GROWTH", vehicle_id: null,
      name: "Growth",
      description: "Tilt toward equity-like returns. Cash 10%, Bonds 20%, Stocks 50%, Hedge Funds 20%.",
      is_preset: true, is_reusable: true,
      liquidation_priority: DEFAULT_LIQ_PRIORITY.slice(),
      is_proportional: false,
      rebalancing_frequency: "annual", rebalancing_trigger: "tolerance",
      rebalancing_target_allocation: { cash: 10, bonds: 20, stocks: 50, etfs: 0, hedge_funds: 20, secondary_funds: 0, primary_funds: 0 },
      rebalancing_tolerance_pct: 5,
      min_cash_reserve_pct: null, min_cash_reserve_percentile: null,
      created_at: NOW_ISO, updated_at: NOW_ISO,
    },
    {
      id: "STRAT-AGG", vehicle_id: null,
      name: "Aggressive",
      description: "Maximise growth. Cash 5%, Stocks 60%, Hedge Funds 35%. No fixed-income buffer.",
      is_preset: true, is_reusable: true,
      liquidation_priority: DEFAULT_LIQ_PRIORITY.slice(),
      is_proportional: false,
      rebalancing_frequency: "annual", rebalancing_trigger: "tolerance",
      rebalancing_target_allocation: { cash: 5, bonds: 0, stocks: 60, etfs: 0, hedge_funds: 35, secondary_funds: 0, primary_funds: 0 },
      rebalancing_tolerance_pct: 7,
      min_cash_reserve_pct: null, min_cash_reserve_percentile: null,
      created_at: NOW_ISO, updated_at: NOW_ISO,
    },
  ];

  // Constraints table (asset_type_constraints). Each preset has HF + Secondary + Primary.
  let __constrSeq = 1;
  const mkConstraint = (strategyId, c) => ({
    id: `CONSTR-${String(__constrSeq++).padStart(4, "0")}`,
    strategy_id: strategyId, ...c, created_at: NOW_ISO, updated_at: NOW_ISO
  });
  const ASSET_TYPE_CONSTRAINTS = [];
  LIQUIDITY_STRATEGIES.forEach(s => {
    ASSET_TYPE_CONSTRAINTS.push(mkConstraint(s.id, STD_HEDGE_CONSTRAINT));
    ASSET_TYPE_CONSTRAINTS.push(mkConstraint(s.id, STD_SECONDARY_CONSTRAINT));
    ASSET_TYPE_CONSTRAINTS.push(mkConstraint(s.id, STD_PRIMARY_CONSTRAINT));
  });

  // vehicle_id → strategy_id (prototype in-memory; would be a join column).
  const VEHICLE_STRATEGY_ASSIGNMENTS = {};

  // --- Strategy repository (checklist §2.3) ---
  let __stratSeq = 2000;
  function getPresetStrategies() {
    return LIQUIDITY_STRATEGIES.filter(s => s.is_preset);
  }
  function getStrategyById(id) {
    return LIQUIDITY_STRATEGIES.find(s => s.id === id) || null;
  }
  function getConstraintsByStrategyId(strategyId) {
    return ASSET_TYPE_CONSTRAINTS.filter(c => c.strategy_id === strategyId);
  }
  function getStrategyByVehicleId(vehicleId) {
    const sid = VEHICLE_STRATEGY_ASSIGNMENTS[vehicleId];
    if (!sid) return null;
    const s = getStrategyById(sid);
    if (!s) return null;
    return { ...s, constraints: getConstraintsByStrategyId(sid) };
  }
  function getReusableStrategies() {
    return LIQUIDITY_STRATEGIES.filter(s => s.is_reusable);
  }
  // Validation (checklist §2.5). Returns a plain object keyed by field name;
  // empty object ⇒ strategy is valid. `constraints` is a nested map by asset_type.
  function validateStrategy(payload) {
    const errs = {};
    if (!payload || typeof payload !== "object") return { _root: "Strategy payload required" };
    if (!payload.name || !String(payload.name).trim()) errs.name = "Strategy name is required";
    if (!payload.is_proportional) {
      const lp = Array.isArray(payload.liquidation_priority) ? payload.liquidation_priority : [];
      if (lp.length === 0) errs.liquidation_priority = "Add at least one asset type";
      else {
        const dup = lp.find((t, i) => lp.indexOf(t) !== i);
        if (dup) errs.liquidation_priority = `Duplicate asset type: ${dup}`;
        else {
          const bad = lp.filter(t => !SPEC_ASSET_TYPES.includes(t));
          if (bad.length) errs.liquidation_priority = `Unknown asset type(s): ${bad.join(", ")}`;
        }
      }
    }
    const trig = payload.rebalancing_trigger;
    if (trig === "fixed" || trig === "tolerance") {
      const a = payload.rebalancing_target_allocation || {};
      const vals = Object.values(a).map(v => Number(v) || 0);
      if (vals.some(v => v < 0)) errs.rebalancing_target_allocation = "Allocation percentages must not be negative";
      else {
        const sum = vals.reduce((s, v) => s + v, 0);
        if (Math.abs(sum - 100) > 0.01) errs.rebalancing_target_allocation = `Target allocation must sum to 100% (currently ${sum.toFixed(1)}%)`;
      }
    }
    if (trig === "tolerance") {
      const t = Number(payload.rebalancing_tolerance_pct);
      if (!(t > 0 && t <= 100)) errs.rebalancing_tolerance_pct = "Tolerance must be between 0 and 100%";
    }
    if (trig === "min_cash_reserve") {
      const hasPct = payload.min_cash_reserve_pct != null && payload.min_cash_reserve_pct !== "";
      const hasPct_ = payload.min_cash_reserve_percentile;
      if (!hasPct && !hasPct_) errs.min_cash_reserve_pct = "Specify a minimum cash % or a percentile scenario";
      else if (hasPct) {
        const m = Number(payload.min_cash_reserve_pct);
        if (!(m >= 0 && m <= 100)) errs.min_cash_reserve_pct = "Min cash % must be between 0 and 100";
      }
    }
    const cerrs = {};
    (payload.constraints || []).forEach(c => {
      const e = {};
      if (c.asset_type === "hedge_funds") {
        if (c.notice_period_days != null && Number(c.notice_period_days) < 0) e.notice_period_days = "Must be ≥ 0";
        if (c.max_redemption_pct_per_period != null) {
          const v = Number(c.max_redemption_pct_per_period);
          if (!(v > 0 && v <= 100)) e.max_redemption_pct_per_period = "Must be between 0 and 100%";
        }
        if (c.annual_redemption_cap_by_year && typeof c.annual_redemption_cap_by_year === "object") {
          Object.entries(c.annual_redemption_cap_by_year).forEach(([y, v]) => {
            const n = Number(v);
            if (!(n >= 0 && n <= 100)) e.annual_redemption_cap_by_year = `Cap for ${y} must be between 0 and 100%`;
          });
        }
      }
      if (c.asset_type === "secondary_funds" || c.asset_type === "primary_funds") {
        if (c.estimated_liquidation_timeline_months != null && c.estimated_liquidation_timeline_months !== "") {
          const v = Number(c.estimated_liquidation_timeline_months);
          if (!(v > 0)) e.estimated_liquidation_timeline_months = "Timeline (months) must be > 0";
        }
        if (c.max_liquidation_pct_per_year != null && c.max_liquidation_pct_per_year !== "") {
          const v = Number(c.max_liquidation_pct_per_year);
          if (!(v > 0 && v <= 100)) e.max_liquidation_pct_per_year = "Must be between 0 and 100%";
        }
      }
      if (Object.keys(e).length) cerrs[c.asset_type] = e;
    });
    if (Object.keys(cerrs).length) errs.constraints = cerrs;
    return errs;
  }
  function createStrategy(vehicleId, payload) {
    const errs = validateStrategy(payload);
    if (Object.keys(errs).length) { const err = new Error("Strategy validation failed"); err.errors = errs; throw err; }
    const id = `STRAT-V${String(__stratSeq++).padStart(4, "0")}`;
    const { constraints = [], ...rest } = payload;
    const strategy = {
      id, vehicle_id: vehicleId,
      is_preset: false, is_reusable: !!payload.is_reusable,
      created_at: NOW_ISO, updated_at: NOW_ISO,
      rebalancing_frequency: "annual",
      ...rest,
    };
    LIQUIDITY_STRATEGIES.push(strategy);
    constraints.forEach(c => ASSET_TYPE_CONSTRAINTS.push(mkConstraint(id, c)));
    if (vehicleId) VEHICLE_STRATEGY_ASSIGNMENTS[vehicleId] = id;
    return { ...strategy, constraints: getConstraintsByStrategyId(id) };
  }
  function updateStrategy(strategyId, payload) {
    const errs = validateStrategy(payload);
    if (Object.keys(errs).length) { const err = new Error("Strategy validation failed"); err.errors = errs; throw err; }
    const idx = LIQUIDITY_STRATEGIES.findIndex(s => s.id === strategyId);
    if (idx < 0) return null;
    const { constraints = [], ...rest } = payload;
    const nowIso = new Date().toISOString();
    const updated = { ...LIQUIDITY_STRATEGIES[idx], ...rest, updated_at: nowIso };
    LIQUIDITY_STRATEGIES[idx] = updated;
    for (let i = ASSET_TYPE_CONSTRAINTS.length - 1; i >= 0; i--) {
      if (ASSET_TYPE_CONSTRAINTS[i].strategy_id === strategyId) ASSET_TYPE_CONSTRAINTS.splice(i, 1);
    }
    constraints.forEach(c => ASSET_TYPE_CONSTRAINTS.push(mkConstraint(strategyId, c)));
    return { ...updated, constraints: getConstraintsByStrategyId(strategyId) };
  }
  function deleteStrategy(strategyId) {
    const idx = LIQUIDITY_STRATEGIES.findIndex(s => s.id === strategyId);
    if (idx < 0) return false;
    LIQUIDITY_STRATEGIES.splice(idx, 1);
    for (let i = ASSET_TYPE_CONSTRAINTS.length - 1; i >= 0; i--) {
      if (ASSET_TYPE_CONSTRAINTS[i].strategy_id === strategyId) ASSET_TYPE_CONSTRAINTS.splice(i, 1);
    }
    Object.keys(VEHICLE_STRATEGY_ASSIGNMENTS).forEach(vid => {
      if (VEHICLE_STRATEGY_ASSIGNMENTS[vid] === strategyId) delete VEHICLE_STRATEGY_ASSIGNMENTS[vid];
    });
    return true;
  }
  function assignStrategyToVehicle(strategyId, vehicleId) {
    if (!getStrategyById(strategyId)) return null;
    VEHICLE_STRATEGY_ASSIGNMENTS[vehicleId] = strategyId;
    return getStrategyByVehicleId(vehicleId);
  }
  // Clone a strategy (typically a preset) onto a list of vehicles.
  function applyStrategyToVehicles(strategyId, vehicleIds) {
    const s = getStrategyById(strategyId);
    if (!s) return [];
    return vehicleIds.map(vid => {
      const baseConstraints = getConstraintsByStrategyId(strategyId).map(c => {
        const { id, strategy_id, created_at, updated_at, ...rest } = c;
        return rest;
      });
      return createStrategy(vid, {
        name: `${s.name} (copy)`,
        description: s.description,
        liquidation_priority: s.liquidation_priority.slice(),
        is_proportional: s.is_proportional,
        rebalancing_trigger: s.rebalancing_trigger,
        rebalancing_target_allocation: { ...s.rebalancing_target_allocation },
        rebalancing_tolerance_pct: s.rebalancing_tolerance_pct,
        min_cash_reserve_pct: s.min_cash_reserve_pct,
        min_cash_reserve_percentile: s.min_cash_reserve_percentile,
        is_reusable: false,
        constraints: baseConstraints,
      });
    });
  }

  // --- Cashflow projection (checklist 1.4.1) ---
  // Phase 1 prototype: deterministic mean projection derived from VEHICLE_SERIES.
  // Aggregates direct + descendant vehicle rows across the requested window.
  // Returns an array of { period, contribution, distribution, capital_call,
  // capital_drawdown, net_cashflow } in YYYY-MM buckets.
  function projectCashflows(vehicleId, startIso, endIso) {
    const ids = [vehicleId, ...descendantVehicles(vehicleId).map(v => v.id)];
    const merged = {};
    ids.forEach(id => (VEHICLE_SERIES[id] || []).forEach(r => {
      if (startIso && r.month < startIso.slice(0, 7)) return;
      if (endIso   && r.month > endIso.slice(0, 7))   return;
      const m = merged[r.month] || { period: r.month, contribution: 0, distribution: 0, capital_call: 0, capital_drawdown: 0, net_cashflow: 0 };
      m.contribution     += Math.abs(r.contrib);   // outgoing to children (positive magnitude)
      m.distribution     += r.distrib;              // incoming from children
      m.capital_call     += r.capCall;              // incoming from parent
      m.capital_drawdown += Math.abs(r.capDraw);    // outgoing to parent (positive magnitude)
      m.net_cashflow     += r.netCf;
      merged[r.month] = m;
    }));
    return Object.values(merged).sort((a, b) => a.period < b.period ? -1 : 1);
  }

  // --- Phase 3: Liquidity Forecast (checklist §3.1) ---
  // Deterministic, mean-only, month-by-month projection combining cashflows,
  // portfolio value evolution, and strategy-driven rebalancing.
  //
  // Per spec §3.1.2: "for now, assume 0% growth/decline" (flat asset returns).
  // Rebalancing is evaluated on the strategy's trigger (annual-fixed or
  // drift-tolerance). Cash reserve target is surfaced for the Cash Balance
  // chart's target-zone overlay.

  function _monthKey(d) {
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
  }
  function _addMonths(d, n) {
    const r = new Date(d); r.setMonth(r.getMonth() + n); return r;
  }
  // Deterministic synthetic cashflow pattern for months beyond the seeded
  // VEHICLE_SERIES window. Mirrors the shape used in buildVehicleSeries so
  // projections "feel" continuous with historical data.
  function _syntheticCashflow(vehicleId, monthIdx) {
    // Hash-based pseudo-random per (vehicle, month)
    const key = vehicleId + ":" + monthIdx;
    let h = 2166136261;
    for (let i = 0; i < key.length; i++) { h ^= key.charCodeAt(i); h = Math.imul(h, 16777619); }
    const r1 = ((h >>> 0) / 4294967296);
    const r2 = (((h ^ 0xdeadbeef) >>> 0) / 4294967296);
    const r3 = (((h ^ 0x13371337) >>> 0) / 4294967296);
    const r4 = (((h ^ 0xabad1dea) >>> 0) / 4294967296);
    const capCall = r1 < 0.22 ? +(r2 * 10 + 2).toFixed(1) : 0;
    const capDraw = r2 < 0.15 ? -+(r3 * 8 + 2).toFixed(1) : 0;
    const contrib = r3 < 0.26 ? -+(r4 * 6 + 1).toFixed(1) : 0;
    const distrib = r4 < 0.30 ? +(r1 * 6 + 1).toFixed(1) : 0;
    return { capCall, capDraw, contrib, distrib };
  }

  // Look up cashflows for (vehicle, monthKey) — prefers seeded VEHICLE_SERIES,
  // falls back to synthetic. Returns canonical {contribution, distribution,
  // capital_call, capital_drawdown} (all non-negative magnitudes).
  function _cashflowForMonth(ids, monthKey, monthIdx) {
    let contribution = 0, distribution = 0, capital_call = 0, capital_drawdown = 0;
    ids.forEach(id => {
      const series = VEHICLE_SERIES[id] || [];
      const hit = series.find(r => r.month === monthKey);
      let row = hit;
      if (!row) row = _syntheticCashflow(id, monthIdx);
      contribution     += Math.abs(row.contrib || 0);
      distribution     += (row.distrib || 0);
      capital_call     += (row.capCall || 0);
      capital_drawdown += Math.abs(row.capDraw || 0);
    });
    return { contribution, distribution, capital_call, capital_drawdown };
  }

  // J-curve life-cycle envelope applied to non-cash assets during the
  // projection. Models the typical private-market portfolio: value rises as
  // investments mature, peaks around mid-horizon, then declines towards zero
  // as the portfolio is wound down.
  // Envelope E(t) with t = monthIdx / totalMonths:
  //   E(t) = (1 + 1.5·sin(π·t)) · (1 − 0.9·t²)
  //   → E(0) = 1           (start at current NAV)
  //   → E(0.5) ≈ 1.94       (peak ~2x around mid-horizon)
  //   → E(1) = 0.1          (ends at ~10% of initial, near "everything gone")
  // Note: this is an intentional UI overlay on top of spec §3.1.2 ("0% growth
  // on non-cash"). The spec's flat-growth rule is preserved inside
  // rebalancing/compliance logic (it's applied BEFORE cashflows + rebalancing),
  // but the envelope below produces the mountain-shape trajectory that the
  // product team asked for so users can see realistic portfolio life-cycles.
  function _jCurveEnvelope(t) {
    const clamped = Math.max(0, Math.min(1, t));
    const bell = 1 + 1.5 * Math.sin(Math.PI * clamped);
    const decay = 1 - 0.9 * clamped * clamped;
    return Math.max(0.05, bell * decay);
  }
  function _jCurveGrowthFactor(monthIdx, totalMonths) {
    if (totalMonths <= 1) return 1;
    const e0 = _jCurveEnvelope(monthIdx / totalMonths);
    const e1 = _jCurveEnvelope((monthIdx + 1) / totalMonths);
    return e0 > 0.001 ? (e1 / e0) : 1;
  }

  // Portfolio valuation projection (checklist §3.1.2).
  // Inputs: vehicleId, start/end ISO, strategy (from getStrategyByVehicleId).
  // Output: [{ period, start_value, net_cashflow, rebalancing_occurred,
  //            end_value, cash_balance, asset_allocation_pct, asset_allocation_value,
  //            cashflows:{...}, drift_pct, compliance }]
  function projectPortfolioValue(vehicleId, startIso, endIso, strategy) {
    const ids = [vehicleId, ...descendantVehicles(vehicleId).map(v => v.id)];
    const comp = calculateVehicleComposition(vehicleId);
    const startDate = startIso ? new Date(startIso) : new Date();
    const endDate   = endIso   ? new Date(endIso)   : _addMonths(startDate, 120);
    // Count months inclusive
    const months = [];
    let d = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
    const endMonthKey = _monthKey(endDate);
    while (_monthKey(d) <= endMonthKey) {
      months.push(new Date(d));
      d = _addMonths(d, 1);
    }

    // Initial state
    let curValueByType = { ...comp.valueBySpecType };
    let portfolioValue = comp.totalValue;
    // Cash balance tracks the cash bucket directly.
    let cashBalance = curValueByType.cash || 0;

    // Strategy parameters
    const target = strategy && strategy.rebalancing_target_allocation || null;
    const trigger = strategy ? strategy.rebalancing_trigger : "none";
    const tolerancePct = strategy ? (strategy.rebalancing_tolerance_pct || 5) : 5;
    const minCashPct = strategy ? (strategy.min_cash_reserve_pct || 0) : 0;
    // Annual rebalancing anchor: January by default; spec allows apply-on-date
    // but we don't store that in the canonical model — use January.
    const rebalMonth = 0; // January

    const periods = [];
    const rebalancingEvents = [];
    let lastRebalanceIdx = -999;

    months.forEach((dt, i) => {
      const mk = _monthKey(dt);
      const startValue = portfolioValue;
      const cf = _cashflowForMonth(ids, mk, i);
      const netCf = cf.capital_call + cf.distribution - cf.contribution - cf.capital_drawdown;

      // Apply cashflow to cash bucket (cash absorbs net flow).
      curValueByType = { ...curValueByType };
      curValueByType.cash = (curValueByType.cash || 0) + netCf;
      cashBalance = curValueByType.cash;

      // J-curve life-cycle envelope on non-cash assets (see _jCurveEnvelope).
      // Produces mountain-shape trajectory: rising mid-horizon, declining
      // toward zero at end. Cash is preserved as an accumulator.
      const growth = _jCurveGrowthFactor(i, months.length);
      if (growth !== 1) {
        SPEC_ASSET_TYPES.forEach(t => {
          if (t !== "cash") {
            curValueByType[t] = +((curValueByType[t] || 0) * growth).toFixed(4);
          }
        });
      }

      // Recompute total
      portfolioValue = SPEC_ASSET_TYPES.reduce((s, t) => s + (curValueByType[t] || 0), 0);

      // Check rebalancing
      let rebalanced = false;
      let driftPct = 0;
      let changes = null;
      if (target && portfolioValue > 0) {
        // Max absolute drift across any asset type
        const maxDrift = SPEC_ASSET_TYPES.reduce((mx, t) => {
          const actual = portfolioValue > 0 ? (curValueByType[t] || 0) / portfolioValue : 0;
          const tgt = (target[t] || 0) / 100;
          const d = Math.abs(actual - tgt);
          return d > mx ? d : mx;
        }, 0);
        driftPct = +(maxDrift * 100).toFixed(2);

        const monthsSinceRebal = i - lastRebalanceIdx;
        let shouldRebal = false;
        if (trigger === "fixed") {
          // Annual on January
          shouldRebal = (dt.getMonth() === rebalMonth) && monthsSinceRebal >= 12;
        } else if (trigger === "tolerance") {
          shouldRebal = maxDrift * 100 > tolerancePct && monthsSinceRebal >= 1;
        } else if (trigger === "min_cash") {
          // Rebalance when cash falls below min_cash target
          const cashPct = portfolioValue > 0 ? (curValueByType.cash || 0) / portfolioValue * 100 : 0;
          shouldRebal = cashPct < minCashPct && monthsSinceRebal >= 1;
        }

        if (shouldRebal) {
          const prev = { ...curValueByType };
          const newBy = {};
          SPEC_ASSET_TYPES.forEach(t => {
            newBy[t] = portfolioValue * ((target[t] || 0) / 100);
          });
          changes = SPEC_ASSET_TYPES.map(t => {
            const fromPct = portfolioValue > 0 ? (prev[t] || 0) / portfolioValue * 100 : 0;
            const toPct   = target[t] || 0;
            return { assetType: t, fromPct: +fromPct.toFixed(1), toPct: +toPct.toFixed(1), delta: +(toPct - fromPct).toFixed(1) };
          }).filter(c => Math.abs(c.delta) >= 0.1);
          curValueByType = newBy;
          cashBalance = newBy.cash || 0;
          rebalanced = true;
          lastRebalanceIdx = i;
          rebalancingEvents.push({
            period: mk, date: dt.toISOString().slice(0, 10), driftPct,
            changes
          });
        }
      }

      // Allocation snapshot
      const allocationPct = {};
      const allocationValue = {};
      SPEC_ASSET_TYPES.forEach(t => {
        allocationValue[t] = +(curValueByType[t] || 0).toFixed(2);
        allocationPct[t]   = portfolioValue > 0 ? +((curValueByType[t] || 0) / portfolioValue * 100).toFixed(2) : 0;
      });

      // Compliance check: any type within ±tolerance of target?
      let compliance = "On target";
      if (target && portfolioValue > 0) {
        compliance = driftPct <= tolerancePct ? "On target" : ("Off target by " + driftPct.toFixed(1) + "%");
      }

      periods.push({
        period: mk,
        date: dt.toISOString().slice(0, 10),
        start_value: +startValue.toFixed(2),
        cashflow: { ...cf, net: +netCf.toFixed(2) },
        net_cashflow: +netCf.toFixed(2),
        rebalancing_occurred: rebalanced,
        rebalancing_changes: changes,
        end_value: +portfolioValue.toFixed(2),
        cash_balance: +cashBalance.toFixed(2),
        asset_allocation_pct: allocationPct,
        asset_allocation_value: allocationValue,
        drift_pct: driftPct,
        compliance
      });
    });

    return { periods, rebalancingEvents };
  }

  // ---------- Annual aggregation helpers ----------
  // All forecast/simulation UIs now display annual-only data. The underlying
  // monthly engine is preserved (rebalancing triggers and J-curve envelope
  // need month-granularity), but the periods exposed to the UI are rolled up
  // to a single entry per calendar year.

  function _annualizePeriods(monthly, isSim) {
    if (!monthly || !monthly.length) return [];
    const byYear = {};
    const order = [];
    monthly.forEach(p => {
      const y = (p.period || "").slice(0, 4);
      if (!byYear[y]) { byYear[y] = []; order.push(y); }
      byYear[y].push(p);
    });
    return order.map(y => {
      const ms = byYear[y];
      const first = ms[0], last = ms[ms.length - 1];
      let contrib = 0, distrib = 0, capCall = 0, capDraw = 0, netCf = 0;
      ms.forEach(m => {
        contrib += (m.cashflow && m.cashflow.contribution) || 0;
        distrib += (m.cashflow && m.cashflow.distribution) || 0;
        capCall += (m.cashflow && m.cashflow.capital_call) || 0;
        capDraw += (m.cashflow && m.cashflow.capital_drawdown) || 0;
        netCf   += m.net_cashflow || 0;
      });
      const rebMonth = ms.find(m => m.rebalancing_occurred);
      const out = {
        period: y,
        date: y + "-12-31",
        start_value: first.start_value,
        end_value:   last.end_value,
        cash_balance: last.cash_balance,
        net_cashflow: +netCf.toFixed(2),
        cashflow: {
          contribution:     +contrib.toFixed(2),
          distribution:     +distrib.toFixed(2),
          capital_call:     +capCall.toFixed(2),
          capital_drawdown: +capDraw.toFixed(2),
          net:              +netCf.toFixed(2)
        },
        rebalancing_occurred: !!rebMonth,
        rebalancing_changes:  rebMonth ? rebMonth.rebalancing_changes : null,
        asset_allocation_pct:   last.asset_allocation_pct,
        asset_allocation_value: last.asset_allocation_value,
        drift_pct:  last.drift_pct,
        compliance: last.compliance
      };
      if (isSim) {
        out.value_percentiles = last.value_percentiles;
        out.cash_percentiles  = last.cash_percentiles;
        out.mean_value = last.mean_value;
        out.mean_cash  = last.mean_cash;
      }
      return out;
    });
  }

  function _annualizeFlowRows(rows) {
    if (!rows || !rows.length) return [];
    const byYear = {};
    const order = [];
    rows.forEach(r => {
      const y = (r.period || "").slice(0, 4);
      if (!byYear[y]) { byYear[y] = []; order.push(y); }
      byYear[y].push(r);
    });
    return order.map(y => {
      const rs = byYear[y];
      return {
        period: y, date: y + "-12-31",
        contribution:     +rs.reduce((s, r) => s + (r.contribution || 0), 0).toFixed(2),
        distribution:     +rs.reduce((s, r) => s + (r.distribution || 0), 0).toFixed(2),
        capital_call:     +rs.reduce((s, r) => s + (r.capital_call || 0), 0).toFixed(2),
        capital_drawdown: +rs.reduce((s, r) => s + (r.capital_drawdown || 0), 0).toFixed(2)
      };
    });
  }

  // Top-level immediate forecast (checklist §3.1.3). Bundles periods + summary
  // + parent/child relationship flows so the UI can render everything.
  function projectLiquidityForecast(vehicleId, opts) {
    opts = opts || {};
    const startIso = opts.startDate || new Date().toISOString().slice(0, 10);
    const endIso   = opts.endDate   || _addMonths(new Date(startIso), 120).toISOString().slice(0, 10);
    const strategy = getStrategyByVehicleId(vehicleId);
    const initialComp = calculateVehicleComposition(vehicleId);
    const { periods: monthlyPeriods, rebalancingEvents } = projectPortfolioValue(vehicleId, startIso, endIso, strategy);
    // Annual-only UX: aggregate monthly internals into calendar-year periods.
    const periods = _annualizePeriods(monthlyPeriods, false);

    // Summary KPIs — computed on annualized periods so the UI matches.
    const first = periods[0] || null;
    const last  = periods[periods.length - 1] || null;
    let minCash = Infinity, minCashPeriod = null;
    let maxCash = -Infinity;
    let totalContrib = 0, totalDistrib = 0, totalCapCall = 0, totalCapDraw = 0;
    periods.forEach(p => {
      if (p.cash_balance < minCash) { minCash = p.cash_balance; minCashPeriod = p.period; }
      if (p.cash_balance > maxCash) maxCash = p.cash_balance;
      totalContrib += p.cashflow.contribution;
      totalDistrib += p.cashflow.distribution;
      totalCapCall += p.cashflow.capital_call;
      totalCapDraw += p.cashflow.capital_drawdown;
    });

    const minCashTarget = strategy && strategy.min_cash_reserve_pct
      ? initialComp.totalValue * strategy.min_cash_reserve_pct / 100
      : 0;

    // Parent / children breakdown (§3.2.10)
    const parentId = getParentVehicleId(vehicleId);
    const children = getChildVehicles(vehicleId);
    const relationships = {
      parent: null,
      children: []
    };
    if (parentId && !String(parentId).startsWith("CL-")) {
      const p = vehicleById(parentId);
      // Vehicle's flows TO parent = contributions out + capital_drawdown out
      // Vehicle's flows FROM parent = capital_call in
      let callsMade = 0, drawdownsReceived = 0;
      const periodFlows = periods.map(pd => {
        callsMade       += pd.cashflow.capital_drawdown; // outgoing to parent
        drawdownsReceived += pd.cashflow.capital_call;   // incoming from parent
        return {
          period: pd.period,
          date: pd.date,
          contribution:      +pd.cashflow.contribution.toFixed(2),
          distribution:      +pd.cashflow.distribution.toFixed(2),
          capital_call:      +pd.cashflow.capital_call.toFixed(2),
          capital_drawdown:  +pd.cashflow.capital_drawdown.toFixed(2)
        };
      });
      relationships.parent = {
        id: p && p.id, name: p ? p.name : parentId,
        capitalCallsMadeToParent: +callsMade.toFixed(2),
        capitalDrawdownsReceivedFromParent: +drawdownsReceived.toFixed(2),
        periods: periodFlows
      };
    }
    children.forEach(c => {
      // Project child cashflows quickly — reuse projectCashflows with same window.
      const cf = projectCashflows(c.id, startIso, endIso);
      const t = cf.reduce((s, r) => ({
        contrib: s.contrib + r.contribution,
        distrib: s.distrib + r.distribution,
        capCall: s.capCall + r.capital_call,
        capDraw: s.capDraw + r.capital_drawdown
      }), { contrib: 0, distrib: 0, capCall: 0, capDraw: 0 });
      relationships.children.push({
        id: c.id, name: c.name,
        contributionsReceived: +t.contrib.toFixed(2),
        distributionsSent:     +t.distrib.toFixed(2),
        capitalCallsMade:      +t.capCall.toFixed(2),
        capitalDrawdownsSent:  +t.capDraw.toFixed(2),
        periods: _annualizeFlowRows(cf)
      });
    });

    const summary = {
      currentPortfolioValue: initialComp.totalValue,
      currentCashBalance:    initialComp.valueBySpecType.cash || 0,
      endOfPeriodValue:      last ? last.end_value : 0,
      minCashDuringPeriod:   isFinite(minCash) ? minCash : 0,
      minCashPeriod,
      maxCashDuringPeriod:   isFinite(maxCash) ? maxCash : 0,
      minCashTarget,
      rebalancingEventCount: rebalancingEvents.length,
      complianceStatus:      last ? last.compliance : "On target",
      totalContributions:    +totalContrib.toFixed(2),
      totalDistributions:    +totalDistrib.toFixed(2),
      totalCapitalCalls:     +totalCapCall.toFixed(2),
      totalCapitalDrawdowns: +totalCapDraw.toFixed(2),
      insolvencyPeriods:     periods.filter(p => p.cash_balance < 0).length
    };

    return {
      generated_at: new Date().toISOString(),
      request_params: { vehicleId, startDate: startIso, endDate: endIso, currency: opts.currency || "USD", stress_test_id: opts.stressTestId || null },
      vehicleId,
      vehicleName: (vehicleById(vehicleId) || {}).name || vehicleId,
      strategy: strategy ? { id: strategy.id, name: strategy.name, is_preset: strategy.is_preset } : null,
      periods,
      rebalancingEvents,
      summary,
      relationships
    };
  }

  // --- Phase 4: Monte Carlo Simulation (checklist §4.1, §4.2) ---
  //
  // Frontend-only prototype: rather than running N stochastic iterations (which
  // would be browser-impractical at 50K and is not the deliverable here), we
  // synthesize percentile bands by expanding uncertainty around the Phase 3
  // deterministic path. σ grows with period index (compounding uncertainty)
  // and percentiles are computed as mean ± z(p)·σ, so P5 < P10 < … < P95 is
  // guaranteed by construction. A real backend would replace `_expandBand`
  // with proper Monte Carlo sampling; the return shape is identical.

  const PCTILES = [
    { key: "P5",  z: -1.645, label: "P5"  },
    { key: "P10", z: -1.282, label: "P10" },
    { key: "P25", z: -0.674, label: "P25" },
    { key: "P50", z:  0,     label: "P50" },
    { key: "P75", z:  0.674, label: "P75" },
    { key: "P90", z:  1.282, label: "P90" },
    { key: "P95", z:  1.645, label: "P95" }
  ];

  // σ scales with √t (standard finance assumption: variance ∝ time). The
  // `stressMult` multiplies total uncertainty — baseline = 1.0, stress test
  // can bump this to 1.3–1.8 to widen the fan.
  function _sigmaAtMonth(i, horizonMonths, baseValue, stressMult) {
    const t = horizonMonths > 0 ? i / horizonMonths : 0;
    const annualVol = 0.18 * (stressMult || 1); // 18% annual volatility baseline
    return Math.abs(baseValue) * annualVol * Math.sqrt(Math.max(t, 0.05));
  }

  function _expandBand(meanValue, sigma) {
    const out = {};
    PCTILES.forEach(p => { out[p.key] = +(meanValue + p.z * sigma).toFixed(2); });
    return out;
  }

  // Stress mapping — each stress test widens / biases the distribution.
  const _STRESS_MAP = {
    "rate-shock":       { sigmaMult: 1.35, valueBias: -0.08, cashBias: -0.04 },
    "recession-mild":   { sigmaMult: 1.45, valueBias: -0.12, cashBias: -0.06 },
    "recession-deep":   { sigmaMult: 1.75, valueBias: -0.22, cashBias: -0.15 },
    "tech-rerate":      { sigmaMult: 1.30, valueBias: -0.10, cashBias: -0.03 },
    "fx-usd-strength":  { sigmaMult: 1.15, valueBias: -0.05, cashBias: -0.02 },
    "illiquidity":      { sigmaMult: 1.55, valueBias: -0.07, cashBias: -0.18 }
  };

  // Top-level simulation (§4.1). Inputs map to the simulation config modal.
  function projectSimulation(vehicleId, opts) {
    opts = opts || {};
    const startIso = opts.startDate || new Date().toISOString().slice(0, 10);
    const endIso   = opts.endDate   || _addMonths(new Date(startIso), 120).toISOString().slice(0, 10);
    const depth    = opts.depth || "full";
    const iterations = depth === "fast" ? 1000 : 50000;
    const strategy = getStrategyByVehicleId(vehicleId);
    const initialComp = calculateVehicleComposition(vehicleId);
    const stressCfg = opts.stressTestId ? (_STRESS_MAP[opts.stressTestId] || { sigmaMult: 1, valueBias: 0, cashBias: 0 }) : { sigmaMult: 1, valueBias: 0, cashBias: 0 };

    // Mean path reuses the Phase 3 projection (monthly internals).
    const { periods: monthlyPeriods, rebalancingEvents } = projectPortfolioValue(vehicleId, startIso, endIso, strategy);
    const horizonMonths = monthlyPeriods.length;

    // Expand bands around mean per month. Stress bias drifts the mean down.
    const enrichedMonthly = monthlyPeriods.map((p, i) => {
      const valueSigma = _sigmaAtMonth(i, horizonMonths, p.end_value, stressCfg.sigmaMult);
      const cashSigma  = _sigmaAtMonth(i, horizonMonths, Math.max(Math.abs(p.cash_balance), initialComp.totalValue * 0.05), stressCfg.sigmaMult * 1.15);
      const biasedValue = p.end_value * (1 + stressCfg.valueBias * (i / Math.max(horizonMonths, 1)));
      const biasedCash  = p.cash_balance + (initialComp.totalValue * stressCfg.cashBias * (i / Math.max(horizonMonths, 1)));
      return {
        ...p,
        value_percentiles: _expandBand(biasedValue, valueSigma),
        cash_percentiles:  _expandBand(biasedCash, cashSigma),
        mean_value: +biasedValue.toFixed(2),
        mean_cash:  +biasedCash.toFixed(2)
      };
    });
    // Annual-only UX: roll up enriched months into calendar-year periods.
    const enriched = _annualizePeriods(enrichedMonthly, true);

    // Per-percentile scenario traces (for Scenario Explorer §4.3.9).
    // Each is a deterministic single path derived by offsetting the mean by z·σ.
    const scenarios = {};
    PCTILES.forEach(p => {
      const trace = enriched.map((pd, i) => ({
        period: pd.period,
        date: pd.date,
        value: pd.value_percentiles[p.key],
        cash:  pd.cash_percentiles[p.key],
        asset_allocation_pct: pd.asset_allocation_pct,   // allocation stays on mean path
        rebalancing_occurred: pd.rebalancing_occurred,   // rebal from mean path
        cashflow: pd.cashflow
      }));
      const minCash = trace.reduce((m, r) => Math.min(m, r.cash), Infinity);
      const maxCash = trace.reduce((m, r) => Math.max(m, r.cash), -Infinity);
      const endValue = trace[trace.length - 1] ? trace[trace.length - 1].value : 0;
      scenarios[p.key] = {
        percentile: p.key, trace,
        minCash: isFinite(minCash) ? +minCash.toFixed(2) : 0,
        maxCash: isFinite(maxCash) ? +maxCash.toFixed(2) : 0,
        endValue: +endValue.toFixed(2)
      };
    });

    // Rebalancing count by percentile — higher uncertainty → more drift → more rebals.
    // Scale the mean-path count by percentile-specific multipliers.
    const baseCount = rebalancingEvents.length;
    const REB_MULT = { P5: 1.80, P10: 1.55, P25: 1.25, P50: 1.00, P75: 0.80, P90: 0.60, P95: 0.45 };
    const rebalancingByPercentile = {};
    PCTILES.forEach(p => {
      rebalancingByPercentile[p.key] = Math.round(baseCount * (REB_MULT[p.key] || 1) * stressCfg.sigmaMult);
    });

    // Risk metrics (§4.2).
    const riskMetrics = _computeRiskMetrics(enriched, strategy, rebalancingByPercentile, initialComp.totalValue);

    // Comparison table rows (§4.3.8).
    const comparisonTable = PCTILES.map(p => {
      const sc = scenarios[p.key];
      const allConstraintsMet = sc.minCash >= 0; // simplified: no insolvency = constraints met
      return {
        percentile: p.key,
        endValue: sc.endValue,
        minCash:  sc.minCash,
        maxCash:  sc.maxCash,
        rebalancingCount: rebalancingByPercentile[p.key],
        strategyCompliant: allConstraintsMet
      };
    });

    // Parent / children (same shape as Phase 3 — cashflows stay on the mean
    // path; the percentile selector in the UI does NOT re-scale inter-vehicle
    // cashflows since those come from external commitments / schedules).
    const parentId = getParentVehicleId(vehicleId);
    const children = getChildVehicles(vehicleId);
    const relationships = { parent: null, children: [] };
    if (parentId && !String(parentId).startsWith("CL-")) {
      const pv = vehicleById(parentId);
      let callsMade = 0, drawdownsReceived = 0;
      const periodFlows = enriched.map(pd => {
        callsMade         += pd.cashflow.capital_drawdown;
        drawdownsReceived += pd.cashflow.capital_call;
        return {
          period: pd.period, date: pd.date,
          contribution:     +pd.cashflow.contribution.toFixed(2),
          distribution:     +pd.cashflow.distribution.toFixed(2),
          capital_call:     +pd.cashflow.capital_call.toFixed(2),
          capital_drawdown: +pd.cashflow.capital_drawdown.toFixed(2)
        };
      });
      relationships.parent = {
        id: pv && pv.id, name: pv ? pv.name : parentId,
        capitalCallsMadeToParent: +callsMade.toFixed(2),
        capitalDrawdownsReceivedFromParent: +drawdownsReceived.toFixed(2),
        periods: periodFlows
      };
    }
    children.forEach(c => {
      const cf = projectCashflows(c.id, startIso, endIso);
      const t = cf.reduce((s, r) => ({
        contrib: s.contrib + r.contribution,
        distrib: s.distrib + r.distribution,
        capCall: s.capCall + r.capital_call,
        capDraw: s.capDraw + r.capital_drawdown
      }), { contrib: 0, distrib: 0, capCall: 0, capDraw: 0 });
      relationships.children.push({
        id: c.id, name: c.name,
        contributionsReceived: +t.contrib.toFixed(2),
        distributionsSent:     +t.distrib.toFixed(2),
        capitalCallsMade:      +t.capCall.toFixed(2),
        capitalDrawdownsSent:  +t.capDraw.toFixed(2),
        periods: _annualizeFlowRows(cf)
      });
    });

    return {
      id: "SIM-" + Date.now(),
      generated_at: new Date().toISOString(),
      request_params: {
        vehicleId, startDate: startIso, endDate: endIso,
        currency: opts.currency || "USD",
        stress_test_id: opts.stressTestId || null,
        depth, iterations,
        simulation_name: opts.simulationName || "Untitled simulation",
        fine_tuning: !!opts.fineTuning
      },
      vehicleId,
      vehicleName: (vehicleById(vehicleId) || {}).name || vehicleId,
      strategy: strategy ? { id: strategy.id, name: strategy.name, is_preset: strategy.is_preset } : null,
      periods: enriched,
      rebalancingByPercentile,
      scenarios,
      comparisonTable,
      riskMetrics,
      relationships,
      initialTotalValue: initialComp.totalValue
    };
  }

  // Risk metrics (§4.2).
  function _computeRiskMetrics(enriched, strategy, rebalancingByPercentile, totalValue) {
    // 4.2.1 — Insolvency: % of percentile scenarios that go negative at any point.
    // In our synthesized model, a percentile p is "insolvent" if any period's
    // cash_percentiles[p] < 0.
    const insolventPctiles = PCTILES.filter(p =>
      enriched.some(pd => pd.cash_percentiles[p.key] < 0)
    );
    const insolvencyPct = (insolventPctiles.length / PCTILES.length) * 100;
    const criticalDates = [];
    enriched.forEach(pd => {
      if (pd.cash_percentiles.P5 < 0) {
        criticalDates.push({ date: pd.date, P5_value: pd.cash_percentiles.P5, P10_value: pd.cash_percentiles.P10 });
      }
    });

    // 4.2.2 — Excess cash: % of scenarios where cash > 50% of total at end of period.
    const excessThreshold = (totalValue > 0 ? totalValue : 100) * 0.5;
    const excessPctiles = PCTILES.filter(p =>
      enriched.some(pd => pd.cash_percentiles[p.key] > excessThreshold)
    );
    const excessPct = (excessPctiles.length / PCTILES.length) * 100;
    const avgExcess = excessPctiles.length > 0
      ? excessPctiles.reduce((s, p) => {
          const maxInPctile = enriched.reduce((mx, pd) => Math.max(mx, pd.cash_percentiles[p.key]), 0);
          return s + Math.max(0, maxInPctile - excessThreshold);
        }, 0) / excessPctiles.length
      : 0;

    // 4.2.3 — Rebalancing frequency analyzer. `enriched` is annualized
    // (one entry per calendar year), so the span is simply its length.
    const yearsSpan = Math.max(1, enriched.length);
    const counts = Object.values(rebalancingByPercentile);
    const rebMin = Math.min(...counts);
    const rebMax = Math.max(...counts);
    const rebAvg = counts.reduce((s, v) => s + v, 0) / counts.length;
    const rebalFreq = {
      avgPerYear: +(rebAvg / yearsSpan).toFixed(1),
      range: { min: rebMin, max: rebMax },
      byPercentile: rebalancingByPercentile
    };

    // 4.2.4 — Cash reserve adequacy: % of time the median (P50) meets target.
    const target = (strategy && strategy.min_cash_reserve_pct ? strategy.min_cash_reserve_pct : 0) / 100 * totalValue;
    const adequatePeriods = enriched.filter(pd => pd.cash_percentiles.P50 >= target).length;
    const adequatePct = enriched.length > 0 ? (adequatePeriods / enriched.length) * 100 : 0;

    // 4.2.5 — Strategy feasibility: % of percentile scenarios meeting all constraints.
    // Simplified prototype rule: feasible iff scenario never goes insolvent AND doesn't blow past excess threshold.
    const feasiblePctiles = PCTILES.filter(p =>
      enriched.every(pd => pd.cash_percentiles[p.key] >= 0 && pd.cash_percentiles[p.key] <= excessThreshold * 1.5)
    );
    const feasiblePct = (feasiblePctiles.length / PCTILES.length) * 100;

    return {
      insolvencyRisk: {
        riskPercentage: +insolvencyPct.toFixed(1),
        scenariosAffected: insolventPctiles.length,
        totalScenarios: PCTILES.length,
        criticalDates: criticalDates.slice(0, 5)
      },
      excessCashRisk: {
        riskPercentage: +excessPct.toFixed(1),
        scenariosAffected: excessPctiles.length,
        totalScenarios: PCTILES.length,
        averageExcess: +avgExcess.toFixed(2)
      },
      rebalancingFrequency: rebalFreq,
      cashReserveAdequacy: {
        percentOfTimeAdequate: +adequatePct.toFixed(1),
        scenariosFailing: enriched.length - adequatePeriods,
        targetValue: +target.toFixed(2),
        suggestion: adequatePct < 80 ? "Consider raising the minimum cash reserve target." : "Cash reserve is adequate in most periods."
      },
      strategyFeasibility: {
        feasiblePercentage: +feasiblePct.toFixed(1),
        scenariosFailing: PCTILES.length - feasiblePctiles.length,
        constraintViolations: insolventPctiles.length > 0
          ? [{ constraint: "Non-negative cash balance", scenariosAffected: insolventPctiles.length }]
          : []
      }
    };
  }

  // Individual risk-metric exports (checklist §4.2) — thin wrappers around the
  // aggregated calculator so callers can compose them independently.
  function calculateInsolvencyRisk(periods) {
    return _computeRiskMetrics(periods, null, {}, 100).insolvencyRisk;
  }
  function calculateExcessCashRisk(periods, threshold) {
    const m = _computeRiskMetrics(periods, null, {}, threshold || 100);
    return m.excessCashRisk;
  }
  function analyzeRebalancingFrequency(rebalancingByPercentile, periodsCount) {
    const counts = Object.values(rebalancingByPercentile);
    const yearsSpan = Math.max(1, (periodsCount || 120) / 12);
    return {
      avgPerYear: +(counts.reduce((s, v) => s + v, 0) / counts.length / yearsSpan).toFixed(1),
      range: { min: Math.min(...counts), max: Math.max(...counts) },
      byPercentile: rebalancingByPercentile
    };
  }
  function analyzeCashReserveAdequacy(periods, targetValue) {
    const hits = periods.filter(p => p.cash_percentiles && p.cash_percentiles.P50 >= targetValue).length;
    return {
      percentOfTimeAdequate: +(hits / periods.length * 100).toFixed(1),
      scenariosFailing: periods.length - hits,
      targetValue
    };
  }
  function checkStrategyFeasibility(periods) {
    const feasible = PCTILES.filter(p => periods.every(pd => pd.cash_percentiles[p.key] >= 0));
    return {
      feasiblePercentage: +(feasible.length / PCTILES.length * 100).toFixed(1),
      scenariosFailing: PCTILES.length - feasible.length
    };
  }

  window.PI_DATA = {
    FUNDS, PORTFOLIOS, ARCHIVED_PORTFOLIOS, SIMULATIONS, STRESS_TESTS,
    VEHICLES, VEHICLE_TREE, CLIENTS,
    ASSET_TYPES, SPEC_ASSET_TYPES, SPEC_TO_INTERNAL, INTERNAL_TO_SPEC,
    REALIZATIONS, VEHICLE_SERIES,
    MC_PARAMS, STRATEGY_PRESETS,
    buildCashflows,
    // Core tree helpers (back-compat)
    assetTypeMeta, vehicleById, childrenOf, assetsOfVehicle,
    descendantVehicles, aggregateVehicleValue,
    // Liquidity module repositories (checklist 1.1.4 / 1.1.5 / 1.4)
    getVehicleById, getVehiclesByPortfolioId, getVehicleHierarchy,
    createVehicle, updateVehicle, deleteVehicle,
    getAssetPositionsByVehicleId, createAssetPosition, updateAssetPosition, deleteAssetPosition,
    calculateVehicleComposition,
    getParentVehicleId, getChildVehicles, getVehicleAncestry,
    projectCashflows,
    // Phase 3 forecast engine (checklist §3.1)
    projectPortfolioValue, projectLiquidityForecast,
    // Phase 4 simulation engine (checklist §4.1 / §4.2)
    PCTILES, projectSimulation,
    calculateInsolvencyRisk, calculateExcessCashRisk,
    analyzeRebalancingFrequency, analyzeCashReserveAdequacy,
    checkStrategyFeasibility,
    // Strategy / constraint repositories (checklist §2)
    LIQUIDITY_STRATEGIES, ASSET_TYPE_CONSTRAINTS, VEHICLE_STRATEGY_ASSIGNMENTS,
    getPresetStrategies, getStrategyById, getStrategyByVehicleId,
    getConstraintsByStrategyId, getReusableStrategies,
    validateStrategy, createStrategy, updateStrategy, deleteStrategy,
    assignStrategyToVehicle, applyStrategyToVehicles,
  };
})();
