/* New-portfolio modal, simulations page, compare view, simulation-list modals */

function NewPortfolioModal({ onClose, onCreateFromUpload, onCreateFromExample, onDownloadTemplate, canClose = true }) {
  const fileInput = PI.useRef();
  const [drag, setDrag] = PI.useState(false);
  function pick(e) {
    const f = e.target.files?.[0];
    if (f) onCreateFromUpload(f.name.replace(/\.(xlsx|xls|csv)$/i, ""), f.name);
  }
  function onDrop(e) {
    e.preventDefault(); setDrag(false);
    const f = e.dataTransfer?.files?.[0];
    if (f) onCreateFromUpload(f.name.replace(/\.(xlsx|xls|csv)$/i, ""), f.name);
  }
  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: canClose ? onClose : undefined }),
    React.createElement("div", { className: "modal-wrap", onClick: canClose ? onClose : undefined },
      React.createElement("div", { className: "modal modal-lg", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" }, "New portfolio"),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 500 } }, "How would you like to start?")
          ),
          canClose && React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),
        React.createElement("div", { className: "modal-body" },
          React.createElement("div", { className: "upload-hero" },
            // Featured: Example portfolio
            React.createElement("div", { className: "upload-card is-featured" },
              React.createElement("div", { className: "upload-card-mark" },
                React.createElement(PI.Icon.Sparkles, { size: 22 })
              ),
              React.createElement("h3", null, "Try the Cepres Example Portfolio"),
              React.createElement("p", null,
                "22 funds across buyout, growth, venture, credit and infrastructure — pre-populated with look-through cash flows so you can explore the full platform immediately."),
              React.createElement("div", { className: "upload-hero-meta" },
                React.createElement("span", null, "22 funds"),
                React.createElement("span", { className: "dotsep" }, "·"),
                React.createElement("span", null, "$4.71B committed"),
                React.createElement("span", { className: "dotsep" }, "·"),
                React.createElement("span", null, "12,400 look-through deals")
              ),
              React.createElement("div", { className: "upload-card-actions" },
                React.createElement(PI.Btn, {
                  kind: "primary",
                  icon: React.createElement(PI.Icon.ArrowRight, { size: 13 }),
                  onClick: onCreateFromExample
                }, "Create example portfolio")
              )
            ),
            // Dropzone: upload
            React.createElement("div", {
              className: `upload-card is-dropzone${drag ? " is-hover" : ""}`,
              onClick: () => fileInput.current.click(),
              onDragOver: e => { e.preventDefault(); setDrag(true); },
              onDragLeave: () => setDrag(false),
              onDrop
            },
              React.createElement("div", { className: "upload-card-mark" },
                React.createElement(PI.Icon.Upload, { size: 22 })
              ),
              React.createElement("h3", null, "Upload your own portfolio"),
              React.createElement("p", null,
                "Drag & drop an Excel or CSV file here, or click to browse. We accept .xlsx, .xls and .csv up to 25 MB."),
              React.createElement("div", { className: "upload-hero-meta" },
                React.createElement("span", null, "Fund list"),
                React.createElement("span", { className: "dotsep" }, "·"),
                React.createElement("span", null, "Quarterly cash flows"),
                React.createElement("span", { className: "dotsep" }, "·"),
                React.createElement("span", null, "Auto-mapped fields")
              ),
              React.createElement("div", { className: "upload-card-actions" },
                React.createElement(PI.Btn, {
                  kind: "secondary", size: "sm",
                  icon: React.createElement(PI.Icon.Upload, { size: 13 }),
                  onClick: (e) => { e.stopPropagation(); fileInput.current.click(); }
                }, "Choose file"),
                React.createElement(PI.Btn, {
                  kind: "ghost", size: "sm",
                  icon: React.createElement(PI.Icon.Download, { size: 13 }),
                  onClick: (e) => { e.stopPropagation(); onDownloadTemplate(); }
                }, "Download template")
              ),
              React.createElement("input", { ref: fileInput, type: "file", accept: ".xlsx,.xls,.csv", style: { display: "none" }, onChange: pick })
            )
          ),
          !canClose && React.createElement("div", { className: "np-welcome", style: { marginTop: 18 } },
            React.createElement(PI.Icon.Info, { size: 14 }),
            React.createElement("span", null, "Welcome to Predictive Intelligence. Create your first portfolio to get started.")
          )
        )
      )
    )
  );
}

// ---------------- Price Goal Seek ----------------
function GoalSeekModal({ fund, kind, onClose, onAccept, onToast }) {
  const isPurchase = kind === "purchase";
  const [date, setDate] = PI.useState(isPurchase ? (fund.purchaseDate || "2026-06-30") : (fund.salesDate || "2028-06-30"));
  const [mode, setMode] = PI.useState("irr"); // irr | tvpi | custom
  const [irr, setIrr] = PI.useState(18); // stored as %, e.g. 18 = 18%
  const [tvpi, setTvpi] = PI.useState(1.8);
  const [custom, setCustom] = PI.useState(fund[isPurchase ? "purchasePrice" : "salesPrice"] || fund.nav * 1.1);
  const [result, setResult] = PI.useState(null); // null until user clicks Calculate

  // Reset the result whenever any input changes — forces user to re-calculate.
  PI.useEffect(() => { setResult(null); }, [date, mode, irr, tvpi, custom]);

  function calculate() {
    const base = fund.nav || fund.contributed || 100;
    let suggested, resultingIrr, resultingTvpi;
    if (mode === "irr") {
      const irrDecimal = irr / 100;
      const factor = isPurchase ? 1 / (1 + irrDecimal * 1.4) : (1 + irrDecimal * 1.4);
      suggested = +(base * factor).toFixed(2);
      resultingIrr = irrDecimal;
      resultingTvpi = isPurchase ? +(1 + irrDecimal * 3.8).toFixed(2) : +(1 + irrDecimal * 2.2).toFixed(2);
    } else if (mode === "tvpi") {
      const factor = isPurchase ? (1.4 / tvpi) : (tvpi / 1.4);
      suggested = +(base * factor).toFixed(2);
      resultingTvpi = tvpi;
      resultingIrr = +((tvpi - 1) / 4.2).toFixed(4);
    } else {
      suggested = +custom;
      resultingTvpi = isPurchase
        ? +((fund.distributed + fund.nav) / Math.max(custom, 0.01)).toFixed(2)
        : +((fund.distributed + custom) / Math.max(fund.contributed, 0.01)).toFixed(2);
      resultingIrr = +((resultingTvpi - 1) / 4.6).toFixed(4);
    }
    setResult({ suggested, resultingIrr, resultingTvpi });
  }

  const label = isPurchase ? "Purchase" : "Sales";
  const priceLabel = isPurchase ? "Max purchase price" : "Min sales price";
  const resultLabel = mode === "custom" ? (isPurchase ? "Custom purchase price" : "Custom sales price") : priceLabel;

  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: onClose }),
    React.createElement("div", { className: "modal-wrap", onClick: onClose },
      React.createElement("div", { className: "modal modal-lg", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" }, `${label} price · goal seek`),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 500 } }, fund.name)
          ),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),
        React.createElement("div", { className: "modal-body" },
          React.createElement("div", { className: "gs-grid" },
            // Inputs
            React.createElement("div", { className: "gs-inputs" },
              React.createElement(PI.Field, { label: `${label} date`, required: true, hint: "Required for all goal-seek paths" },
                React.createElement("input", {
                  className: "input", type: "date", value: date,
                  onChange: e => setDate(e.target.value)
                })
              ),
              React.createElement("div", { className: "gs-tabs" },
                ["irr", "tvpi", "custom"].map(m => React.createElement("button", {
                  key: m,
                  className: `gs-tab${mode === m ? " is-active" : ""}`,
                  onClick: () => setMode(m)
                },
                  React.createElement("div", { className: "gs-tab-lbl" },
                    m === "irr" ? "Target IRR" : m === "tvpi" ? "Target TVPI" : "Custom price"),
                  React.createElement("div", { className: "gs-tab-desc" },
                    m === "irr" ? `Solve for ${isPurchase ? "max" : "min"} price` :
                    m === "tvpi" ? `Solve for ${isPurchase ? "max" : "min"} price` :
                    "Show resulting IRR + TVPI"
                  )
                ))
              ),
              React.createElement("div", { className: "gs-input-area" },
                mode === "irr" && React.createElement(PI.Field, { label: "Desired IRR", hint: "e.g. enter 18 for 18%" },
                  React.createElement("div", { className: "input-addon" },
                    React.createElement("input", { className: "input", type: "number", step: 1, min: 0, max: 100, value: irr, onChange: e => setIrr(+e.target.value) }),
                    React.createElement("span", { className: "input-addon-right" }, "%"))
                ),
                mode === "tvpi" && React.createElement(PI.Field, { label: "Desired TVPI", hint: "Multiple of invested capital" },
                  React.createElement("div", { className: "input-addon" },
                    React.createElement("input", { className: "input", type: "number", step: 0.05, min: 0.1, value: tvpi, onChange: e => setTvpi(+e.target.value) }),
                    React.createElement("span", { className: "input-addon-right" }, "×"))
                ),
                mode === "custom" && React.createElement(PI.Field, { label: `Custom ${label.toLowerCase()} price`, hint: `In ${fund.currency} millions` },
                  React.createElement("div", { className: "input-addon" },
                    React.createElement("span", { className: "input-addon-left" }, { USD: "$", EUR: "€", GBP: "£" }[fund.currency] || "$"),
                    React.createElement("input", { className: "input", type: "number", step: 0.1, min: 0, value: custom, onChange: e => setCustom(+e.target.value) }),
                    React.createElement("span", { className: "input-addon-right" }, "M"))
                )
              )
            ),
            // Output
            React.createElement("div", { className: "gs-output" },
              React.createElement("div", { className: "gs-output-lbl" }, "Result"),
              result
                ? React.createElement("div", { className: "gs-result" },
                    React.createElement("div", { className: "gs-result-primary" },
                      React.createElement("div", { className: "gs-rp-lbl" }, resultLabel),
                      React.createElement("div", { className: "gs-rp-val num" },
                        PI.fmt.moneyPlain(result.suggested, fund.currency))
                    ),
                    React.createElement("div", { className: "gs-result-secondary" },
                      React.createElement("div", null,
                        React.createElement("div", { className: "gs-rs-lbl" }, "Resulting IRR"),
                        React.createElement("div", { className: "gs-rs-val num" }, PI.fmt.pct(result.resultingIrr, 1))),
                      React.createElement("div", null,
                        React.createElement("div", { className: "gs-rs-lbl" }, "Resulting TVPI"),
                        React.createElement("div", { className: "gs-rs-val num" }, PI.fmt.mult(result.resultingTvpi))),
                      React.createElement("div", null,
                        React.createElement("div", { className: "gs-rs-lbl" }, label + " date"),
                        React.createElement("div", { className: "gs-rs-val num" }, date))
                    ),
                    React.createElement("div", { className: "gs-result-note" },
                      React.createElement(PI.Icon.Info, { size: 12 }),
                      "Calculated against ", fund.name, "'s cash-flow schedule. Change any input above and click Calculate to refresh."
                    )
                  )
                : React.createElement("div", { className: "gs-result gs-result-empty" },
                    React.createElement(PI.Icon.Microscope, { size: 28 }),
                    React.createElement("div", { className: "gs-result-empty-title" }, "No calculation yet"),
                    React.createElement("div", { className: "gs-result-empty-sub" },
                      "Adjust the inputs, then click ", React.createElement("strong", null, "Calculate"),
                      " to see the suggested price.")
                  )
            )
          )
        ),
        React.createElement("footer", { className: "modal-foot" },
          React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Keep original price"),
          React.createElement(PI.Btn, {
            kind: "ghost",
            icon: React.createElement(PI.Icon.Microscope, { size: 14 }),
            onClick: calculate
          }, result ? "Re-calculate" : "Calculate"),
          React.createElement(PI.Btn, {
            kind: "primary",
            icon: React.createElement(PI.Icon.Check, { size: 13 }),
            disabled: !result,
            onClick: () => {
              if (!result) return;
              onAccept({ price: result.suggested, date });
              onToast && onToast(`${label} price updated to ${PI.fmt.moneyPlain(result.suggested, fund.currency)}`, "ok");
            }
          }, `Accept ${label.toLowerCase()} price`)
        )
      )
    )
  );
}

// ---------------- Reusable column-header filter dropdown ----------------
function ColumnFilter({ label, value, options, onChange }) {
  const [open, setOpen] = PI.useState(false);
  const ref = PI.useClickOutside(() => setOpen(false));
  const active = value !== "all" && value !== undefined && value !== null;
  const selected = options.find(o => o.value === value);
  return React.createElement("div", { ref, className: "col-filter" },
    React.createElement("button", {
      className: `col-filter-trigger${active ? " is-active" : ""}`,
      onClick: (e) => { e.stopPropagation(); setOpen(o => !o); }
    },
      React.createElement("span", null, active && selected ? selected.label : label),
      React.createElement(PI.Icon.Filter, { size: 11 })
    ),
    open && React.createElement("div", { className: "col-filter-menu" },
      options.map(o => React.createElement("button", {
        key: o.value,
        className: `col-filter-item${o.value === value ? " is-selected" : ""}`,
        onClick: (e) => { e.stopPropagation(); onChange(o.value); setOpen(false); }
      },
        React.createElement("span", null, o.label),
        o.value === value && React.createElement(PI.Icon.Check, { size: 12 })
      ))
    )
  );
}
window.PI.ColumnFilter = ColumnFilter;

// ---------------- Simulations page ----------------
function SimulationsPage({ simulations, portfolios, onOpen, onCompare, onNewSim, onPickPortfolio, onToast, initialPortfolioFilter }) {
  const [search, setSearch] = PI.useState("");
  const [compareMode, setCompareMode] = PI.useState(false);
  const [selected, setSelected] = PI.useState(new Set());
  const [portfolioFilter, setPortfolioFilter] = PI.useState(initialPortfolioFilter || "all");
  const [ownerFilter, setOwnerFilter] = PI.useState("all");

  // Sync when parent passes a new filter (e.g. navigated from portfolios list)
  PI.useEffect(() => {
    if (initialPortfolioFilter) setPortfolioFilter(initialPortfolioFilter);
  }, [initialPortfolioFilter]);

  const portfolioOptions = [...new Set(simulations.map(s => s.portfolio))].sort();
  const ownerOptions = [...new Set(simulations.map(s => s.owner).filter(Boolean))].sort();
  const filtered = simulations.filter(s => {
    if (portfolioFilter !== "all" && s.portfolio !== portfolioFilter) return false;
    if (ownerFilter !== "all" && s.owner !== ownerFilter) return false;
    if (search && !(s.name.toLowerCase().includes(search.toLowerCase()) || s.portfolio.toLowerCase().includes(search.toLowerCase()))) return false;
    return true;
  });
  const hasFilter = portfolioFilter !== "all" || ownerFilter !== "all";

  function toggleSel(id) {
    setSelected(prev => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else if (n.size < 2) n.add(id);
      else { onToast("Select exactly 2 simulations to compare", "warn"); return prev; }
      return n;
    });
  }

  function runCompare() {
    if (selected.size !== 2) { onToast("Select 2 simulations to compare", "warn"); return; }
    onCompare([...selected]);
  }

  return React.createElement("div", { className: "main-inner" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("div", { className: "page-crumb" },
          React.createElement("span", null, "Workspace"),
          React.createElement("span", { className: "sep" }, "/"),
          React.createElement("span", null, "Simulations")
        ),
        React.createElement("h1", { className: "page-title" }, "Simulations"),
        React.createElement("div", { className: "page-sub" },
          `${simulations.length} runs across ${new Set(simulations.map(s => s.portfolio)).size} portfolios`)
      ),
      React.createElement("div", { className: "head-actions" },
        compareMode
          ? React.createElement(PI.Fragment, null,
              React.createElement("span", { className: "tag tag-dawn", style: { marginRight: 4 } },
                `${selected.size}/2 selected`),
              React.createElement(PI.Btn, { kind: "ghost",
                onClick: () => { setCompareMode(false); setSelected(new Set()); } }, "Cancel"),
              React.createElement(PI.Btn, { kind: "primary",
                icon: React.createElement(PI.Icon.BarChart, { size: 14 }),
                disabled: selected.size !== 2,
                onClick: runCompare }, "Compare")
            )
          : React.createElement(PI.Fragment, null,
              React.createElement(PI.Btn, { kind: "ghost",
                icon: React.createElement(PI.Icon.BarChart, { size: 14 }),
                onClick: () => setCompareMode(true) }, "Compare"),
              React.createElement(PI.Btn, { kind: "primary",
                icon: React.createElement(PI.Icon.Plus, { size: 14 }),
                onClick: onNewSim }, "New simulation")
            )
      )
    ),

    React.createElement("div", { className: "table-wrap" },
      React.createElement("div", { className: "tbl-toolbar" },
        React.createElement("div", { className: "tbl-toolbar-left" },
          React.createElement("div", { className: "tbl-search" },
            React.createElement(PI.Icon.Search, { size: 13 }),
            React.createElement("input", {
              placeholder: "Search simulations",
              value: search, onChange: e => setSearch(e.target.value)
            })
          ),
          hasFilter && React.createElement("button", {
            className: "btn-chip-clear",
            onClick: () => { setPortfolioFilter("all"); setOwnerFilter("all"); }
          }, "Clear filters"),
          React.createElement("span", { className: "tbl-count" }, `${filtered.length} of ${simulations.length}`)
        )
      ),
      React.createElement("div", { className: "tbl-scroll" },
        React.createElement("table", { className: "portfolios-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              compareMode && React.createElement("th", { style: { width: 34 } }, ""),
              React.createElement("th", { style: { minWidth: 240 } }, "Simulation"),
              React.createElement("th", null,
                React.createElement(ColumnFilter, {
                  label: "Portfolio",
                  value: portfolioFilter,
                  options: [{ value: "all", label: "All portfolios" }, ...portfolioOptions.map(p => ({ value: p, label: p }))],
                  onChange: setPortfolioFilter
                })
              ),
              React.createElement("th", null,
                React.createElement(ColumnFilter, {
                  label: "Owner",
                  value: ownerFilter,
                  options: [{ value: "all", label: "All owners" }, ...ownerOptions.map(o => ({ value: o, label: o }))],
                  onChange: setOwnerFilter
                })
              ),
              React.createElement("th", null, "Created"),
              React.createElement("th", { style: { width: 120 } }, "")
            )
          ),
          React.createElement("tbody", null,
            filtered.map(s => {
              const isSel = selected.has(s.id);
              return React.createElement("tr", {
                key: s.id,
                className: `is-clickable${isSel ? " is-selected" : ""}`,
                onClick: () => compareMode ? toggleSel(s.id) : s.status === "Completed" && onOpen(s)
              },
                compareMode && React.createElement("td", { onClick: e => e.stopPropagation() },
                  React.createElement("input", { type: "checkbox", className: "chk",
                    checked: isSel, disabled: s.status !== "Completed",
                    onChange: () => toggleSel(s.id) })
                ),
                React.createElement("td", null,
                  React.createElement("div", { className: "inv-name" }, s.name),
                  React.createElement("div", { className: "inv-gp" }, s.stressTests.length ? `Stress: ${s.stressTests.join(", ")}` : "No stress tests")
                ),
                React.createElement("td", null, s.portfolio),
                React.createElement("td", null, s.owner || "—"),
                React.createElement("td", null, s.created),
                React.createElement("td", { onClick: e => e.stopPropagation() },
                  React.createElement("div", { className: "row-actions", style: { opacity: 1 } },
                    React.createElement("button", { title: "Rename", onClick: () => onToast("Rename — coming soon") },
                      React.createElement(PI.Icon.Edit, { size: 13 })),
                    React.createElement("button", { title: "Share", onClick: () => onToast("Share link copied") },
                      React.createElement(PI.Icon.Share, { size: 13 }))
                  )
                )
              );
            })
          )
        )
      )
    )
  );
}

// ---------------- Compare Simulations view ----------------
function CompareView({ simulations, ids, onBack, onToast }) {
  const a = simulations.find(s => s.id === ids[0]);
  const b = simulations.find(s => s.id === ids[1]);
  if (!a || !b) return React.createElement("div", null, "Missing simulations");

  const rows = [
    { lbl: "Portfolio", k: "portfolio" },
    { lbl: "Created", k: "created" },
    { lbl: "Iterations", k: "depth", fmt: v => v === "fast" ? "1,000" : "50,000" },
    { lbl: "Stress tests", k: "stressTests", fmt: v => v.length ? v.join(", ") : "None" },
    { lbl: "Mean TVPI", k: "headlineTvpi", fmt: v => PI.fmt.mult(v), num: true },
    { lbl: "P10 TVPI", k: "p10Tvpi", fmt: v => PI.fmt.mult(v), num: true },
    { lbl: "P90 TVPI", k: "p90Tvpi", fmt: v => PI.fmt.mult(v), num: true },
    { lbl: "Mean IRR", k: "meanIrr", fmt: v => PI.fmt.pct(v, 1), num: true },
    { lbl: "Mean DPI (10y)", k: "meanDpi", fmt: v => PI.fmt.mult(v), num: true },
    { lbl: "Prob. loss", k: "probLoss", fmt: v => PI.fmt.pct(v, 1), num: true },
  ];

  return React.createElement("div", { className: "main-inner" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("div", { className: "page-crumb" },
          React.createElement("a", { href: "#", onClick: e => { e.preventDefault(); onBack(); } }, "Simulations"),
          React.createElement(PI.Icon.ChevronRight, { size: 12, className: "sep" }),
          React.createElement("span", null, "Compare")
        ),
        React.createElement("h1", { className: "page-title" }, "Simulation comparison"),
        React.createElement("div", { className: "page-sub" },
          `${a.name}  vs.  ${b.name}`)
      ),
      React.createElement("div", { className: "head-actions" },
        React.createElement(PI.Btn, { kind: "ghost", onClick: onBack }, "Back"),
        React.createElement(PI.Btn, { kind: "ghost",
          icon: React.createElement(PI.Icon.Download, { size: 13 }),
          onClick: () => onToast("Comparison downloaded") }, "Download PDF")
      )
    ),

    React.createElement("div", { className: "compare-grid" },
      [a, b].map((s, i) => React.createElement("div", { key: s.id, className: "compare-col" },
        React.createElement("div", { className: "compare-col-head" },
          React.createElement("div", { className: "eyebrow" }, i === 0 ? "Baseline" : "Comparison"),
          React.createElement("div", { className: "compare-col-title" }, s.name)
        ),
        React.createElement("div", { className: "compare-kpis" },
          React.createElement("div", { className: "compare-kpi" },
            React.createElement("div", { className: "compare-kpi-lbl" }, "Mean TVPI"),
            React.createElement("div", { className: "compare-kpi-val num" }, PI.fmt.mult(s.headlineTvpi))),
          React.createElement("div", { className: "compare-kpi" },
            React.createElement("div", { className: "compare-kpi-lbl" }, "Mean IRR"),
            React.createElement("div", { className: "compare-kpi-val num" }, PI.fmt.pct(s.meanIrr, 1))),
          React.createElement("div", { className: "compare-kpi" },
            React.createElement("div", { className: "compare-kpi-lbl" }, "P(loss)"),
            React.createElement("div", { className: "compare-kpi-val num" }, PI.fmt.pct(s.probLoss, 1)))
        ),
        // Histogram sketch
        React.createElement("div", { className: "compare-chart" },
          React.createElement("div", { className: "compare-chart-lbl" }, "TVPI distribution"),
          React.createElement("div", { className: "compare-histo" },
            Array.from({ length: 18 }, (_, j) => {
              const mid = j - 9;
              const v = Math.exp(-Math.pow((mid - (s.headlineTvpi - 1.5) * 6) / 5, 2)) * 100;
              return React.createElement("div", {
                key: j, className: "compare-histo-bar",
                style: { height: `${Math.max(6, v)}%`, background: i === 0 ? "var(--green)" : "var(--dawn)" }
              });
            })
          )
        )
      ))
    ),

    React.createElement("div", { className: "table-wrap", style: { marginTop: 20 } },
      React.createElement("table", { className: "compare-table" },
        React.createElement("thead", null, React.createElement("tr", null,
          React.createElement("th", null, "Metric"),
          React.createElement("th", null, a.name),
          React.createElement("th", null, b.name),
          React.createElement("th", { className: "num" }, "Δ"))),
        React.createElement("tbody", null,
          rows.map(r => {
            const va = a[r.k], vb = b[r.k];
            const delta = r.num ? (vb - va) : null;
            const deltaFmt = delta !== null
              ? (delta > 0 ? "+" : "") + (r.k === "probLoss" || r.k === "meanIrr" ? PI.fmt.pct(delta, 1) : PI.fmt.num(delta, 2))
              : "";
            const deltaClass = delta > 0 ? (r.k === "probLoss" ? "neg" : "pos") :
                               delta < 0 ? (r.k === "probLoss" ? "pos" : "neg") : "";
            return React.createElement("tr", { key: r.k },
              React.createElement("td", { style: { fontWeight: 500 } }, r.lbl),
              React.createElement("td", { className: r.num ? "num" : "" }, r.fmt ? r.fmt(va) : va),
              React.createElement("td", { className: r.num ? "num" : "" }, r.fmt ? r.fmt(vb) : vb),
              React.createElement("td", { className: `num ${deltaClass}` }, deltaFmt)
            );
          })
        )
      )
    )
  );
}

window.PI.NewPortfolioModal = NewPortfolioModal;
window.PI.GoalSeekModal = GoalSeekModal;
window.PI.SimulationsPage = SimulationsPage;
window.PI.CompareView = CompareView;

// --------------- Pick Portfolio for Simulation ---------------
function PickPortfolioModal({ portfolios, onClose, onPick }) {
  const [sel, setSel] = PI.useState(null);
  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: onClose }),
    React.createElement("div", { className: "modal-wrap", onClick: onClose },
      React.createElement("div", { className: "modal", style: { maxWidth: 520 }, onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" }, "New simulation · step 1 of 2"),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 500 } }, "Choose a portfolio")
          ),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),
        React.createElement("div", { className: "modal-body" },
          React.createElement("div", { className: "pick-pf-list" },
            portfolios.map(p => React.createElement("button", {
              key: p.id,
              className: `pick-pf-row${sel === p.id ? " is-active" : ""}`,
              onClick: () => setSel(p.id)
            },
              React.createElement("div", null,
                React.createElement("div", { className: "pick-pf-name" }, p.name),
                React.createElement("div", { className: "pick-pf-meta" },
                  `${p.funds} funds · ${PI.fmt.money(p.committed)} committed · ${(p.simCount||0)} simulations`)
              ),
              sel === p.id && React.createElement(PI.Icon.Check, { size: 14 })
            ))
          )
        ),
        React.createElement("footer", { className: "modal-foot" },
          React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
          React.createElement(PI.Btn, {
            kind: "primary", disabled: !sel,
            icon: React.createElement(PI.Icon.ArrowRight, { size: 13 }),
            onClick: () => onPick(sel)
          }, "Continue")
        )
      )
    )
  );
}
window.PI.PickPortfolioModal = PickPortfolioModal;
