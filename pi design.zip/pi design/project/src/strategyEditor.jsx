/* Strategy Editor Modal — Phase 2 (checklist §2.4).
   Triggered from liquidity.jsx StrategyConfigPanel via [Edit / Create strategy].
   Reference: descrizione.md §5. All comments reference the spec section.
   Uses spec asset-type keys throughout (cash / bonds / stocks / etfs /
   hedge_funds / secondary_funds / primary_funds). */

// ---------- Labels / option lists ----------
const SPEC_LABELS = {
  cash: "Cash",
  bonds: "Bonds",
  stocks: "Stocks",
  etfs: "ETFs",
  hedge_funds: "Hedge Funds",
  secondary_funds: "Secondary",
  primary_funds: "Primary",
};
const FREQ_OPTS = [
  { value: "monthly",     label: "Monthly" },
  { value: "quarterly",   label: "Quarterly" },
  { value: "semi-annual", label: "Semi-annual" },
  { value: "annual",      label: "Annual" },
  { value: "gated",       label: "Gated" },
];
const PERCENTILE_OPTS = [
  { value: "P5",  label: "P5 (worst-case)" },
  { value: "P10", label: "P10" },
  { value: "P25", label: "P25" },
  { value: "P50", label: "P50 (median)" },
  { value: "P75", label: "P75" },
  { value: "P90", label: "P90" },
  { value: "P95", label: "P95 (best-case)" },
];

function makeDefaultConstraint(type) {
  switch (type) {
    case "hedge_funds":
      return {
        asset_type: type,
        redemption_frequency: "quarterly",
        notice_period_days: 30,
        max_redemption_pct_per_period: 20,
        annual_redemption_cap_by_year: null,
      };
    case "secondary_funds":
      return {
        asset_type: type,
        estimated_liquidation_timeline_months: 48,
        max_liquidation_pct_per_year: 25,
        exclude_from_liquidation: null,
      };
    case "primary_funds":
      return {
        asset_type: type,
        estimated_liquidation_timeline_months: null,
        max_liquidation_pct_per_year: null,
        exclude_from_liquidation: null,
      };
    case "bonds":
    case "stocks":
    case "etfs":
      return { asset_type: type, exclude_from_liquidation: null };
    case "cash":
    default:
      return { asset_type: type };
  }
}

// ---------- Constraint Editor Popup (checklist §2.4.3 / spec §5.1.2) ----------
function ConstraintEditorPopup({ assetType, constraint, positions, errors, onSave, onCancel }) {
  const initial = constraint
    ? { ...constraint }
    : makeDefaultConstraint(assetType);
  const [c, setC] = PI.useState(initial);
  // Hedge-fund annual cap: toggle between "same every year" and "varies by year"
  const capIsMap = c.annual_redemption_cap_by_year && typeof c.annual_redemption_cap_by_year === "object" && !Array.isArray(c.annual_redemption_cap_by_year);
  const [capVaries, setCapVaries] = PI.useState(capIsMap);
  const [flatCap, setFlatCap] = PI.useState(() => {
    if (capIsMap) {
      const v = Object.values(c.annual_redemption_cap_by_year)[0];
      return typeof v === "number" ? v : 30;
    }
    return typeof c.annual_redemption_cap_by_year === "number" ? c.annual_redemption_cap_by_year : null;
  });
  // Primary: "allow redemption" toggle
  const [allowPrimaryRedemption, setAllowPrimaryRedemption] = PI.useState(
    assetType === "primary_funds" && (c.estimated_liquidation_timeline_months != null || c.max_liquidation_pct_per_year != null)
  );
  // Excludable positions list
  const [showExclude, setShowExclude] = PI.useState(Array.isArray(c.exclude_from_liquidation) && c.exclude_from_liquidation.length > 0);

  const internalType = PI_DATA.SPEC_TO_INTERNAL[assetType];
  const relevantPositions = positions.filter(p => {
    const mapped = PI_DATA.INTERNAL_TO_SPEC[p.assetType];
    return mapped === assetType;
  });

  const setField = (k, v) => setC({ ...c, [k]: v });

  const body = [];
  if (assetType === "cash") {
    body.push(React.createElement("div", { key: "info", className: "strat-cp-info" },
      React.createElement(PI.Icon.Info, { size: 14 }),
      React.createElement("span", null, "Fully liquid, instant liquidation. No configuration needed.")
    ));
  } else if (assetType === "bonds" || assetType === "stocks" || assetType === "etfs") {
    const hint = assetType === "bonds" ? "Highly liquid, market hours." : `Liquid on public markets (T+1-3).`;
    body.push(React.createElement("div", { key: "info", className: "strat-cp-info" },
      React.createElement(PI.Icon.Info, { size: 14 }),
      React.createElement("span", null, hint)
    ));
    body.push(React.createElement("label", { key: "excl-tog", className: "strat-cp-check" },
      React.createElement("input", {
        type: "checkbox", checked: showExclude,
        onChange: e => {
          setShowExclude(e.target.checked);
          if (!e.target.checked) setField("exclude_from_liquidation", null);
        }
      }),
      React.createElement("span", null, `Exclude specific ${SPEC_LABELS[assetType].toLowerCase()} from liquidation`)
    ));
    if (showExclude) {
      if (relevantPositions.length === 0) {
        body.push(React.createElement("div", { key: "excl-empty", className: "strat-cp-empty" },
          `No ${SPEC_LABELS[assetType].toLowerCase()} positions on this vehicle.`));
      } else {
        body.push(React.createElement("div", { key: "excl-list", className: "strat-cp-exclude" },
          relevantPositions.map(p => {
            const excluded = Array.isArray(c.exclude_from_liquidation) && c.exclude_from_liquidation.includes(p.id);
            return React.createElement("label", { key: p.id, className: "strat-cp-exclude-row" },
              React.createElement("input", {
                type: "checkbox", checked: excluded,
                onChange: e => {
                  const list = Array.isArray(c.exclude_from_liquidation) ? c.exclude_from_liquidation.slice() : [];
                  if (e.target.checked) list.push(p.id);
                  else { const i = list.indexOf(p.id); if (i >= 0) list.splice(i, 1); }
                  setField("exclude_from_liquidation", list);
                }
              }),
              React.createElement("span", { className: "strat-cp-exclude-name" }, p.name || p.ticker || p.id),
              React.createElement("span", { className: "strat-cp-exclude-nav" }, PI.fmt.money(p.nav))
            );
          })
        ));
      }
    }
  } else if (assetType === "hedge_funds") {
    const hfErr = errors || {};
    body.push(React.createElement("div", { key: "freq-row", className: "strat-cp-field" },
      React.createElement("div", { className: "strat-cp-label" }, "Redemption frequency"),
      React.createElement("div", { className: "strat-cp-radio-group" },
        FREQ_OPTS.map(o => React.createElement("label", { key: o.value, className: "strat-cp-radio" },
          React.createElement("input", {
            type: "radio", name: "hf-freq", value: o.value,
            checked: c.redemption_frequency === o.value,
            onChange: () => setField("redemption_frequency", o.value)
          }),
          React.createElement("span", null, o.label)
        ))
      )
    ));
    body.push(React.createElement("div", { key: "notice-row", className: "strat-cp-grid2" },
      React.createElement(PI.Field, { label: "Notice period (days)", error: hfErr.notice_period_days },
        React.createElement("input", {
          className: "input", type: "number", min: 0,
          value: c.notice_period_days ?? "",
          onChange: e => setField("notice_period_days", e.target.value === "" ? null : +e.target.value)
        })
      ),
      React.createElement(PI.Field, { label: "Max redemption % per period", error: hfErr.max_redemption_pct_per_period, hint: "Max % of position per redemption window" },
        React.createElement("input", {
          className: "input", type: "number", min: 0, max: 100,
          value: c.max_redemption_pct_per_period ?? "",
          onChange: e => setField("max_redemption_pct_per_period", e.target.value === "" ? null : +e.target.value)
        })
      )
    ));
    // Annual cap block
    body.push(React.createElement("div", { key: "cap-head", className: "strat-cp-label" }, "Annual redemption cap"));
    body.push(React.createElement("div", { key: "cap-radio", className: "strat-cp-radio-group" },
      React.createElement("label", { className: "strat-cp-radio" },
        React.createElement("input", {
          type: "radio", name: "hf-cap", checked: !capVaries,
          onChange: () => {
            setCapVaries(false);
            setField("annual_redemption_cap_by_year", flatCap != null ? flatCap : null);
          }
        }),
        React.createElement("span", null, "Same every year")
      ),
      React.createElement("label", { className: "strat-cp-radio" },
        React.createElement("input", {
          type: "radio", name: "hf-cap", checked: capVaries,
          onChange: () => {
            setCapVaries(true);
            const y = new Date().getFullYear();
            const seed = {};
            [y, y + 1, y + 2].forEach(yy => { seed[yy] = flatCap ?? 30; });
            setField("annual_redemption_cap_by_year", seed);
          }
        }),
        React.createElement("span", null, "Varies by year")
      )
    ));
    if (!capVaries) {
      body.push(React.createElement("div", { key: "cap-flat", className: "strat-cp-field" },
        React.createElement(PI.Field, { label: "Cap (%)", error: hfErr.annual_redemption_cap_by_year, hint: "Leave empty for no cap" },
          React.createElement("input", {
            className: "input", type: "number", min: 0, max: 100,
            value: flatCap ?? "",
            onChange: e => {
              const v = e.target.value === "" ? null : +e.target.value;
              setFlatCap(v);
              setField("annual_redemption_cap_by_year", v);
            }
          })
        )
      ));
    } else {
      const caps = c.annual_redemption_cap_by_year || {};
      const years = Object.keys(caps).sort();
      body.push(React.createElement("table", { key: "cap-tbl", className: "strat-cp-year-table" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", null, "Year"),
            React.createElement("th", null, "Cap (%)"),
            React.createElement("th", null, "")
          )
        ),
        React.createElement("tbody", null,
          years.map(y => React.createElement("tr", { key: y },
            React.createElement("td", null, y),
            React.createElement("td", null,
              React.createElement("input", {
                className: "input input-sm", type: "number", min: 0, max: 100,
                value: caps[y], onChange: e => {
                  const nc = { ...caps, [y]: e.target.value === "" ? 0 : +e.target.value };
                  setField("annual_redemption_cap_by_year", nc);
                }
              })
            ),
            React.createElement("td", null,
              React.createElement("button", {
                type: "button", className: "btn-link-danger",
                onClick: () => {
                  const nc = { ...caps };
                  delete nc[y];
                  setField("annual_redemption_cap_by_year", nc);
                }
              }, "Remove")
            )
          ))
        ),
        React.createElement("tfoot", null,
          React.createElement("tr", null,
            React.createElement("td", { colSpan: 3 },
              React.createElement("button", {
                type: "button", className: "btn-link",
                onClick: () => {
                  const lastY = years.length ? Math.max(...years.map(y => +y)) : new Date().getFullYear();
                  const nc = { ...caps, [lastY + 1]: flatCap ?? 30 };
                  setField("annual_redemption_cap_by_year", nc);
                }
              }, "+ Add year")
            )
          )
        )
      ));
      if (hfErr.annual_redemption_cap_by_year) {
        body.push(React.createElement("div", { key: "cap-err", className: "field-error" }, hfErr.annual_redemption_cap_by_year));
      }
    }
    // Status display
    const thisYear = new Date().getFullYear();
    let thisYearCap = null;
    if (!capVaries && flatCap != null) thisYearCap = flatCap;
    else if (capVaries && c.annual_redemption_cap_by_year && c.annual_redemption_cap_by_year[thisYear] != null) thisYearCap = c.annual_redemption_cap_by_year[thisYear];
    body.push(React.createElement("div", { key: "status", className: "strat-cp-status" },
      React.createElement(PI.Icon.Info, { size: 13 }),
      React.createElement("span", null,
        thisYearCap != null
          ? `Max redemption in ${thisYear}: ${thisYearCap}% of position value`
          : `No annual cap for ${thisYear} — redemptions limited only by per-period cap (${c.max_redemption_pct_per_period ?? "—"}% × ${c.redemption_frequency || "—"})`
      )
    ));
  } else if (assetType === "secondary_funds") {
    const sErr = errors || {};
    body.push(React.createElement("div", { key: "info", className: "strat-cp-info" },
      React.createElement(PI.Icon.Info, { size: 14 }),
      React.createElement("span", null, "Secondary positions wind down gradually — typically 3-5 years.")
    ));
    body.push(React.createElement("div", { key: "grid", className: "strat-cp-grid2" },
      React.createElement(PI.Field, { label: "Liquidation timeline (months)", error: sErr.estimated_liquidation_timeline_months, hint: "Full exit horizon" },
        React.createElement("input", {
          className: "input", type: "number", min: 0,
          value: c.estimated_liquidation_timeline_months ?? "",
          onChange: e => setField("estimated_liquidation_timeline_months", e.target.value === "" ? null : +e.target.value)
        })
      ),
      React.createElement(PI.Field, { label: "Max liquidation % per year", error: sErr.max_liquidation_pct_per_year },
        React.createElement("input", {
          className: "input", type: "number", min: 0, max: 100,
          value: c.max_liquidation_pct_per_year ?? "",
          onChange: e => setField("max_liquidation_pct_per_year", e.target.value === "" ? null : +e.target.value)
        })
      )
    ));
    const pct = Number(c.max_liquidation_pct_per_year) || 0;
    if (pct > 0) {
      const yrs = Math.ceil(100 / pct);
      body.push(React.createElement("div", { key: "status", className: "strat-cp-status" },
        React.createElement(PI.Icon.Info, { size: 13 }),
        React.createElement("span", null, `At ${pct}% per year, fully exited in ~${yrs} year${yrs === 1 ? "" : "s"}`)
      ));
    }
  } else if (assetType === "primary_funds") {
    const pErr = errors || {};
    body.push(React.createElement("div", { key: "info", className: "strat-cp-info" },
      React.createElement(PI.Icon.Info, { size: 14 }),
      React.createElement("span", null, "Generally illiquid. Redemption at fund termination only (vintage + life).")
    ));
    body.push(React.createElement("label", { key: "allow-tog", className: "strat-cp-check" },
      React.createElement("input", {
        type: "checkbox", checked: allowPrimaryRedemption,
        onChange: e => {
          setAllowPrimaryRedemption(e.target.checked);
          if (e.target.checked) {
            setField("estimated_liquidation_timeline_months", 60);
            setC(cc => ({ ...cc, estimated_liquidation_timeline_months: 60, max_liquidation_pct_per_year: 10 }));
          } else {
            setC(cc => ({ ...cc, estimated_liquidation_timeline_months: null, max_liquidation_pct_per_year: null }));
          }
        }
      }),
      React.createElement("span", null, "Allow redemption (e.g. for co-investments)")
    ));
    if (allowPrimaryRedemption) {
      body.push(React.createElement("div", { key: "grid", className: "strat-cp-grid2" },
        React.createElement(PI.Field, { label: "Timeline (months)", error: pErr.estimated_liquidation_timeline_months },
          React.createElement("input", {
            className: "input", type: "number", min: 0,
            value: c.estimated_liquidation_timeline_months ?? "",
            onChange: e => setField("estimated_liquidation_timeline_months", e.target.value === "" ? null : +e.target.value)
          })
        ),
        React.createElement(PI.Field, { label: "Max per year (%)", error: pErr.max_liquidation_pct_per_year },
          React.createElement("input", {
            className: "input", type: "number", min: 0, max: 100,
            value: c.max_liquidation_pct_per_year ?? "",
            onChange: e => setField("max_liquidation_pct_per_year", e.target.value === "" ? null : +e.target.value)
          })
        )
      ));
    }
  }

  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim scrim-nested", onClick: onCancel }),
    React.createElement("div", { className: "modal-wrap modal-wrap-nested", onClick: onCancel },
      React.createElement("div", { className: "modal modal-sm strat-cp", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" }, "Constraints"),
            React.createElement("h3", { style: { fontSize: 16, fontWeight: 500 } }, SPEC_LABELS[assetType])
          ),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 15 }), onClick: onCancel })
        ),
        React.createElement("div", { className: "modal-body strat-cp-body" }, body),
        React.createElement("footer", { className: "modal-foot" },
          React.createElement(PI.Btn, { kind: "ghost", onClick: onCancel }, "Cancel"),
          React.createElement(PI.Btn, { kind: "primary", onClick: () => onSave(c) }, "Save")
        )
      )
    )
  );
}

// ---------- Priority List with drag-to-reorder (checklist §2.4.2) ----------
function PriorityList({ items, availableToAdd, onReorder, onRemove, onAdd, onEditConstraint, isProportional, onToggleProportional }) {
  const [dragIdx, setDragIdx] = PI.useState(null);
  const [overIdx, setOverIdx] = PI.useState(null);
  const [addOpen, setAddOpen] = PI.useState(false);
  const addRef = PI.useClickOutside(() => setAddOpen(false));

  const handleDragStart = (i) => (e) => {
    setDragIdx(i);
    e.dataTransfer.effectAllowed = "move";
    try { e.dataTransfer.setData("text/plain", String(i)); } catch (_) { /* IE */ }
  };
  const handleDragOver = (i) => (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    if (overIdx !== i) setOverIdx(i);
  };
  const handleDrop = (i) => (e) => {
    e.preventDefault();
    if (dragIdx != null && dragIdx !== i) onReorder(dragIdx, i);
    setDragIdx(null); setOverIdx(null);
  };
  const handleDragEnd = () => { setDragIdx(null); setOverIdx(null); };

  // Keyboard reorder (a11y): Up/Down arrow on drag handle
  const keyMove = (i) => (e) => {
    if (e.key === "ArrowUp" && i > 0) { e.preventDefault(); onReorder(i, i - 1); }
    else if (e.key === "ArrowDown" && i < items.length - 1) { e.preventDefault(); onReorder(i, i + 1); }
  };

  return React.createElement("div", { className: "strat-priority" },
    React.createElement("ol", { className: `strat-pri-list${isProportional ? " is-disabled" : ""}`, "aria-label": "Liquidation priority list" },
      items.map((type, i) => React.createElement("li", {
        key: type,
        className: `strat-pri-row${dragIdx === i ? " is-dragging" : ""}${overIdx === i && dragIdx != null && dragIdx !== i ? " is-drop" : ""}`,
        draggable: !isProportional,
        onDragStart: handleDragStart(i),
        onDragOver: handleDragOver(i),
        onDrop: handleDrop(i),
        onDragEnd: handleDragEnd,
      },
        React.createElement("button", {
          type: "button",
          className: "strat-pri-handle",
          title: "Drag to reorder (or use ↑ / ↓)",
          onKeyDown: keyMove(i),
          "aria-label": `Reorder ${SPEC_LABELS[type]}`,
          disabled: isProportional
        }, "\u2630"),
        React.createElement("span", { className: "strat-pri-rank" }, i + 1),
        React.createElement("span", { className: "strat-pri-label" }, SPEC_LABELS[type]),
        React.createElement("button", {
          type: "button", className: "btn-link",
          disabled: isProportional,
          onClick: () => onEditConstraint(type)
        }, "Constraints…"),
        React.createElement("button", {
          type: "button", className: "btn-link-danger",
          disabled: isProportional || items.length <= 1,
          title: items.length <= 1 ? "Cannot remove the last asset type" : "",
          onClick: () => onRemove(type)
        }, "Remove")
      ))
    ),

    availableToAdd.length > 0 && !isProportional && React.createElement("div", { className: "strat-pri-add", ref: addRef },
      React.createElement(PI.Btn, {
        kind: "ghost", size: "sm",
        icon: React.createElement(PI.Icon.Plus, { size: 12 }),
        onClick: () => setAddOpen(o => !o)
      }, "Add asset type"),
      addOpen && React.createElement("div", { className: "strat-pri-add-menu" },
        availableToAdd.map(t => React.createElement("button", {
          key: t, type: "button", className: "strat-pri-add-item",
          onClick: () => { onAdd(t); setAddOpen(false); }
        }, SPEC_LABELS[t]))
      )
    ),

    React.createElement("label", { className: "strat-prop-toggle" },
      React.createElement("input", {
        type: "checkbox", checked: isProportional,
        onChange: e => onToggleProportional(e.target.checked)
      }),
      React.createElement("span", null,
        React.createElement("b", null, "Use Proportional Liquidation"),
        React.createElement("span", { className: "strat-prop-hint" }, " — liquidate proportionally from all asset types, ignoring priority.")
      )
    )
  );
}

// ---------- Rebalancing Rules (checklist §2.4.4) ----------
function RebalancingRulesSection({
  trigger, setTrigger,
  allocation, setAllocation,
  tolerance, setTolerance,
  minCashPct, setMinCashPct,
  minCashPercentile, setMinCashPercentile,
  applyOnDate, setApplyOnDate,
  specificDate, setSpecificDate,
  errors
}) {
  const sum = PI_DATA.SPEC_ASSET_TYPES.reduce((s, k) => s + (Number(allocation[k]) || 0), 0);
  const sumOk = Math.abs(sum - 100) <= 0.01;
  const showTargetTable = trigger === "fixed" || trigger === "tolerance";

  return React.createElement("div", { className: "strat-reb" },
    React.createElement("div", { className: "strat-reb-triggers" },
      [
        { v: "fixed",            label: "Maintain Target Allocation",    hint: "Enforce exact % every year" },
        { v: "tolerance",        label: "Target with Tolerance Band",     hint: "Rebalance only if drift > ±X%" },
        { v: "min_cash_reserve", label: "Minimum Cash Reserve",           hint: "Keep at least X% cash (or a stress percentile)" },
      ].map(opt => React.createElement("label", {
        key: opt.v,
        className: `strat-reb-radio${trigger === opt.v ? " is-active" : ""}`
      },
        React.createElement("input", {
          type: "radio", name: "strat-trigger", value: opt.v,
          checked: trigger === opt.v,
          onChange: () => setTrigger(opt.v)
        }),
        React.createElement("div", { className: "strat-reb-radio-body" },
          React.createElement("div", { className: "strat-reb-radio-label" }, opt.label),
          React.createElement("div", { className: "strat-reb-radio-hint" }, opt.hint)
        )
      ))
    ),

    showTargetTable && React.createElement("div", { className: "strat-reb-section" },
      React.createElement("div", { className: "form-section-title" }, "Target allocation"),
      React.createElement("table", { className: "strat-target-table" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", null, "Asset type"),
            React.createElement("th", { style: { width: 140 } }, "Target %")
          )
        ),
        React.createElement("tbody", null,
          PI_DATA.SPEC_ASSET_TYPES.map(t => React.createElement("tr", { key: t },
            React.createElement("td", null, SPEC_LABELS[t]),
            React.createElement("td", null,
              React.createElement("input", {
                className: "input input-sm", type: "number", min: 0, max: 100,
                value: allocation[t] ?? 0,
                onChange: e => {
                  const v = e.target.value === "" ? 0 : +e.target.value;
                  setAllocation({ ...allocation, [t]: v });
                }
              })
            )
          ))
        ),
        React.createElement("tfoot", null,
          React.createElement("tr", { className: `strat-target-sum${sumOk ? " is-ok" : " is-bad"}` },
            React.createElement("td", null, "Total"),
            React.createElement("td", null, sum.toFixed(1) + "%",
              !sumOk && React.createElement("span", { className: "strat-target-sum-hint" }, ` (needs 100%)`)
            )
          )
        )
      ),
      errors.rebalancing_target_allocation && React.createElement("div", { className: "field-error" }, errors.rebalancing_target_allocation)
    ),

    trigger === "tolerance" && React.createElement("div", { className: "strat-reb-section" },
      React.createElement(PI.Field, { label: "Tolerance band (± %)", error: errors.rebalancing_tolerance_pct, hint: "Rebalance if any asset drifts by more than this percentage from target" },
        React.createElement("input", {
          className: "input", type: "number", min: 0, max: 100, step: 0.5,
          value: tolerance,
          onChange: e => setTolerance(e.target.value === "" ? 0 : +e.target.value)
        })
      )
    ),

    trigger === "min_cash_reserve" && React.createElement("div", { className: "strat-reb-section" },
      React.createElement("div", { className: "strat-reb-minc" },
        React.createElement(PI.Field, { label: "Minimum cash (% of portfolio)", error: errors.min_cash_reserve_pct, hint: "Leave empty if you pick a percentile scenario instead" },
          React.createElement("input", {
            className: "input", type: "number", min: 0, max: 100, step: 0.5,
            value: minCashPct ?? "",
            disabled: !!minCashPercentile,
            onChange: e => setMinCashPct(e.target.value === "" ? null : +e.target.value)
          })
        ),
        React.createElement(PI.Field, { label: "Or cover a stress percentile", hint: "Maintain enough cash to sustain this outcome" },
          React.createElement(PI.Dropdown, {
            value: minCashPercentile || "",
            options: [{ value: "", label: "— No percentile —" }, ...PERCENTILE_OPTS],
            onChange: v => {
              setMinCashPercentile(v || null);
              if (v) setMinCashPct(null);
            }
          })
        )
      )
    ),

    React.createElement("div", { className: "strat-reb-section strat-reb-freq" },
      React.createElement("div", { className: "form-section-title" }, "Frequency"),
      React.createElement("div", { className: "strat-reb-freq-row" },
        React.createElement("div", { className: "strat-reb-freq-fixed" },
          React.createElement(PI.Icon.Calendar, { size: 13 }),
          React.createElement("span", null, "Annual (at year-end)")
        ),
        React.createElement("label", { className: "strat-cp-check" },
          React.createElement("input", {
            type: "checkbox", checked: applyOnDate,
            onChange: e => setApplyOnDate(e.target.checked)
          }),
          React.createElement("span", null, "Apply on specific date (MM-DD)")
        ),
        applyOnDate && React.createElement("input", {
          className: "input input-sm", type: "text", placeholder: "12-31",
          value: specificDate, onChange: e => setSpecificDate(e.target.value),
          style: { width: 80 }
        })
      )
    )
  );
}

// ---------- Save Strategy (checklist §2.4.5) ----------
function SaveStrategySection({ name, setName, description, setDescription, isReusable, setIsReusable, errors }) {
  return React.createElement("div", { className: "strat-save" },
    React.createElement(PI.Field, { label: "Strategy name", required: true, error: errors.name },
      React.createElement("input", {
        className: "input", type: "text",
        value: name, placeholder: 'e.g. "Conservative with Hedge Fund Limits"',
        onChange: e => setName(e.target.value)
      })
    ),
    React.createElement(PI.Field, { label: "Description (optional)" },
      React.createElement("input", {
        className: "input", type: "text",
        value: description,
        onChange: e => setDescription(e.target.value)
      })
    ),
    React.createElement("label", { className: "strat-cp-check strat-reuse" },
      React.createElement("input", {
        type: "checkbox", checked: isReusable,
        onChange: e => setIsReusable(e.target.checked)
      }),
      React.createElement("span", null, "Make reusable across other vehicles")
    )
  );
}

// ---------- Main Strategy Editor Modal (checklist §2.4.1) ----------
function StrategyEditorModal({ vehicleId, initialStrategy, onSave, onClose, onToast }) {
  const veh = PI_DATA.vehicleById(vehicleId);
  const positions = vehicleId ? PI_DATA.getAssetPositionsByVehicleId(vehicleId) : [];
  const isEditing = !!initialStrategy;

  // --- State ---
  const [name, setName] = PI.useState(initialStrategy?.name || "");
  const [description, setDescription] = PI.useState(initialStrategy?.description || "");
  const [liqPriority, setLiqPriority] = PI.useState(
    initialStrategy?.liquidation_priority?.slice() || PI_DATA.SPEC_ASSET_TYPES.slice()
  );
  const [isProp, setIsProp] = PI.useState(!!initialStrategy?.is_proportional);
  const [trigger, setTrigger] = PI.useState(initialStrategy?.rebalancing_trigger || "fixed");
  const [allocation, setAllocation] = PI.useState(() =>
    initialStrategy?.rebalancing_target_allocation
      ? { ...initialStrategy.rebalancing_target_allocation }
      : { cash: 20, bonds: 35, stocks: 30, etfs: 10, hedge_funds: 5, secondary_funds: 0, primary_funds: 0 }
  );
  const [tolerance, setTolerance] = PI.useState(initialStrategy?.rebalancing_tolerance_pct ?? 5);
  const [minCashPct, setMinCashPct] = PI.useState(initialStrategy?.min_cash_reserve_pct ?? null);
  const [minCashPercentile, setMinCashPercentile] = PI.useState(initialStrategy?.min_cash_reserve_percentile || null);
  const [applyOnDate, setApplyOnDate] = PI.useState(false);
  const [specificDate, setSpecificDate] = PI.useState("12-31");
  const [isReusable, setIsReusable] = PI.useState(!!initialStrategy?.is_reusable);

  const [constraintsByType, setConstraintsByType] = PI.useState(() => {
    const m = {};
    if (initialStrategy?.constraints) {
      initialStrategy.constraints.forEach(c => {
        const { id, strategy_id, created_at, updated_at, ...rest } = c;
        m[c.asset_type] = rest;
      });
    }
    return m;
  });
  const [editingConstraintType, setEditingConstraintType] = PI.useState(null);
  const [errors, setErrors] = PI.useState({});

  // --- Helpers ---
  const buildPayload = () => {
    const relevantTypes = isProp ? PI_DATA.SPEC_ASSET_TYPES : liqPriority;
    const constraints = relevantTypes
      .filter(t => t !== "cash") // cash has no constraints per spec §5.1.2
      .map(t => constraintsByType[t] || makeDefaultConstraint(t));
    return {
      name: name.trim(),
      description,
      liquidation_priority: isProp ? [] : liqPriority.slice(),
      is_proportional: isProp,
      rebalancing_trigger: trigger,
      rebalancing_target_allocation: (trigger === "fixed" || trigger === "tolerance") ? { ...allocation } : null,
      rebalancing_tolerance_pct: trigger === "tolerance" ? Number(tolerance) : null,
      min_cash_reserve_pct: (trigger === "min_cash_reserve" && !minCashPercentile && minCashPct != null) ? Number(minCashPct) : null,
      min_cash_reserve_percentile: trigger === "min_cash_reserve" ? (minCashPercentile || null) : null,
      is_reusable: isReusable,
      constraints,
    };
  };

  const liveErrs = PI_DATA.validateStrategy(buildPayload());
  const canSave = Object.keys(liveErrs).length === 0;

  // --- Actions ---
  const reorder = (from, to) => {
    const next = liqPriority.slice();
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    setLiqPriority(next);
  };
  const remove = (t) => setLiqPriority(liqPriority.filter(x => x !== t));
  const add = (t) => { if (!liqPriority.includes(t)) setLiqPriority([...liqPriority, t]); };
  const availableToAdd = PI_DATA.SPEC_ASSET_TYPES.filter(t => !liqPriority.includes(t));

  const save = () => {
    const payload = buildPayload();
    const errs = PI_DATA.validateStrategy(payload);
    if (Object.keys(errs).length) {
      setErrors(errs);
      onToast && onToast("Please fix the highlighted fields", "error");
      return;
    }
    onSave(payload);
  };

  const openConstraintEditor = (type) => setEditingConstraintType(type);
  const saveConstraint = (c) => {
    setConstraintsByType({ ...constraintsByType, [c.asset_type]: c });
    setEditingConstraintType(null);
  };

  // --- Render ---
  return React.createElement(PI.Portal, null,
    React.createElement("div", { className: "scrim", onClick: onClose }),
    React.createElement("div", { className: "modal-wrap", onClick: onClose },
      React.createElement("div", { className: "modal modal-xl strat-editor", onClick: e => e.stopPropagation() },
        React.createElement("header", { className: "modal-head" },
          React.createElement("div", null,
            React.createElement("div", { className: "drawer-eyebrow" },
              isEditing ? "Edit liquidity strategy" : "Create liquidity strategy"
            ),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 500 } },
              veh ? `${veh.name} · ${veh.desc || ""}` : "Strategy"
            )
          ),
          React.createElement(PI.IconBtn, { icon: React.createElement(PI.Icon.X, { size: 16 }), onClick: onClose })
        ),

        React.createElement("div", { className: "modal-body strat-editor-body" },
          // Part 1 — Liquidation priority
          React.createElement("section", { className: "strat-section" },
            React.createElement("div", { className: "strat-section-head" },
              React.createElement("div", { className: "strat-section-num" }, "1"),
              React.createElement("div", null,
                React.createElement("h4", { className: "strat-section-title" }, "Cash allocation priority"),
                React.createElement("div", { className: "strat-section-sub" }, "Order in which assets are liquidated when the vehicle needs cash.")
              )
            ),
            React.createElement(PriorityList, {
              items: liqPriority, availableToAdd,
              onReorder: reorder, onRemove: remove, onAdd: add,
              onEditConstraint: openConstraintEditor,
              isProportional: isProp, onToggleProportional: setIsProp
            }),
            errors.liquidation_priority && React.createElement("div", { className: "field-error" }, errors.liquidation_priority)
          ),

          // Part 2 — Rebalancing rules
          React.createElement("section", { className: "strat-section" },
            React.createElement("div", { className: "strat-section-head" },
              React.createElement("div", { className: "strat-section-num" }, "2"),
              React.createElement("div", null,
                React.createElement("h4", { className: "strat-section-title" }, "Rebalancing rules"),
                React.createElement("div", { className: "strat-section-sub" }, "When and how to restore target allocation.")
              )
            ),
            React.createElement(RebalancingRulesSection, {
              trigger, setTrigger,
              allocation, setAllocation,
              tolerance, setTolerance,
              minCashPct, setMinCashPct,
              minCashPercentile, setMinCashPercentile,
              applyOnDate, setApplyOnDate,
              specificDate, setSpecificDate,
              errors
            })
          ),

          // Part 3 — Save
          React.createElement("section", { className: "strat-section" },
            React.createElement("div", { className: "strat-section-head" },
              React.createElement("div", { className: "strat-section-num" }, "3"),
              React.createElement("div", null,
                React.createElement("h4", { className: "strat-section-title" }, "Save this strategy"),
                React.createElement("div", { className: "strat-section-sub" }, "Name this configuration and optionally reuse it on other vehicles.")
              )
            ),
            React.createElement(SaveStrategySection, {
              name, setName,
              description, setDescription,
              isReusable, setIsReusable,
              errors
            })
          )
        ),

        React.createElement("footer", { className: "modal-foot" },
          React.createElement("div", { className: "strat-foot-status" },
            !canSave && Object.keys(liveErrs).length > 0
              ? React.createElement("span", { className: "strat-foot-err" },
                  React.createElement(PI.Icon.Warning, { size: 12 }),
                  React.createElement("span", null, `${Object.keys(liveErrs).length} field${Object.keys(liveErrs).length === 1 ? "" : "s"} need${Object.keys(liveErrs).length === 1 ? "s" : ""} attention`)
                )
              : React.createElement("span", { className: "strat-foot-ok" }, "Ready to save.")
          ),
          React.createElement(PI.Btn, { kind: "ghost", onClick: onClose }, "Cancel"),
          React.createElement(PI.Btn, {
            kind: "primary",
            icon: React.createElement(PI.Icon.Save, { size: 13 }),
            onClick: save, disabled: !canSave
          }, isEditing ? "Save changes" : "Create strategy")
        )
      )
    ),

    // Nested constraint popup
    editingConstraintType && React.createElement(ConstraintEditorPopup, {
      assetType: editingConstraintType,
      constraint: constraintsByType[editingConstraintType],
      positions,
      errors: errors.constraints?.[editingConstraintType] || null,
      onSave: saveConstraint,
      onCancel: () => setEditingConstraintType(null)
    })
  );
}

window.PI.StrategyEditorModal = StrategyEditorModal;
