# Cepres Design System

A design system and UI kit for **Cepres** — a global private equity and investment advisory fintech firm — with specific components for the **Predictive Intelligence** SaaS product.

> **Cepres** is a global private equity and investment advisory firm offering data, analytics, and software to General Partners (GPs) and Limited Partners (LPs).
>
> **Predictive Intelligence** is a SaaS product in the Cepres portfolio. Based on the company description, it is an analytics application that surfaces forward-looking insight from private-market data — fund performance projections, deal benchmarks, portfolio scenario modeling, and "look-through" analysis across GP/LP relationships. The SaaS is delivered in English.

## Sources used

| Source | Status | Path |
|---|---|---|
| Cepres logo (PNG, transparent) | Used | `uploads/CEPRES-LOGO.png` → `assets/cepres-logo.png` |
| CEPRES Brand Style Guide (10-page PDF) | Used | `uploads/cepres standards.pdf` → rasterized pages at `research/standards-p*.png` |
| Brand Guide source (referenced, not provided) | Not accessed | Frontify — `company-227392.frontify.com` |
| Roboto font | Loaded from Google Fonts | `fonts/roboto.css` |

Because no codebase or Figma file was provided, the **Predictive Intelligence** UI kit is constructed from the brand foundations + the product's implied domain (PE fund analytics) rather than a live source of truth. **See CAVEATS below.**

---

## Index

```
Cepres Design System/
├── README.md                    ← this file
├── SKILL.md                     ← skill description for agents
├── colors_and_type.css          ← core tokens: CSS vars, semantic defaults
├── assets/
│   ├── cepres-logo.png          ← full lockup (2000×475)
│   ├── cepres-mark-dawn.svg     ← circular C mark, Dawn #2F3E55
│   ├── cepres-mark-teal.svg     ← circular C mark, Cepres Green #058F8A
│   ├── cepres-logo-dawn.svg     ← rebuilt lockup, Dawn
│   └── cepres-wordmark.svg      ← wordmark only
├── fonts/
│   └── roboto.css              ← loads Roboto from Google Fonts
├── preview/                     ← Design System tab cards (Type, Colors, Spacing, Components, Brand)
├── ui_kits/
│   └── predictive_intelligence/ ← SaaS UI kit (React JSX + index.html)
└── research/                    ← raw extractions from the brand PDF
```

---

## Content fundamentals

### Language & voice
- **American English, AP Style.** Not British English.
- The SaaS product is delivered in **English** — no Italian copy in the product.
- **Brevity and impact over verbosity.** Short sentences. Precise verbs.
- **Confident but not arrogant** — back claims with data, not adjectives.
- **Clear and direct** — jargon only when defined. Technical PE terms (GP, LP, IRR, DPI, MOIC, TVPI) are fine on first reference; define acronyms at first use in external-facing copy.
- **Action-oriented.** Active voice. Strong verbs.
- **Empathetic.** Acknowledge partner (LP/GP) challenges.

### The "is / is NOT" test
Cepres **IS**: Bold · Sophisticated · Creative · Smart · Approachable · Analytical.
Cepres is **NOT**: Bombastic · Stuffy · Unfocused · Arrogant · Pushover · Esoteric.

### Tone examples

| ❌ Avoid | ✅ Prefer |
|---|---|
| "Unlock the power of cutting-edge AI to revolutionize your PE workflow!" | "Forecast fund performance with 20 years of look-through data." |
| "We're thrilled to announce…" | "Predictive Intelligence is live." |
| "Our solution leverages best-in-class analytics…" | "Compare your fund against 12,000 deals." |
| "Click here to learn more" | "See fund benchmarks" |

### Casing
- **Sentence case** for headings, buttons, navigation, and labels. Not Title Case.
- **CEPRES** the brand is set in all-caps **only** inside the logo lockup. In body copy, write **"Cepres"** (capital C, lowercase rest) or **"CEPRES"** only when matching formal branding. In this system we use **Cepres** in product/UI copy.

### Terminology (from the brand guide)
| Term | Usage |
|---|---|
| "Look through" (verb) | "Look through our portfolio." |
| "Look-through" (adjective) | "Look-through analysis." |
| "Sign in" / "Sign up" (verb) | "Sign in to your account." |
| "Signin" / "Signup" (noun) | "Signin is required." |
| "Log in" / "Log out" (verb), "Login" (noun) | "Log in to proceed." |
| **Private Equity (PE)** | Define on first use. |
| **Limited Partner (LP / LPs)** | Legal term — use when addressing GPs/LPs. |
| **General Partner (GP / GPs)** | Legal term — use when addressing LPs/GPs. |

### Emoji
**Not used.** The brand is sophisticated and analytical — emoji read as casual/consumer and break tone. Use Lucide icons or numeric glyphs instead.

---

## Visual foundations

### Color
Three tiers, strict proportions:

- **Primary (70–80% of every layout)**: Dawn `#2F3E55` · Warm Grey `#EDEEE9` · White `#FFFFFF`. These three carry the brand.
- **Accent (5–15% only)**: Gold `#FFD700` (hover, CTA, emphasis) · Tantalum `#888888` (subtle dividers) · Cepres Green `#058F8A` (charts & data accents).
- **Grayscale** (UI elements only): Black 100/80/60/40/20/0. For text, borders, disabled, dividers.
- **Chart/Data palette** (charts only, never UI chrome): heavy set (Green #025100, Blue #00437F, Purple #7B267F, Red #AF2323, Orange #B56624, Yellow #FFF200) and a light set for comparison/supporting series.

**Rule:** primary dominates; accents amplify; never let gold or green carry more than a sliver of any screen.

### Type
- **Primary font: Roboto.** Weights 400 (body) and 500 (headings, emphasis — Roboto has no 600). Fallback: Helvetica, Arial.
- **Sentence-case headings.** Tight letter-spacing on display sizes (`-0.015em` to `-0.02em`).
- **Body text ≥ 16px digital / 10pt print.** Line height 1.2–1.5em (body), 1.1–1.3em (headings). Paragraph spacing 1.5em.
- **Line length 60–180 characters** — no wider measures.
- Single H1 per page. H2+ for logical breaks. No faked headings via styled spans.

### Layout
- **8px baseline grid** (12px for large-scale print). All spacing rounds to multiples of 4 or 8.
- **Whitespace is strategic** — don't fill every gap. Generous margins read as sophisticated; dense grids read as stuffy.
- Responsive: Desktop ≥1200, Tablet 768–1199, Mobile <768.
- Max body measure ~72ch.

### Backgrounds
- **Flat color first.** White or Warm Grey for canvases; Dawn for hero/header surfaces.
- **No gradients** in print collateral. Digital may use *very* subtle Dawn-to-slightly-darker-Dawn at most (avoid bluish-purple AI-slop gradients).
- **No patterns, textures, or hand-drawn illustrations.** Imagery is professional photography (business-focused, warm/neutral tones) or charts.

### Borders & dividers
- **Grayscale only.** Black 20% `#D6D6D6` for default borders; Black 40% for dividers; Black 80% for focus/selected.
- 1px by default; 2px for focus rings (plus a soft Dawn glow).

### Shadows
- **Subtle.** Never heavy. Cards use `0 1px 3px rgba(47,62,85,0.08)` at most. Reserve elevation for floating elements (menus, dialogs).

### Corner radii
- **Inputs & small buttons:** 4px · **Buttons/badges:** 6px · **Cards:** 8px · **Dialogs/hero surfaces:** 12px · **Pills/chips:** full radius.
- No 16px+ softness — keeps the "clean, geometric, refined edges" brief.

### Motion
- **Restrained.** 120–280ms transitions. Standard easing `cubic-bezier(0.4, 0, 0.2, 1)`.
- Fades and small transforms only. No bounces, no spring overshoots, no parallax.

### Hover & press states
- **Primary button hover:** shift Dawn background toward near-black and apply a 2px Gold underline or left-border. Cursor remains pointer; no scale.
- **Secondary button hover:** border color deepens from Black 20% to Black 80%; background warms slightly (Warm Grey fill).
- **Press:** 60ms ease-out, background -4% luminance, no shrink.
- **Link hover:** color shifts from Dawn to Cepres Green.
- **Row hover (tables):** Warm Grey fill.

### Transparency & blur
- **Used sparingly.** Overlay scrims at 60–70% Dawn for dialogs. Avoid frosted glass — feels iOS-casual and off-brand.

### Cards
- White or Warm Grey background · Black 20% border OR subtle shadow (choose one, not both) · 8px radius · 24–32px internal padding · 1.5em minimum between content blocks.

### Data visualization
- Primary Cepres Green `#058F8A` for key metric series.
- Heavy chart palette for categorical breakdowns; light palette for comparison/supporting series.
- Always include legends and labels. Never use color as the only signal.

---

## Iconography

Cepres's brand guide doesn't prescribe a specific icon library — only that visuals must be **"clean & modern, geometric shapes, refined edges."** For this design system we standardize on **Lucide** (lucide.dev) because it matches those criteria exactly: 1.5px stroke, rounded joins, geometric primitives, open-source, wide coverage including finance icons.

- **CDN**: `https://unpkg.com/lucide@latest`
- **Stroke**: 1.5px (default) at 20–24px icon size; 2px at 16px for crispness.
- **Color**: icons inherit `currentColor`. Default to Dawn on light surfaces, White on Dawn.
- **Sizing**: 16 · 20 · 24 · 32. Tap targets ≥ 44px even when the glyph is 20.

**Substitution flagged:** Lucide is a substitution — the brand guide doesn't mandate it. If Cepres has an internal icon set on Frontify, swap this out.

### Emoji & unicode
- **No emoji.** (See Content Fundamentals.)
- **Unicode glyphs** are fine for arrows (→ · ←), bullets (• · ·), math (±, ×), and currency ($, €, £, ¥). Used sparingly in analytical UI — e.g. "IRR ↑ 2.4%".

### Logos stored
- `assets/cepres-logo.png` — original, 2000×475 PNG with transparency.
- `assets/cepres-mark-dawn.svg` · `cepres-mark-teal.svg` — the circular "C" mark alone.
- `assets/cepres-logo-dawn.svg` · `cepres-logo-white.svg` — full lockup in single-color variants.
- `assets/cepres-wordmark.svg` — wordmark-only.

---

## UI Kits

- **Predictive Intelligence** (`ui_kits/predictive_intelligence/`) — SaaS application. Screens: portfolio overview, fund detail, deal benchmark, predictions, login. See that directory's README.

---

## CAVEATS

1. **No codebase or Figma file was provided.** The Predictive Intelligence UI kit is a *plausible reconstruction* from the brand standards + PE analytics domain knowledge — not a copy of the real product. Screens, terminology, and information architecture need verification from the product team.
2. **Brand guide minimum logo sizes were unspecified** (the PDF says "As per original guide standards" without giving numbers). We've used sensible defaults (24px minimum for the mark, 120px for the full lockup). Please confirm.
3. **Roboto** is pulled from Google Fonts. Note Roboto doesn't ship a 600 weight — the system uses 500 (Medium) for the semibold slot. If the brand licenses a custom cut, drop woff2s into `fonts/` and add @font-face rules.s/`.
4. **Iconography** defaults to Lucide — flagged as a substitution; replace with internal icons if Cepres maintains a set on Frontify.
5. **No product screenshots** were provided. All mockups are first-principles designs driven by the brand guide. Expect iteration.

## Please help me iterate

**To make this perfect, I need one of the following:**
- 🔗 A link to your Frontify brand page (`company-227392.frontify.com`) if I can be given access.
- 📸 Screenshots of the existing Predictive Intelligence product (even a few core screens — dashboard, fund detail, login).
- 💻 A codebase import, or a Figma file link for the product.
- 📝 Confirmation of the product's core IA: what are the top-level nav items? What does a user do on day 1?

With any of these I can swap the speculative UI kit for a pixel-accurate recreation.
