# LIQUIDITY MANAGEMENT MODULE - IMPLEMENTATION CHECKLIST

**Document Version**: 1.0  
**Last Updated**: April 2026  
**Status**: Ready for Claude Code  
**Reference Document**: descrizione.md

---

## HOW TO USE THIS CHECKLIST

1. Claude Code should read this checklist carefully
2. Reference the corresponding sections in `descrizione.md` for detailed requirements
3. Work through phases sequentially (Phase 1 → Phase 2 → Phase 3, etc.)
4. After completing each task, mark it with ✅ or ❌ in the checkbox
5. If a task is blocked or needs clarification, mark with ⚠️ and add a note
6. At the end of each phase, add a "Phase X Summary" comment

---

## PHASE 1: FOUNDATION (Core Models & Basic UI)

> **Stack adaptation**: this repo is a frontend-only prototype (React via CDN +
> Babel-standalone, no backend, no database, no test runner). Every task below
> is implemented against the in-memory `PI_DATA` namespace in
> `project/src/data.js`. Tasks that require a backend / DB / test framework are
> marked ⚠️ with the reason; their intent is satisfied by the frontend helpers
> where possible.

### 1.1 Data Models

- [x] ✅ **1.1.1** Create `Vehicle` model
  - Fields: id, portfolio_id, parent_vehicle_id (nullable), name, description, created_at, updated_at
  - Relations: belongs_to Portfolio, belongs_to Vehicle (parent), has_many Vehicles (children)
  - Notes: `parent_vehicle_id` NULL means this is a root/master vehicle
  - Reference: Part 11.1.1 in descrizione.md
  - **Impl**: `VEHICLE_TREE` in `src/data.js` already carries `{ id, name, desc, kind, parentId }` for V-01…V-14 and points to `CL-ROOT` for the apex; `parentId === "CL-ROOT"` is the equivalent of "no parent vehicle". `created_at` / `updated_at` are omitted (prototype). The `CLIENTS` array holds the portfolio apex.

- [x] ✅ **1.1.2** Create `AssetPosition` model
  - Fields: id, vehicle_id, asset_type (enum), symbol_or_name, quantity, current_value, acquisition_date, cost_basis, acquisition_details (JSON), created_at, updated_at
  - Relations: belongs_to Vehicle
  - Asset types: cash, bonds, stocks, etfs, hedge_funds, secondary_funds, primary_funds
  - Notes: For bonds, acquisition_details should include maturity_date, coupon_rate, coupon_frequency
  - **Impl**: existing `FUNDS` rows act as AssetPositions (every row has `id`, `vehicleId`, `assetType`, `name`, `ticker`, `nav` ≡ current_value, `purchaseDate` ≡ acquisition_date, `purchasePrice` ≡ cost_basis). Added:
    - **`cash` asset type** (new in `ASSET_TYPES`), seeded per leaf vehicle (`CSH-V01…CSH-V14`).
    - **`acquisition_details`** JSON on each bond seed (`maturity_date`, `coupon_rate`, `coupon_frequency`, `ytm`) and on `createAssetPosition` when provided.
    - **`SPEC_ASSET_TYPES`** canonical 7-type order, plus `SPEC_TO_INTERNAL` / `INTERNAL_TO_SPEC` translation maps. Internal IDs kept for back-compat; spec IDs used by the Liquidity module.

- [ ] ⚠️ **1.1.3** Create migration files — **Skipped**: no database in this prototype. The "schema" is the shape of the objects in `PI_DATA`, documented inline in `src/data.js`. Real backend would materialise this as two tables (`vehicles`, `asset_positions`) per descrizione.md §11.1.1/11.1.2.

- [x] ✅ **1.1.4** Add Vehicle repository/service
  - `getVehicleById(id)` — aliased to existing `vehicleById`
  - `getVehiclesByPortfolioId(portfolio_id)` — returns roots + all descendants under a `CL-*` client node
  - `getVehicleHierarchy(root_vehicle_id)` — returns nested tree `{ id, name, parent_id, children, children_count }`, accepts either a portfolio id (`CL-ROOT`) or a vehicle id
  - `createVehicle(portfolio_id, parent_id, name, description)` — mints `V-NN`, pushes onto `VEHICLE_TREE`
  - `updateVehicle(id, name, description)` — mutates in place
  - `deleteVehicle(id)` — rejects if the vehicle has children *or* direct asset positions (per descrizione.md §2 "has-many" invariant)

- [x] ✅ **1.1.5** Add AssetPosition repository/service
  - `getAssetPositionsByVehicleId(id)` — aliased to existing `assetsOfVehicle`
  - `createAssetPosition(vehicleId, assetType, symbolOrName, quantity, currentValue, extra)` — mints `POS-NNNN`, carries `acquisition_details`, back-fills NAV/cost/metadata fields so the row works with existing tables & charts
  - `updateAssetPosition(id, patch)` — updates quantity / current_value / acquisition_details
  - `deleteAssetPosition(id)` — removes from `FUNDS`
  - `calculateVehicleComposition(vehicleId)` — look-through across descendants; returns `{ totalValue, valueBySpecType, pctBySpecType, valueByInternalType, positions }` keyed by the spec's 7 asset types

### 1.2 API Endpoints (Backend)

> ⚠️ **Section-wide adaptation**: no backend exists. Each endpoint's *intent* is
> satisfied by the corresponding frontend helper on `window.PI_DATA` (already
> implemented in 1.1.4/1.1.5). The function signatures below map 1:1 to the
> REST surface described in descrizione.md §11 and can be wrapped in a real
> controller without refactoring.

- [x] ⚠️ **1.2.1** GET /api/portfolios/{portfolio_id}/vehicles → `PI_DATA.getVehicleHierarchy(portfolioId)` returns the nested tree shape `[{ id, name, parent_id, children, children_count }]` requested.
- [x] ⚠️ **1.2.2** GET /api/vehicles/{vehicle_id} → `PI_DATA.getVehicleById(id)` + `PI_DATA.getAssetPositionsByVehicleId(id)` + `PI_DATA.calculateVehicleComposition(id)` compose the detail payload.
- [x] ⚠️ **1.2.3** POST /api/vehicles → `PI_DATA.createVehicle(portfolioId, parentId, name, desc)`.
- [x] ⚠️ **1.2.4** PUT /api/vehicles/{vehicle_id} → `PI_DATA.updateVehicle(id, name, desc)`.
- [x] ⚠️ **1.2.5** DELETE /api/vehicles/{vehicle_id} → `PI_DATA.deleteVehicle(id)` enforces the "no children + no direct positions" invariant by throwing.
- [x] ⚠️ **1.2.6** POST /api/vehicles/{vehicle_id}/asset-positions → `PI_DATA.createAssetPosition(vehicleId, assetType, symbolOrName, quantity, currentValue, { acquisition_date, cost_basis, acquisition_details })`. Validation (asset_type is one of `ASSET_TYPES`, vehicle must exist) is expressed at call-sites — the helper will fail fast if the caller passes an unknown type.
- [x] ⚠️ **1.2.7** GET /api/vehicles/{vehicle_id}/composition → `PI_DATA.calculateVehicleComposition(id).pctBySpecType` returns the `{ cash, bonds, stocks, etfs, hedge_funds, secondary_funds, primary_funds }` percentages from descrizione.md §3.

### 1.3 Frontend - Liquidity Management Tab

- [x] ✅ **1.3.1** Create "Liquidity Management" tab component
  - **Impl**: new `src/liquidity.jsx` (`window.PI.LiquidityTab`). Wired into `src/detail.jsx` as a third option on the existing Table ⇄ Universe ⇄ **Liquidity** view toggle (same affordance as the other portfolio views). 3-section layout: Section A and B live in a two-column grid (`.liq-grid`), Section C spans full width below.

- [x] ✅ **1.3.2** Section A: Vehicle Hierarchy Visualization (`LiquidityTree`)
  - Compact SVG tree (tighter than Universe View so it fits the split column), same parent-child edges. Click or Enter/Space on a vehicle → the right-hand Details Panel updates, active node highlighted in gold.

- [x] ✅ **1.3.3** Section A: Vehicle Details Panel — `VehicleDetailsPanel`
  - Name, breadcrumb ancestry, "Level N of M" computed from `getVehicleAncestry`. Two KPI tiles (cash + portfolio value) each with a 14-month sparkline rendered from `VEHICLE_SERIES`. Close button resets selection.

- [x] ✅ **1.3.4** Vehicle Details Panel: Current Composition — `CompositionPie`
  - Donut pie built inline in SVG with hover `<title>` tooltips showing `$` + `%`. 7-colour palette drawn from `ASSET_TYPES` (via `SPEC_TO_INTERNAL`). Companion table lists Asset type | Value | Share. (Per-row P&L sort is deferred — the existing model tracks NAV not position-level cost basis for all rows.)

- [x] ✅ **1.3.5** Vehicle Details Panel: Cashflow Waterfall — `CashflowWaterfall`
  - Columns Type | Amount | Date | Source / destination. Period selector (1M / 3M / 1Y / All) derived from `VEHICLE_SERIES`. Direction icon (↓ in / ↑ out) with colour coding. Rows auto-sorted newest first; paginates at 20 with a "+N more" footer.

- [x] ✅ **1.3.6** Vehicle Details Panel: Asset-Specific Details — `AssetSpecificSections`
  - `<details>/<summary>` expandable blocks per asset type. Cash → account/currency/balance. Hedge funds → value + next window + notice-end + remaining cap + status badge. Bonds → coupon %, frequency, next coupon (estimated from `acquisition_details`), maturity, YTM. Stocks & ETFs → name/ticker/value. Secondary / Primary → vintage, stage, GP, value.

- [x] ✅ **1.3.7** Section B: Vehicle Selector
  - `PI.Dropdown` listing every vehicle (id + description). Picking from the dropdown also syncs the tree selection, and clicking a tree node syncs the dropdown.

- [x] ✅ **1.3.8** Section B: Strategy Overview — `StrategyConfigPanel`
  - Shows assigned strategy name + description + "Last modified" timestamp. If no strategy is assigned, renders an inline warning with a **Create strategy** call-to-action. "Edit strategy" button surfaces Phase 2's full editor (toast placeholder). Below: four preset cards (Conservative / Balanced / Growth, plus Auto-optimize excluded from the grid) that can assign a strategy inline.

- [x] ✅ **1.3.9** Section C: Action Buttons — `LiquidityActions`
  - Sticky bar at the bottom of the tab: **Run immediate forecast** (reuses the existing `onImmediateForecastRun` pipeline) + **Run simulation** (opens the existing forecast launch modal via `onStartForecast`). Both wire into the current app's forecast/simulation flows so the results screens light up exactly as they already do elsewhere.

### 1.4 Data Integration (Cashflow Projection)

- [x] ✅ **1.4.1** `PI_DATA.projectCashflows(vehicleId, startIso, endIso)` — aggregates monthly rows from `VEHICLE_SERIES` across the vehicle + all descendants, clips to the requested window, and returns `[{ period, contribution, distribution, capital_call, capital_drawdown, net_cashflow }]` in YYYY-MM buckets. Contributions/drawdowns are stored as positive magnitudes in this output (directionality is encoded in the field name, matching the spec), while `net_cashflow` preserves sign. Phase 1 is deterministic; Phase 4 will add Monte-Carlo variance.

- [x] ✅ **1.4.2** `PI_DATA.calculateVehicleComposition(vehicleId)` — look-through across descendants. Returns `{ totalValue, valueBySpecType, pctBySpecType, valueByInternalType, positions }` keyed by all 7 spec asset types (`cash`, `bonds`, `stocks`, `etfs`, `hedge_funds`, `secondary_funds`, `primary_funds`). The LiquidityTab consumes this for the donut pie, the composition table, and the tree-node tooltips.

- [x] ✅ **1.4.3** Parent-child helpers
  - `PI_DATA.getParentVehicleId(id)` — string or null (null when parent is the portfolio root or vehicle is unknown)
  - `PI_DATA.getChildVehicles(id)` — aliased to existing `childrenOf`
  - `PI_DATA.getVehicleAncestry(id)` — returns `[root, …, parent, self]` walking up through `VEHICLE_TREE` and into `CLIENTS` so the breadcrumb in the Details Panel shows `Portfolio › V1 › V3 › V8`.

### 1.5 Testing (Phase 1)

> ⚠️ **Section-wide adaptation**: no JS test runner is configured in this repo
> (the HTML loads React/Babel from CDNs and transpiles on the fly). Verification
> is manual via the browser. Each sub-item below documents the manual test
> equivalent to perform after loading `project/Predictive Intelligence.html`.

- [x] ⚠️ **1.5.1** Vehicle model manual checks
  - In DevTools console: `PI_DATA.getVehicleHierarchy("CL-ROOT")` returns nested tree rooted at *Cepres Example Portfolio* with V-01 / V-02 as direct children.
  - `PI_DATA.createVehicle("CL-ROOT", "V-01", "V15", "Test sleeve")` returns a `V-15` object and `PI_DATA.VEHICLE_TREE.length` grows by one.
  - `PI_DATA.deleteVehicle("V-01")` throws (has children). `PI_DATA.deleteVehicle("V-15")` succeeds (cleanup).
- [x] ⚠️ **1.5.2** AssetPosition model manual checks
  - `PI_DATA.getAssetPositionsByVehicleId("V-13")` lists the four seeded bonds + the ETF + the cash account.
  - `PI_DATA.calculateVehicleComposition("V-01").pctBySpecType` sums to ~1.0 across the 7 spec keys.
  - `PI_DATA.createAssetPosition("V-13", "bond", "Test 5Y", 100, 50, { acquisition_details: { maturity_date: "2031-01-01", coupon_rate: 0.04, coupon_frequency: "annual" } })` returns a new `POS-*` row.
- [x] ⚠️ **1.5.3** API integration tests → exercised through the helper layer per §1.2 adaptation.
- [x] ⚠️ **1.5.4** Frontend component checks
  - Navigate to any portfolio → flip the Table/Universe/Liquidity toggle to **Liquidity** → the tree renders with V-01…V-14 + the portfolio apex; clicking V-08 populates the Details Panel with composition, waterfall, and the expandable asset sections. Selecting a vehicle in the Section B dropdown highlights the matching tree node.

### 1.6 Phase 1 Summary

- [x] ✅ Data models materialised in `PI_DATA` (`VEHICLE_TREE`, `FUNDS` with `cash` type + bond `acquisition_details`); migrations N/A (no DB).
- [x] ✅ Repository helpers for vehicles + asset positions + composition + projection + ancestry exposed on `window.PI_DATA`.
- [x] ✅ Liquidity Management tab renders without errors as a third option on the Portfolio Detail view toggle.
- [x] ✅ Hierarchy visualisation, composition pie, cashflow waterfall, and asset-specific expandable sections all display correctly for seeded data.
- [x] ⚠️ Automated tests skipped (no runner); manual checks documented above.

**Phase 1 Status**: ✅ **Complete** (with the stack-adaptation caveats noted in §1.2 and §1.5).

**Notes / deviations from spec**:
- Palette: the spec calls for Material (#2196F3, #4CAF50, …) but the repo is governed by the Cepres Design System (MEMORY.md). The 7 asset types now use Cepres-compatible colours (dawn, teal, gold, green, plum, slate-blue, sage). Semantic signalling (red for insolvency, gold for "attention needed") is preserved.
- Existing `coinvestment` type is retained alongside the 7 spec types and rolls up into `primary_funds` in the Liquidity composition view, so the co-invest seed rows are not lost.
- The Portfolio Detail view already uses a **Table ⇄ Universe ⇄ Liquidity** segmented toggle rather than a tab bar; the spec's "Liquidity Management tab" maps to the new third segment rather than introducing a parallel navigation pattern.
- Strategy editor (`[Edit Strategy]`) currently emits a toast pointing to Phase 2; the inline preset picker in Section B assigns a strategy to the selected vehicle so the flow remains testable end-to-end.

---

## PHASE 2: STRATEGY CONFIGURATION (Constraints & Rules)

> **Stack adaptation (as in Phase 1)**: no backend / DB / test runner. Models
> are in-memory arrays on `PI_DATA`; API endpoints are satisfied by matching
> helper functions. Tests → manual DevTools checks.

### 2.1 Data Models

- [x] ✅ **2.1.1** Create `LiquidityStrategy` model
  - **Impl**: `PI_DATA.LIQUIDITY_STRATEGIES` array in `src/data.js`. Each entry carries every field listed in descrizione.md §11.1.3 (`id`, `vehicle_id`, `name`, `description`, `is_preset`, `is_reusable`, `liquidation_priority`, `is_proportional`, `rebalancing_frequency`, `rebalancing_trigger`, `rebalancing_target_allocation`, `rebalancing_tolerance_pct`, `min_cash_reserve_pct`, `min_cash_reserve_percentile`, `created_at`, `updated_at`). `vehicle_id === null` means it is a preset. Constraints are stored on a separate table and looked up via `strategy_id` (see 2.1.2).

- [x] ✅ **2.1.2** Create `AssetTypeConstraint` model
  - **Impl**: `PI_DATA.ASSET_TYPE_CONSTRAINTS` array, joined to the strategy by `strategy_id`. Carries `asset_type` (spec key), `redemption_frequency`, `notice_period_days`, `max_redemption_pct_per_period`, `annual_redemption_cap_by_year` (JSON map `{ year: cap }`), `estimated_liquidation_timeline_months`, `max_liquidation_pct_per_year`, `exclude_from_liquidation` (array of position ids), plus `id` / `created_at` / `updated_at`.

- [ ] ⚠️ **2.1.3** Migration files — **Skipped**: no database. Real backend would materialise this as two tables (`liquidity_strategies`, `asset_type_constraints`) with FK on `strategy_id` and indexes on `vehicle_id` / `asset_type`.

### 2.2 Preset Strategies (Database Seeding)

- [x] ✅ **2.2.1** Seed default preset strategies
  - **Impl**: four rows in `LIQUIDITY_STRATEGIES` marked `is_preset: true, is_reusable: true` (`STRAT-CONS`, `STRAT-BAL`, `STRAT-GROWTH`, `STRAT-AGG`). Allocations exactly match the spec:
    - Conservative: Cash 30 / Bonds 40 / Stocks 20 / Hedge 10
    - Balanced: Cash 15 / Bonds 35 / Stocks 35 / Hedge 15
    - Growth: Cash 10 / Bonds 20 / Stocks 50 / Hedge 20 (`trigger: tolerance, ±5%`)
    - Aggressive: Cash 5 / Stocks 60 / Hedge 35 (`trigger: tolerance, ±7%`)
  - Each preset ships with three constraints seeded automatically: standard HF (`quarterly, 30d notice, 20%/period, no cap`), Secondary (`48 months timeline, 25%/year`), Primary (redemption disabled by default).

### 2.3 API Endpoints (Strategy CRUD)

> ⚠️ **Section-wide adaptation**: no backend. Each endpoint's intent is
> satisfied by the matching helper on `window.PI_DATA`. Signatures below map
> 1:1 to the REST surface in descrizione.md §11.

- [x] ⚠️ **2.3.1** GET /api/liquidity-strategies/presets → `PI_DATA.getPresetStrategies()` returns the four preset rows.
- [x] ⚠️ **2.3.2** GET /api/vehicles/{vehicle_id}/strategy → `PI_DATA.getStrategyByVehicleId(id)`. Returns `null` when unassigned; otherwise returns the strategy merged with `constraints: [...]`.
- [x] ⚠️ **2.3.3** POST /api/vehicles/{vehicle_id}/strategy → `PI_DATA.createStrategy(vehicleId, payload)`. Runs `validateStrategy(payload)`; throws with `error.errors` populated when validation fails (equivalent to an HTTP 400 with a structured body).
- [x] ⚠️ **2.3.4** PUT /api/vehicles/{vehicle_id}/strategy → `PI_DATA.updateStrategy(strategyId, payload)`. Same validation. Replaces the constraint set atomically.
- [x] ⚠️ **2.3.5** DELETE /api/vehicles/{vehicle_id}/strategy → `PI_DATA.deleteStrategy(strategyId)`. Hard delete; also unassigns any vehicles that pointed to it and removes all its constraints.
- [x] ⚠️ **2.3.6** GET /api/liquidity-strategies/{strategy_id}/apply-to-vehicles → `PI_DATA.applyStrategyToVehicles(strategyId, [vehicleIds])`. Clones the source strategy (including constraints) onto each target vehicle and returns the created records. Used by the preset cards in Section B.

### 2.4 Frontend - Strategy Editor Modal

- [x] ✅ **2.4.1** Strategy Editor Modal component
  - **Impl**: `src/strategyEditor.jsx` exports `window.PI.StrategyEditorModal`. Modal uses the existing `.modal modal-xl` shell (same DOM contract as `EditFundModal`), with a three-section body (priority list / rebalancing rules / save). Triggered from `StrategyConfigPanel` via the `[Edit / Create strategy]` button. Loaded in `Predictive Intelligence.html` before `liquidity.jsx` so `PI.StrategyEditorModal` exists when `LiquidityTab` mounts.

- [x] ✅ **2.4.2** Part 1 — Liquidation Priority List
  - **Impl**: `PriorityList` component with native HTML5 drag-and-drop (no third-party library). Each row renders `☰ | rank | Asset Type | Constraints… | Remove`, with a gold highlight on the drop target during drag. Keyboard fallback: ↑ / ↓ on the drag handle reorders (a11y). Remove is disabled when only one asset type remains. `[+ Add asset type]` opens a dropdown of currently-removed types. The Proportional Liquidation checkbox disables the list (dims + blocks pointer events) when enabled.

- [x] ✅ **2.4.3** Constraint Editor Popup
  - **Impl**: `ConstraintEditorPopup` — a nested modal (z-index: 100/110) that stacks above the main editor. Body is per-asset-type:
    - **Cash**: info banner only ("Fully liquid, instant liquidation").
    - **Bonds / Stocks / ETFs**: info banner + "Exclude specific …" checkbox; when enabled, lists the vehicle's positions (id / name / NAV) with per-row checkboxes → writes `exclude_from_liquidation: [posId, …]`.
    - **Hedge Funds**: redemption-frequency radio group (5 options), notice-period (days), max-per-period (%), annual-cap toggle between "same every year" (single %) and "varies by year" (editable year → cap table with Add/Remove). Live status row: "Max redemption in 2026: X%".
    - **Secondary Funds**: timeline (months) + max % per year, with a derived "fully exited in ~N years" indicator.
    - **Primary Funds**: info banner + "Allow redemption" checkbox; when enabled, exposes timeline + max % per year (useful for co-invests per spec §5.1.2).

- [x] ✅ **2.4.4** Part 2 — Rebalancing Rules
  - **Impl**: `RebalancingRulesSection`. Three radio cards (Maintain Target / Tolerance Band / Minimum Cash Reserve). For Fixed & Tolerance: an editable 7-row Target Allocation table with live total that turns red when it deviates from 100%. Tolerance trigger adds a ± % field. Min Cash trigger exposes either a % input *or* a percentile dropdown (P5…P95) — they are mutually exclusive (selecting a percentile disables the numeric input). Frequency row shows the fixed "Annual (at year-end)" pill plus an "Apply on specific date (MM-DD)" toggle (spec calls this optional; the canonical `rebalancing_frequency` field remains `"annual"` so no schema leakage).

- [x] ✅ **2.4.5** Part 3 — Save Strategy
  - **Impl**: `SaveStrategySection` — required Name input (shows `field-error` if blank), optional Description, and the "Make reusable across other vehicles" checkbox. On Save, the modal passes the payload up to `LiquidityTab.handleSaveStrategy`, which routes to `PI_DATA.createStrategy` or `PI_DATA.updateStrategy` (the distinction is based on whether a non-preset strategy is already attached to the vehicle — preset assignments always produce a fresh clone instead of mutating the preset). On success the modal closes, `tick` is bumped, and `StrategyConfigPanel` re-reads the current strategy from `PI_DATA.getStrategyByVehicleId`. Toast confirms the action.

- [x] ⚠️ **2.4.6** Strategy templates/presets selection
  - Partially satisfied: the spec marks this step as **Optional**, and the preset affordance already lives in Section B as a grid of four cards ("Conservative / Balanced / Growth / Aggressive"). Clicking a preset card clones that preset onto the selected vehicle via `applyStrategyToVehicles`. A modal-level radio ("Use preset / Create custom") was deliberately skipped for now to avoid duplicating the Section-B affordance. If the preset-card UX proves insufficient a future iteration can add the radio as a shortcut inside the modal.

### 2.5 Validation & Error Handling

- [x] ✅ **2.5.1** Validate liquidation_priority — `PI_DATA.validateStrategy` enforces: at least one asset type; no duplicates; every entry ∈ `SPEC_ASSET_TYPES`. Skipped when `is_proportional === true`.
- [x] ✅ **2.5.2** Validate rebalancing_target_allocation — sums to 100 ± 0.01% for Fixed & Tolerance triggers; no negative percentages.
- [x] ✅ **2.5.3** Validate constraints
  - Hedge Funds: `notice_period_days ≥ 0`; `0 < max_redemption_pct_per_period ≤ 100`; every entry in `annual_redemption_cap_by_year` ∈ [0, 100].
  - Secondary / Primary: `estimated_liquidation_timeline_months > 0`; `0 < max_liquidation_pct_per_year ≤ 100`.
  - Errors bucket under `errors.constraints[asset_type]` so the constraint popup can surface field-level messages.
- [x] ✅ **2.5.4** Inline validation feedback
  - Field-level red messages render via the existing `PI.Field` `error` prop. The Save button reads `canSave = Object.keys(liveErrors).length === 0` so it disables in real time. Footer status line flips between "Ready to save." (green) and "N fields need attention" (red). Save attempt with errors shows a toast and highlights the offending section. Success fires a success toast.

### 2.6 Testing (Phase 2)

> ⚠️ **Section-wide adaptation**: no JS test runner. Manual DevTools verifications documented below.

- [x] ⚠️ **2.6.1** Strategy model manual checks
  - `PI_DATA.getPresetStrategies().length === 4`; each has `is_preset === true` and a non-empty `rebalancing_target_allocation`.
  - `PI_DATA.getConstraintsByStrategyId("STRAT-CONS")` returns three rows (hedge / secondary / primary).
  - `PI_DATA.createStrategy("V-08", { name: "Test", liquidation_priority: ["cash","bonds"], is_proportional: false, rebalancing_trigger: "fixed", rebalancing_target_allocation: { cash: 50, bonds: 50, stocks: 0, etfs: 0, hedge_funds: 0, secondary_funds: 0, primary_funds: 0 }, constraints: [] })` returns a `STRAT-V*` record and sets `PI_DATA.VEHICLE_STRATEGY_ASSIGNMENTS["V-08"]`.
  - `PI_DATA.createStrategy("V-08", { ..., rebalancing_target_allocation: { cash: 80, bonds: 10 } })` throws with `err.errors.rebalancing_target_allocation` describing the 100% violation.
- [x] ⚠️ **2.6.2** API-equivalent integration checks — exercised through the helper layer per §2.3 adaptation. `PI_DATA.applyStrategyToVehicles("STRAT-BAL", ["V-09","V-10"])` returns two cloned strategies.
- [x] ⚠️ **2.6.3** Frontend component checks
  - Open the portfolio → flip to **Liquidity** → select V-08 → click `[Create strategy]`. The modal opens with default values.
  - Drag row 2 ("Bonds") above row 1 ("Cash") in the priority list → order persists and the rank column updates. Focus the handle and press ↓ to verify keyboard reorder.
  - Click "Constraints…" next to Hedge Funds → nested popup opens; switch to "Varies by year" → table gains a row; save. The main modal is still intact behind.
  - Switch to "Minimum Cash Reserve" trigger → target table hides, min-cash inputs appear, save button disables until either % or percentile is picked.
  - Clear the Name input → save button disables and footer shows "1 field needs attention".
  - Click a preset card in Section B (outside the modal) → current strategy updates inline; "Last modified" timestamp refreshes.

### 2.7 Phase 2 Summary

- [x] ✅ LiquidityStrategy + AssetTypeConstraint materialised on `PI_DATA`; migrations N/A (no DB).
- [x] ✅ Four preset strategies seeded with the standard HF + secondary + primary constraints per spec §2.2.1.
- [x] ✅ Strategy CRUD helpers (`getPresetStrategies`, `getStrategyByVehicleId`, `createStrategy`, `updateStrategy`, `deleteStrategy`, `assignStrategyToVehicle`, `applyStrategyToVehicles`) exposed on `window.PI_DATA`.
- [x] ✅ Strategy Editor Modal (priority list with DnD + constraints popup + rebalancing rules + save) wired into `LiquidityTab`.
- [x] ✅ Validation enforced on save and inline; save button disables when invalid; toasts on success / error.
- [x] ⚠️ Automated tests skipped (no runner); manual DevTools checks documented above.

**Phase 2 Status**: ✅ **Complete** (with the stack-adaptation caveats noted in §2.1.3, §2.3, §2.6).

**Notes / deviations from spec**:
- The strategy-editor-level "preset vs custom" radio (§2.4.6) was not added, because Section B already hosts the preset card grid and the spec flags that radio as optional. Presets clone via `applyStrategyToVehicles`, producing independently-editable non-preset copies.
- `rebalancing_frequency` remains the enum `"annual"` per the data model. The "Apply on specific date" checkbox is captured in modal state but intentionally not stored on the canonical strategy until Phase 3 consumes it (avoids leaking speculative schema fields).
- Drag-and-drop uses the native HTML5 DnD API rather than `react-beautiful-dnd` (zero dependencies, fits the CDN+Babel runtime). Keyboard reorder via Arrow keys is provided as an a11y equivalent.
- Preset card selection is additive (always clones) rather than replacing — the previous custom strategy, if any, becomes orphan data. Acceptable for the prototype; a real backend would garbage-collect unassigned non-reusable strategies.

---

## PHASE 3: IMMEDIATE FORECAST (Mean Results)

> **Stack adaptation**: no backend / DB / test runner. Projection services
> live on `window.PI_DATA` in `project/src/data.js`; the results page is a
> view-switch inside the Liquidity tab (no client-side routing). All 5
> charts are hand-drawn inline SVG (no charting library), following the
> established `CompositionPie` / sparkline pattern.

### 3.1 Backend - Forecast Engine

- [x] ✅ **3.1.1** Cashflow projection service
  - **Impl**: `PI_DATA.projectCashflows(vehicleId, startIso, endIso)` already existed from Phase 1 §1.4.1. Phase 3 extends it indirectly via `_cashflowForMonth(ids, monthKey, monthIdx)` which **prefers seeded `VEHICLE_SERIES` rows, falls back to deterministic synthetic patterns for months beyond the seed window** — so a 10-year projection feels continuous with historical data. Output shape matches spec: `{ period, contribution, distribution, capital_call, capital_drawdown, net_cashflow }`. Mean-only / deterministic per spec note for Phase 3.

- [x] ✅ **3.1.2** Portfolio valuation projection service
  - **Impl**: `PI_DATA.projectPortfolioValue(vehicleId, startIso, endIso, strategy)`. Monthly granularity. Each period: start_value → apply cashflow (absorbed into the cash bucket) → 0% growth/decline on other assets (per spec) → evaluate rebalancing trigger from strategy → if triggered, shift allocations to target and record a `rebalancingEvents` entry with per-asset `{fromPct, toPct, delta}` changes. Supports all three strategy triggers defined in Phase 2: `fixed` (annual in January, 12-month cooldown), `tolerance` (drift > `rebalancing_tolerance_pct`), `min_cash` (cash falls below `min_cash_reserve_pct`). Vehicles without a strategy get a flat projection (no rebalancing).

- [x] ⚠️ **3.1.3** API endpoint for Immediate Forecast
  - **Skipped (no backend)**. The intent is satisfied by `PI_DATA.projectLiquidityForecast(vehicleId, opts)`. Opts: `{ startDate, endDate, currency, stressTestId }`. Returns canonical shape: `{ generated_at, request_params, vehicleId, vehicleName, strategy, periods, rebalancingEvents, summary, relationships }`. `summary` carries the 6 KPI values plus insolvency period count and total flows for each of the 4 categories. `relationships` carries `{ parent, children }` for §3.2.10. Status codes map to JS exceptions (caller's try/catch).

### 3.2 Frontend - Immediate Forecast Results Page

- [x] ✅ **3.2.1** Results page component
  - **Impl**: `PI.LiquidityForecastResults` in `src/liquidityForecast.jsx`. Rendered *inline within the Liquidity tab* (`LiquidityTab` view-switches between the main grid and the results view based on `forecastResult` state). No client-side routing in this prototype; the results view has a `[Back to Liquidity]` button + a `[Reconfigure]` button in the header.

- [x] ⚠️ **3.2.2** Tabbed vehicle view — **Partial**. A single-vehicle results view is rendered. The vehicle is selected in the config modal dropdown (§3.3.1). No "All Vehicles" aggregate tab and no per-child tabs; the config modal lets the user pick any vehicle in the tree, so the UX gap is compensated via reconfigure. Deferred because: (a) building persistent per-tab state would balloon the component; (b) the `Relationships` section (§3.2.10) already shows aggregated per-child flows in the same view. Real multi-tab aggregation would need a broader state refactor.

- [x] ✅ **3.2.3** Chart 1 — Portfolio value over time (line)
  - **Impl**: `ChartValue` component, inline SVG 640×240. Blue `#2196F3` line. Y-axis: nice-rounded max from period data. X-axis: year labels (ticks at January + first + last periods so the first year is always shown even if the start date is mid-year). Per-point hover circles appear on `<svg>:hover` with native `<title>` tooltips (`YYYY-MM-DD · Value: $X`). Nice-max auto-ticks at 0 / 25 / 50 / 75 / 100% of the range.

- [x] ✅ **3.2.4** Chart 2 — Cash balance over time (line + zones)
  - **Impl**: `ChartCash`. Green `#4CAF50` line for cash balance. Light green zone above the `minCashTarget` (when the strategy specifies `min_cash_reserve_pct`). Light red zone below zero for insolvency periods; a bold red zero-line appears only when the range crosses zero. Dashed green target line. Points switch fill to red below zero. Hover tooltip includes target min.

- [x] ✅ **3.2.5** Chart 3 — Asset allocation over time (stacked area, $/% toggle)
  - **Impl**: `ChartAllocation`. Pills toggle between `%` (default, 0–100 scale) and `$` (nice-max scale). 7 stacked paths in canonical SPEC order (cash → bonds → stocks → etfs → hedge_funds → secondary_funds → primary_funds), each filled with the corresponding `assetTypeMeta(...).color` from the design-system palette — consistent with the CompositionPie colours elsewhere in the Liquidity tab. Legend below the chart.

- [x] ✅ **3.2.6** Chart 4 — Capital flows (grouped bar)
  - **Impl**: `ChartFlows`. Annual aggregation (yearly bars for readability at 10-year horizons). 4 bars per year: distributions (green, above axis), capital calls (teal, above), contributions (blue, below), capital drawdowns (orange, below). Y-axis symmetric around zero. Native `<title>` tooltips per bar with the category label + amount. Legend below.

- [x] ✅ **3.2.7** Chart 5 — Rebalancing events timeline
  - **Impl**: `ChartRebalancing`. Horizontal axis with year ticks. Each event renders as a gold pin (`#E5AD00`) with a dropped line to the timeline. Hover shows the date + the top 3 changed asset types (`assetType: fromPct%→toPct%`). Empty-state message when no events projected.

- [x] ✅ **3.2.8** Summary KPI cards
  - **Impl**: `KpiCards`. 6 cards in a 6-column grid (collapses to 3 cols @1300px, 2 cols @720px): Current portfolio value, Current cash balance, End-of-period value, Minimum cash during period (hint: `on YYYY-MM`, coloured red if insolvency hit / gold if below target / green otherwise), Rebalancing events, Strategy compliance (green "On target" / gold "Off target by X%"). Each card carries a left-border accent (gold/green/red) reflecting the status.

- [x] ✅ **3.2.9** Detailed cashflow table (collapsible)
  - **Impl**: `CashflowTable`. Collapsible header with rotating chevron. 8 columns per spec (Period / Start / Contributions / Distributions / Capital calls / Capital drawdowns / Rebalancing / End). Paginated at 20 rows per page with Prev/Next buttons. Rebalancing column renders a gold `tag` pill on rebalanced rows. Sorting by column is deferred — default period-ascending order matches the natural month-by-month narrative.

- [x] ✅ **3.2.10** Parent / Child relationships section
  - **Impl**: `Relationships`. Conditional: hidden entirely if the vehicle has neither a parent nor children. Parent block shows name + capital calls made to parent + capital drawdowns received. Children table shows name + contributions received + distributions sent + capital calls made + capital drawdowns sent. Computed on the fly from `projectCashflows(childId, …)` aggregations — no extra state in the UI.

### 3.3 Frontend - Forecast Configuration Modal

- [x] ✅ **3.3.1** Configure Immediate Forecast modal
  - **Impl**: `PI.LiquidityForecastConfigModal` in `src/liquidityForecast.jsx`. Standard `modal-wrap` / `modal modal-md` layout. Fields: Currency (USD/EUR/GBP Dropdown), Stress test (None + PI_DATA.STRESS_TESTS Dropdown), Start date (native `<input type="date">`, default today), End date (default +10 years), Vehicle (Dropdown over `VEHICLE_TREE` excluding CL- clients, default = currently-selected vehicle in the Liquidity tab). Buttons: `[Cancel]` / `[Run forecast]`. On click → `PI_DATA.projectLiquidityForecast(cfg.vehicleId, cfg)` → set results state → switch to results view.

- [x] ✅ **3.3.2** Validation
  - **Impl**: Live `errors` object computed on every render. Rules: currency required, startDate required, endDate required, endDate > startDate, vehicle required. Errors surface through the existing `PI.Field.error` prop (red inline under the input). Footer status line mirrors the pattern from Phase 2's strategy editor: "Ready to run." (green) / "N fields need attention." (red). Run button is disabled until `canRun`.

### 3.4 Testing (Phase 3)

- [x] ⚠️ **3.4.1** Unit tests for projection services — **No test runner**. Manual verification steps:
  - Open DevTools console on the Liquidity tab
  - `PI_DATA.projectCashflows("V-08", "2026-04", "2027-04")` → array of ~12 monthly rows, each with the 5 canonical fields summing to `net_cashflow`
  - `PI_DATA.projectPortfolioValue("V-08", "2026-04-19", "2036-04-19", PI_DATA.getStrategyByVehicleId("V-08"))` → `{periods, rebalancingEvents}`; verify `periods[i+1].start_value === periods[i].end_value` for all i; verify at least one rebalancing event near a January if the strategy uses `fixed` trigger
- [x] ⚠️ **3.4.2** Integration tests for API endpoints — **No backend**. `PI_DATA.projectLiquidityForecast("V-08")` returns the full shape documented in §3.1.3 above.
- [x] ⚠️ **3.4.3** Frontend component tests — **No component test harness**. Manual verification:
  - Click `[Run immediate forecast]` in Section C of the Liquidity tab
  - Config modal opens, defaults sensible (today → today+10y, USD, current vehicle)
  - Clear the start date → footer turns red, Run button disables
  - Fix and click Run → results view renders with 6 KPI cards, 5 charts (toggle the % / $ pill on the allocation chart), cashflow table expands/paginates, parent/child section appears when a vehicle with parent/children is selected
  - Click `[Back to Liquidity]` → returns to the main grid with state preserved
  - Click `[Reconfigure]` → reopens the config modal with the previous values lost (intentional — fresh config each run)

### 3.5 Phase 3 Summary

- [x] ✅ Cashflow projection service working — `PI_DATA.projectCashflows` + `_cashflowForMonth` synthetic fallback
- [x] ✅ Portfolio valuation projection service working — `PI_DATA.projectPortfolioValue` honours all 3 strategy triggers
- [x] ✅ Endpoint-equivalent helper working — `PI_DATA.projectLiquidityForecast` returns the canonical shape
- [x] ✅ Results page renders 5 charts (portfolio value, cash balance, asset allocation, capital flows, rebalancing timeline)
- [x] ✅ Summary section displays 6 KPI cards with status accents
- [x] ⚠️ Automated tests — not applicable (no test runner); manual verification path documented in §3.4
- [x] ✅ Manual test verified: V-08 (Balanced preset) produces a believable 10-year forecast with quarterly-ish rebalancing events when tolerance-triggered; cashflow table balance identity holds (start + net = end)

**Deviation notes (Phase 3):**
1. **No client-side routing**. The spec's `/portfolios/{id}/forecasts/immediate/{id}` route maps to a view-switch inside the Liquidity tab. The LiquidityTab renders either the main grid OR the results view based on internal state. `[Back]` returns to the grid; `[Reconfigure]` re-opens the config modal.
2. **No multi-vehicle tabs (§3.2.2 partial)**. The config modal's vehicle dropdown is the selection mechanism. The Relationships section (§3.2.10) compensates by showing aggregated per-child flows inline.
3. **Annual aggregation on Chart 4**. Spec allows "grouped bars per period" but 120 monthly bars would be unreadable at 640px width. Annual aggregation preserves the narrative shape while keeping the chart legible. Documented in the chart's subtitle.
4. **No sort on cashflow table**. Fixed period-ascending order. Pagination at 20 rows covers the 120-period default horizon in 6 pages.
5. **Synthetic cashflow extension for months beyond seeded `VEHICLE_SERIES`**. `VEHICLE_SERIES` only carries 36 months (2024-01 → 2026-12). For a 10-year forecast starting today, most months need extrapolation. `_syntheticCashflow` uses the same probability distributions as `buildVehicleSeries` (hash-based, deterministic) so the projection visually continues from the seed pattern without a discontinuity.
6. **No stress-test application yet**. The stress_test_id is accepted, stored in `request_params`, and shown in the results header — but it does not modify the projection values. Flagged for Phase 4/5 follow-up when stress-test model parameters get wired into the Monte Carlo engine.

**Phase 3 Status**: ✅ Complete (with the stack-adaptation caveats noted in §3.1.3, §3.2.2, §3.4)

---

## PHASE 4: SIMULATION (Probabilistic Distributions + Risk Metrics)

### 4.1 Backend - Monte Carlo Simulation Engine

- [x] ✅ **4.1.1** Create stochastic cashflow projection service
  - Adapted to FE prototype: `projectSimulation` in `data.js` produces percentile metrics per period without literal N-iteration sampling. Bands are synthesized as `mean ± z(p)·σ` where σ grows with √t and `stressMult` widens the fan. Output shape matches the spec (P5/P10/P25/P50/P75/P90/P95 for each time period, mean, std_dev implicit in σ) so a real backend can drop in true sampling without the UI changing.
  - Deviation note: literal iterations aren't generated in-browser (50K paths × N periods would freeze the tab). Seed parameter ignored — determinism comes from the closed-form band. Real production path would replace `_expandBand` with true percentile extraction.

- [x] ✅ **4.1.2** Create stochastic portfolio valuation service
  - Implemented inside `projectSimulation` — each enriched period carries `value_percentiles` and `cash_percentiles` (P5..P95), `mean_value`, `mean_cash`. Composition-by-percentile is approximated on the mean allocation path (all percentiles share the mean trajectory); the Asset Allocation heatmap synthesizes per-percentile shares via a `cashBias` factor so the chart reveals structure. Rebalancing-by-percentile uses a `REB_MULT` table scaled by the mean rebalancing count.
  - Deviation note: true per-iteration composition is out of scope for the FE prototype.

- [x] ✅ **4.1.3** Create API endpoint for Simulation
  - Adapted to FE prototype: `PI_DATA.projectSimulation(vehicleId, opts)` replaces the HTTP endpoint. Accepts `{ simulationName, depth ("fast"|"full"), fineTuning (bool), currency, stressTestId, startDate, endDate }`. Validation happens in the config modal (required fields, end > start). `iterations` is set to 1,000 (fast) or 50,000 (full) in `request_params` for display; the synthesized model does not actually loop that many times.
  - Fine-tuning radio option is rendered but disabled (tooltip: "Fine-tuning editor is out of prototype scope.").

- [x] ✅ **4.1.4** Extend SimulationResult model
  - Adapted: the in-memory result object returned by `projectSimulation` is the single source of truth — `{ id, generated_at, request_params, vehicleId, vehicleName, strategy, periods (enriched), rebalancingByPercentile, scenarios, comparisonTable, riskMetrics, relationships, initialTotalValue }`. Persistence layer (DB) is out of scope per user directive ("non mi interessa un BE funzionante").

### 4.2 Backend - Risk Metrics Calculation

- [x] ✅ **4.2.1** Create insolvency risk calculator
  - `calculateInsolvencyRisk(periods)` in `data.js`. Counts percentile scenarios where `cash_percentiles < 0` at any period; returns `{ riskPercentage, scenariosAffected, totalScenarios, criticalDates }`. The internal `_computeRiskMetrics` wraps this for the full suite.

- [x] ✅ **4.2.2** Create excess cash risk calculator
  - `calculateExcessCashRisk(periods, threshold)` — flags percentile scenarios exceeding 50% of portfolio value in cash; returns `{ riskPercentage, scenariosAffected, averageExcess }`.

- [x] ✅ **4.2.3** Create rebalancing frequency analyzer
  - `analyzeRebalancingFrequency(rebalancingByPercentile, periodsCount)` — returns `{ avgPerYear, range: { min, max }, byPercentile }`.

- [x] ✅ **4.2.4** Create cash reserve adequacy analyzer
  - `analyzeCashReserveAdequacy(periods, targetValue)` — returns `{ percentOfTimeAdequate, scenariosFailing, targetValue, suggestion }` (suggestion from the aggregate calculator).

- [x] ✅ **4.2.5** Create strategy feasibility checker
  - `checkStrategyFeasibility(periods)` — simplified prototype rule: a percentile is feasible iff its cash path never goes negative AND doesn't blow past 1.5× the excess-cash threshold. Returns `{ feasiblePercentage, scenariosFailing, constraintViolations }`. Full constraint-matrix enforcement (redemption windows, lockups, concentration) is a future enhancement; the preset constraint violations are surfaced in the Strategy Feasibility risk card.

### 4.3 Frontend - Simulation Results Page

- [x] ✅ **4.3.1** Create Simulation Results Page component
  - Implemented as `PI.LiquiditySimulationResults` in `liquiditySimulation.jsx`. View-switch inside `LiquidityTab` replaces the Liquidity grid entirely when `simResult` is non-null — no client-side routing ("route" is implicit from state). Page title: `${simulation_name} — ${vehicleId · vehicleName}`. Layout mirrors the Immediate Forecast results page (back + reconfigure, risk cards, 2×2 chart grid, comparison table, scenario explorer, relationships). Multi-vehicle "All Vehicles" tab is not implemented — a single vehicle is simulated per run, consistent with the config modal's single-vehicle picker.

- [x] ✅ **4.3.2** Implement configuration display (collapsible header)
  - Header shows simulation name, strategy, depth, iterations, currency, date range, and stress test. Rendered as a single meta-row with dividers (`·`) — not collapsible (full info is visible at a glance; the "View simulation config" modal is the Reconfigure button).

- [x] ✅ **4.3.3** Implement Chart 1: Total Portfolio Value with Distributions (Line + Shaded Bands)
  - `ChartValueFan` — P50 blue line, P25–P75 band (opacity 0.22), P5–P95 wider band (opacity 0.12), dashed P5 and P95 boundary lines. Pill toggle switches between "Bands" view (spec "Show P50 ± 1 std dev") and "All 7 lines" view. Hover tooltip on P50 dots lists all 5 percentile values at that point. Color: `#2196F3` gradients.

- [x] ✅ **4.3.4** Implement Chart 2: Cash Balance with Distributions (Line + Shaded Bands)
  - `ChartCashFan` — same band structure in green (`#4CAF50`), with a red insolvency zone below zero (`#FDECEC` fill) and light-green above-target zone (`#E4F3F2`). Dashed target line if strategy specifies a min_cash_reserve. Sub-title reads "Insolvency risk in X% of scenarios" when any percentile goes negative. Hover tooltip labels percentiles as "risk / expected / best".

- [x] ✅ **4.3.5** Implement Chart 3: Asset Allocation Over Time (Heatmap)
  - `ChartAllocationHeatmap` — Option A heatmap implementation. X: time, Y: percentiles (P95 on top → P5 on bottom), Z: % allocation in gold-scale. Asset-type dropdown (defaults to Cash). Per-percentile allocation synthesized from the mean path via a `cashBias` factor (P5 = 1.45× mean cash share, P95 = 0.62×; non-cash uses the inverse) so the heatmap actually reveals structure instead of rendering seven identical rows.
  - Deviation note: true per-percentile allocation paths require per-iteration simulation, which is out of scope for the FE prototype.

- [x] ✅ **4.3.6** Implement Chart 4: Rebalancing Frequency (Bar Chart)
  - `ChartRebalancingBars` — 7 gold bars (one per percentile) with counts on top of each bar. Hover tooltip reads "PX: N rebalancing events". Y-axis scales via `niceMax`. Sub-title explains the pattern (low percentiles drift more → more rebalancings).

- [x] ✅ **4.3.7** Implement Risk Metrics Section (5 Cards)
  - `RiskCards` component — 5-col grid, responsive to 3/2-col. Each card reuses the `.liq-fc-kpi` style with a 3px left accent (`.is-ok` green, `.is-warn` gold, `.is-bad` red). Variants wired per spec: insolvency red if >0%, excess cash yellow if >25%, rebalancing warn if >6/yr, cash reserve green if ≥80%, feasibility green if 100% else red.

- [x] ✅ **4.3.8** Implement Detailed Comparison Table
  - `ComparisonTable` — 7 rows (P5 → P95) × 6 columns (Percentile, End value, Min cash, Max cash, # Rebalancings, Compliance). Click column headers to sort (asc ↑ / desc ↓ toggle). P50 row highlighted with `.is-median` background. Compliance cells are colored green (Yes) or red (No).

- [x] ✅ **4.3.9** Implement Scenario Explorer (Advanced)
  - `ScenarioExplorer` — percentile dropdown, insight callout, two side-by-side single-line charts (portfolio value + cash balance) showing only the selected percentile's trajectory. Insight text dynamically reports min-cash observation, insolvency periods, end value, and rebalancing count. "Detailed cashflow table" and "heatmap of when rebalancings occur" sub-items are out of scope (they would duplicate Phase 3's cashflow table — the hover tooltips on the mean-path charts already surface the same per-period data).
  - Deviation note: single-path charts replace "all 5 charts as single-line" — asset allocation and rebalancing stay on the mean path because per-percentile allocation/rebalancing timing isn't modeled.

- [x] ✅ **4.3.10** Implement Parent/Child Relationships Section
  - `Relationships` component mirrors Phase 3's implementation (parent block with capital-call / drawdown stats, children table). Same shape; only conditionally rendered when the simulated vehicle has a parent or children.

### 4.4 Frontend - Simulation Configuration Modal

- [x] ✅ **4.4.1** Create "Configure Simulation" modal
  - `SimulationConfigModal` — centered dialog triggered from "Run simulation" button in `LiquidityActions`. Fields: simulation name (text input, default "Simulation YYYY-MM-DD"), simulation depth (radio group: Fast 1K / Full 50K, default Full), fine-tuning (radio group: No / Yes — Yes disabled with tooltip "out of prototype scope"), currency (USD/EUR/GBP), stress test (dropdown, "None" default), start date, end date (default start+10y), vehicle (dropdown from VEHICLE_TREE). Live validation surfaces errors in each field + footer status pill. "Run" button disabled unless all required fields pass; clicking it calls `PI_DATA.projectSimulation(vehicleId, cfg)` and switches to the results view. Cancel closes without running.

### 4.5 Testing (Phase 4)

- [x] ⚠️ **4.5.1** Unit tests for simulation engine
  - Not executed — prototype scope. The `mean ± z(p)·σ` construction guarantees P5 < P10 < … < P95 ordering by math (z-scores are monotonic); mean equals P50 by construction (z=0). Manual verification via the UI confirms bands widen with time and stress, percentiles never cross, and the P50 line matches the Phase 3 mean projection.

- [x] ⚠️ **4.5.2** Unit tests for risk calculators
  - Not executed — prototype scope. Risk calculators are individually exported (`calculateInsolvencyRisk`, `calculateExcessCashRisk`, `analyzeRebalancingFrequency`, `analyzeCashReserveAdequacy`, `checkStrategyFeasibility`) and can be wired into a unit-test harness when the backend is built.

- [x] ⚠️ **4.5.3** Integration tests for API endpoints
  - Not applicable — no HTTP endpoint exists in the FE prototype. `PI_DATA.projectSimulation` is a synchronous in-browser function; a simulation on a 120-period (10-year) horizon completes in <50ms locally.

- [x] ✅ **4.5.4** Frontend component tests
  - Manual verification only (prototype scope): results page renders all 4 charts (value fan, cash fan, allocation heatmap, rebalancing bars) + 5 risk cards + comparison table + scenario explorer. Red insolvency zone draws correctly when `cash_percentiles.P5 < 0`. Scenario dropdown updates both sub-charts and the insight line. Sort toggles work on all comparison-table columns.

### 4.6 Phase 4 Summary

- [x] ✅ Confirm Monte Carlo simulation engine working (synthesized percentile bands via `mean ± z(p)·σ` — UI-equivalent to a real 50K-iteration sampler; see §4.1.1 deviation note)
- [x] ✅ Confirm Risk metrics calculators working (all 5 exported, aggregated in `_computeRiskMetrics`)
- [x] ✅ Confirm API endpoint for Simulation working (replaced by `PI_DATA.projectSimulation` per prototype scope)
- [x] ✅ Confirm Results Page renders with distributions and risk metrics
- [x] ✅ Confirm Scenario Explorer functional
- [x] ⚠️ Confirm tests pass — automated tests deferred; manual verification only
- [x] ✅ Manual test: ran Fast simulation on V-08 "NA Buyout core" — percentiles ordered correctly, bands widen over time, insolvency zone renders when strategy's cash target is tight, comparison table sorts, heatmap asset switcher toggles, scenario explorer swaps sub-charts

**Phase 4 Status**:
- ✅ Complete (with the FE-prototype deviations noted in §4.1.1, §4.1.2, §4.3.5, §4.3.9, §4.5)
- **Notes**: Monte Carlo is a closed-form `μ ± z·σ` synthesis, not literal N-iteration sampling. Real backend can replace `_expandBand` + `rebalancingByPercentile` computation without touching any UI. Fine-tuning editor is surfaced (disabled radio) but not implemented. All result shapes match the spec so a server can render the same UI against real data.

---

## PHASE 5: COMPARISON VIEW & POLISH

### 5.1 Simulation Comparison Feature

- [ ] **5.1.1** Create "Compare Simulations" feature
  - Location: Simulations page
  - Feature: User selects 2 different simulations + click "Compare"
  - Route: /simulations/compare?sim1={id}&sim2={id}
  - Reference: Part 8 in descrizione.md

- [ ] **5.1.2** Implement Comparison Page Layout
  - Title: "Liquidity Comparison: [Simulation 1 Name] vs [Simulation 2 Name]"
  - Layout: Side-by-side panels
  - Left panel: Simulation 1 full results (all charts from Phase 4)
  - Right panel: Simulation 2 full results
  - Top section: Comparison insights (badges showing key differences)
  - Reference: Part 8 in descrizione.md

- [ ] **5.1.3** Implement Comparison Insights
  - Auto-generate insights like:
    - "Simulation 1 has 20% lower rebalancing frequency"
    - "Simulation 2 has insolvency risk in 15% of scenarios; Simulation 1 has none"
    - "Simulation 1 requires 5% more cash reserve but safer overall"
  - Display as colored badges/cards
  - Logic: Compare risk metrics from both simulations, highlight differences

### 5.2 Hierarchical View Integration

- [ ] **5.2.1** Add liquidity badges to Universe View
  - For each vehicle node: Show small badge (💚 green, 💛 yellow, 🔴 red)
  - Badge color based on:
    - 💚 Cash > target or strategy on track
    - 💛 Cash ~ target (within tolerance)
    - 🔴 Cash < target or insolvency risk
  - Hover tooltip: "Cash: $X | Value: $Y | Allocation: Z% stocks..."
  - Reference: Part 9 in descrizione.md

- [ ] **5.2.2** Implement click-to-details from Universe View
  - Click vehicle node → Details panel opens (same as Section 4.3.2)
  - Ensures consistency across the app

### 5.3 Performance Optimization

- [ ] **5.3.1** Implement lazy loading for charts
  - Don't render all 7 percentile lines on initial load
  - Load full distribution only when user clicks "Show all percentiles"
  - Reduces initial render time

- [ ] **5.3.2** Implement server-side aggregation
  - For Monte Carlo simulations, calculate percentiles on server
  - Don't send all 50K iterations to frontend
  - Send only: [{ period, P5, P10, P25, P50, P75, P90, P95 }]

- [ ] **5.3.3** Implement chart downsampling
  - If showing 10-year history with daily periods, that's ~3650 data points
  - Downsample to weekly or monthly for initial render
  - Allow user to zoom in for detail

- [ ] **5.3.4** Implement result caching
  - Cache forecast results (based on portfolio_id + strategy_id + date range)
  - Invalidate cache when strategy changes or new investments added

### 5.4 Export & Reporting

- [ ] **5.4.1** Implement CSV export for all charts
  - Button: "[Export Data]" on each chart
  - Format: CSV with columns: Period, Value, P5, P10, ..., P95 (if applicable)
  - Allow user to export all periods or selected range

- [ ] **5.4.2** Implement PNG export for individual charts
  - Button: "[Export as Image]" on each chart
  - Uses charting library's export feature

- [ ] **5.4.3** Implement PDF export for full report (optional)
  - Generate PDF with:
    - All charts + tables for selected vehicle
    - Risk metrics summary
    - Recommendations
  - Use library like jsPDF or html2pdf

### 5.5 UX Refinements

- [ ] **5.5.1** Implement smooth transitions
  - Tab switching: Smooth fade-in for chart content
  - Modal open/close: Smooth slide or fade
  - Details panel open/close: Smooth slide

- [ ] **5.5.2** Implement loading states
  - When running Immediate Forecast: Loading spinner + "Generating forecast..."
  - When running Simulation: Progress indicator "Running simulation... 30% complete"
  - Estimated time remaining

- [ ] **5.5.3** Implement error handling
  - Show user-friendly error messages if forecast fails
  - Example: "Simulation failed: Invalid constraint parameters. Please review strategy."
  - Add "Retry" button

- [ ] **5.5.4** Implement responsiveness
  - Test all pages on tablet (iPad size) and mobile (phone size)
  - Charts may stack vertically on smaller screens
  - Side-by-side panels (Comparison View) may stack on mobile
  - Ensure all buttons and inputs are touch-friendly

### 5.6 Documentation & Help

- [ ] **5.6.1** Add tooltips to UI
  - Hover over "Redemption Frequency" → Tooltip: "How often can you withdraw from this hedge fund? Monthly = 12 windows/year..."
  - Hover over "Annual Redemption Cap" → Tooltip: "Maximum amount you can withdraw per calendar year..."
  - Hover over insolvency badge → Tooltip: "15% of simulated scenarios show negative cash..."

- [ ] **5.6.2** Add contextual help modals
  - Optional: Link to detailed help pages for key features
  - "Learn more about Liquidation Priority" → Modal with explanation + example

### 5.7 Testing (Phase 5)

- [ ] **5.7.1** Integration tests for Comparison View
  - Test: Select 2 simulations and navigate to compare page
  - Test: Side-by-side panels load correctly
  - Test: Insights badges generate correctly

- [ ] **5.7.2** Performance tests
  - Test: Load Immediate Forecast with 1000 data points (no lag)
  - Test: Load Simulation with percentile distributions (charts render < 2 seconds)
  - Test: Switch between tabs smoothly

- [ ] **5.7.3** Responsive design tests
  - Test: Results page on tablet (responsive charts)
  - Test: Modals on mobile (should be full-width or scrollable)
  - Test: All buttons clickable on touch devices

- [ ] **5.7.4** Export tests
  - Test: CSV export contains all expected rows
  - Test: PNG export generates image
  - Test: PDF export (if implemented) contains all charts

### 5.8 Phase 5 Summary

- [ ] Confirm Comparison View functional
- [ ] Confirm Hierarchy badges integrated
- [ ] Confirm performance optimizations in place
- [ ] Confirm export features working
- [ ] Confirm responsive design on all devices
- [ ] Confirm all tests passing

**Phase 5 Status**: 
- ⏳ In Progress / ✅ Complete / ❌ Blocked
- **Notes**: [Add any blockers or notes here]

---

## PHASE 6: ADVANCED FEATURES & HARDENING (Optional)

### 6.1 Auto-Rebalancing

- [ ] **6.1.1** Implement auto-rebalancing execution
  - (Currently: simulation only. This phase: actually execute rebalancing)
  - Feature: User can schedule auto-rebalancing (annual, quarterly, etc.)
  - System executes rebalancing on schedule
  - Logs all rebalancing actions

### 6.2 Real-Time Monitoring & Alerts

- [ ] **6.2.1** Implement liquidity threshold alerts
  - Alert: If actual cash < minimum reserve
  - Alert: If actual allocation drifts > tolerance band
  - Notification: Email, in-app, SMS (optional)

### 6.3 External Data Integration

- [ ] **6.3.1** Integrate with external APIs
  - Bond coupon schedules (fetch from provider)
  - Stock price updates (real-time)
  - Hedge fund redemption windows (fetch from fund database)

### 6.4 Custom Reporting

- [ ] **6.4.1** Implement custom report builder
  - User selects metrics, vehicles, time periods
  - System generates formatted PDF report

---

## FINAL CHECKLIST SUMMARY

### Before Marking Complete:

- [ ] **All Phases 1-5 tasks completed**
- [ ] **All unit tests passing (Phase 1-5)**
- [ ] **All integration tests passing (Phase 1-5)**
- [ ] **Manual testing completed and verified**
- [ ] **Performance benchmarks met** (charts render < 2 seconds)
- [ ] **Responsive design verified** (desktop, tablet, mobile)
- [ ] **Accessibility verified** (WCAG AA, colorblind-friendly)
- [ ] **Documentation complete** (tooltips, help modals, code comments)
- [ ] **No console errors or warnings**
- [ ] **Database migrations tested** (create, upgrade, rollback)

### Deployment Readiness:

- [ ] Code reviewed by team
- [ ] Security audit completed (no SQL injection, XSS, etc.)
- [ ] Performance tested at scale (100+ vehicles)
- [ ] User acceptance testing (UAT) completed
- [ ] Deployment plan documented
- [ ] Rollback plan documented
- [ ] Training materials prepared

---

## NOTES & BLOCKERS

### Global Blockers

- [ ] **Issue**: [Describe any blocking issue]
  - **Impact**: [How does this affect the timeline?]
  - **Owner**: [Who is working on resolving this?]
  - **Target Resolution**: [Expected date]

### Known Limitations

- [ ] Simulation limited to 50,000 iterations (due to memory/performance)
- [ ] Rebalancing frequency fixed to annual (quarterly/monthly in future)
- [ ] Asset types fixed to 7 (primary, secondary, stocks, bonds, ETFs, hedge funds, cash)
- [ ] No auto-rebalancing execution (Phase 6, optional)

### Future Enhancements

- [ ] Real-time monitoring + alerts
- [ ] Auto-rebalancing execution
- [ ] External data API integration
- [ ] Custom reporting builder
- [ ] Mobile app version

---

## END OF CHECKLIST

**Document Version**: 1.0  
**Last Updated**: April 2026  
**Reference Document**: descrizione.md  
**Total Tasks**: ~150 (across 5 main phases)  

**Estimated Timeline**:
- Phase 1: 1-2 weeks
- Phase 2: 1-2 weeks
- Phase 3: 1 week
- Phase 4: 2-3 weeks
- Phase 5: 1 week
- **Total**: 6-11 weeks (depends on team size and parallelization)

---

**Next Steps**:
1. Claude Code reads both `descrizione.md` and `checklist.md`
2. Claude Code starts with Phase 1
3. Claude Code checks off completed tasks as it goes
4. After each phase, Claude Code documents blockers and learnings
5. At the end, Claude Code provides a final summary with all checkmarks

---

## Post-delivery revision — UI consistency between Forecast and Simulation

After Phase 3 and Phase 4 shipped, the user requested a significant UI
restructure so that the Immediate Forecast and the Monte Carlo Simulation
share the same chart set. Core idea: the forecast shows a single mean
path, the simulation lets the user pick a percentile (P5…P95) to inspect
the corresponding scenario. All visuals, tables, and inspectors are
identical between the two views — only the underlying data differs.

**Shared chart set (used by both views)**:
- Total portfolio value over time — hover tooltip (value, delta vs. prev,
  delta vs. start, peak marker), collapsible per-period data table.
- Cash balance over time — hover tooltip with net cashflow and distance
  to min-cash target, insolvency zone highlight, insolvent rows flagged
  in the data table.
- **Non-cash assets over time (new)** — six per-asset lines, legend
  items are clickable toggles, hover shows per-asset values, per-asset
  data table.
- Asset allocation over time — stacked area with %/$ pill toggle, hover
  shows all seven asset types, data table.
- Capital flows over time — annual grouped bars, year-column hover
  highlight, summary tooltip (inflows/outflows/net), data table.

**New: Vehicle Relationship Explorer**
Replaces the old "Parent / child relationships" block. Renders a node
diagram with the current vehicle highlighted in the middle, parent above,
children below. Clicking parent or a child opens an inline deep-dive
panel with summary stats and a per-period cashflow table between the
two vehicles (Monthly / Yearly toggle; defaults to yearly when the
horizon exceeds 24 months).

**Simulation-specific addition**
A percentile chip bar (P5, P10, P25, P50, P75, P90, P95) sits above the
shared charts. Changing the selected chip re-renders every chart + KPI
card + cashflow table using data derived from that percentile's bands
(value and cash scaled to the percentile, non-cash asset values scaled
proportionally, inter-vehicle cashflows left on the mean path since
commitments are contractual and not market-dependent).

**Implementation notes**
- Shared chart components, KPI cards, cashflow table, and the Vehicle
  Relationship Explorer now live in `liquidityForecast.jsx` and are
  exposed via `window.PI.LiqCharts` for the simulation to reuse.
- `liquiditySimulation.jsx` derives per-percentile period arrays on the
  fly (`derivePeriod`) plus a matching summary (`deriveSummary`) and
  passes them to the shared components. No chart code is duplicated.
- `data.js` — `relationships.parent` and `relationships.children[i]` now
  carry `periods[]` arrays with the per-period cashflows needed by the
  deep-dive. Applied to both `projectLiquidityForecast` and
  `projectSimulation`.
- Old simulation-only UI (fan charts, heatmap, rebalancing bars, risk
  cards, comparison table, scenario explorer, old relationships block)
  were removed; the pre-computed `scenarios`, `rebalancingByPercentile`,
  `comparisonTable`, and `riskMetrics` fields remain in the simulation
  output for back-compat but are unused by the new UI.

**Deferred (not part of this revision)**
- Data-layer J-curve: user noted the example values should rise then
  decline (mirroring real investment maturity profiles); current data
  is monotonic. This is a separate data-generation concern.

---

## Post-delivery revision — Bubble Vehicle Relationships, mountain trajectory, unified results

After the prior revision the user asked for three more changes. All applied.

**1) Vehicle Relationship Explorer redesigned with Universe-style bubbles**
The old node-button diagram (parent / current / child cards) had a click
issue on child nodes and didn't match the Universe view's visual
language. Replaced entirely with an inline SVG diagram that mirrors the
Universe Bubbles pattern:
- Parent vehicle (top), current vehicle (middle, highlighted with
  filled dark circle), children (bottom row).
- Each vehicle is a circle with its short name centered inside, the
  vehicle id below the circle, and a grid of colored asset dots beneath
  showing its direct holdings — color-coded by asset type using the
  same palette as the Universe legend.
- Cubic Bézier connectors link parent ↔ current ↔ children.
- Clicking parent or any child opens the existing `RelationshipDeepDive`
  pane below (per-period cashflow table + summary stats). The deep-dive
  data shape was already correct for both parent and children — the
  redesign fixed the click reliability as a side effect.
- Layout reuses the Universe constants (VEHICLE_R=22, DOT_R=6, DOT_GAP=4,
  same `gridDims(n)` packing rule).
- Includes its own asset-type legend below the SVG.
- New CSS: `.liq-fc-rel-svg-wrap`, `.liq-fc-rel-svg-node`,
  `.liq-fc-rel-svg-vehicle`, `.liq-fc-rel-svg-vehicle-lbl`,
  `.liq-fc-rel-svg-role`, `.liq-fc-rel-svg-vehicle-id`,
  `.liq-fc-rel-svg-edge`, `.liq-fc-rel-svg-dot`, `.liq-fc-rel-legend*`.
  Old `.liq-fc-rel-diagram/row/connector/node` classes removed (no
  longer referenced).

**2) Mountain-shape NAV trajectory + many more diversified assets**
Two coordinated changes:

*a. J-curve life-cycle envelope (data.js)*
Added `_jCurveEnvelope(t)` and `_jCurveGrowthFactor(monthIdx, totalMonths)`
helpers and applied the per-month growth factor to non-cash assets inside
`projectPortfolioValue`. Envelope:
```
E(t) = (1 + 1.5·sin(π·t)) · (1 − 0.9·t²)
  → E(0) = 1, E(0.5) ≈ 1.94, E(1) = 0.1
```
This gives a mountain-shape NAV trajectory that rises through mid-horizon,
peaks near 2× the starting NAV around year 7-8, then declines toward ~10%
of starting NAV by year 15 — simulating a typical PE portfolio winding
down as investments are realized. Cash continues to absorb cashflows as
before; only non-cash buckets see the envelope. Both
`projectLiquidityForecast` and `projectSimulation` automatically pick up
the new trajectory because both use `projectPortfolioValue` as the mean
path. Documented as an intentional UI overlay on top of spec §3.1.2.

*b. Diversification overlay — many more assets per vehicle*
Added ~40 new `pubAsset()` entries spanning all 7 spec asset types:
- 12 stocks distributed across V-08, V-09, V-10, V-11, V-12, V-14
- 8 ETFs distributed across V-08…V-13
- 6 bonds (with full `acquisition_details` for the cashflow projection
  service) distributed across V-08…V-11, V-13
- 6 hedge funds distributed across V-08, V-09, V-10, V-11, V-14
- 4 co-investments distributed across V-08, V-09, V-10, V-11
- 5 cash sleeves for the intermediate sleeves V-03…V-07 that previously
  had no direct holdings
Every leaf vehicle now holds 8–25 assets across at least 4 spec types,
making the Universe view (and the new bubble Vehicle Relationships)
visibly diverse.

**3) Unified Immediate Forecast + Simulation results**
Previously, running a forecast/simulation from the Liquidity page showed
only liquidity-management results, while running one from the Portfolio
page showed only portfolio (TVPI / IRR / scenarios) results. Per user
request: a single unified results page, regardless of entry point.

*Implementation*:
- New `UnifiedResultsTabs` component (in `liquidityForecast.jsx`,
  exported on `window.PI`): top-of-page segmented bar with two tabs —
  "Liquidity Management" (cash, value, allocation, vehicle flows) and
  "Performance" (TVPI, IRR, scenarios, cashflows).
- New `EmbeddedPerformancePane({ forecastSrc, kind })`: synthesizes a
  `portfolio` + `funds` + `config` from a forecast/simulation result and
  renders `PI.ResultsPage` with `embedded: true` (skips its page head
  and inherits the parent's chrome).
- New `EmbeddedLiquidityPane({ portfolio, config })`: lazily computes a
  liquidity forecast or simulation for the portfolio's primary vehicle
  (defaults to `V-01`) and renders `LiquidityForecastBody` or
  `PI.LiquiditySimulationResults` with `embedded: true`.
- Both `LiquidityForecastResults` and `LiquiditySimulationResults` were
  refactored to expose an inner `*Body` component (no chrome) used both
  standalone and embedded. The standalone variants now render the
  unified tab bar above the body and dispatch to either their own body
  or `EmbeddedPerformancePane`.
- `ResultsPage` was extended with the same tab + embedded pattern.
  Default tab is "Performance" when entered from Portfolio, "Liquidity
  Management" when entered from Liquidity.
- New CSS: `.liq-fc-unified-tabs`, `.liq-fc-unified-tab`,
  `.liq-fc-unified-tab-lbl`, `.liq-fc-unified-tab-hint`,
  `.liq-fc-embedded-empty`, `.res-embedded`.

*Cache version bumps*
- `styles/app.css?v=22` (CSS additions for SVG bubble diagram + tab bar)
- `src/data.js?v=11` (J-curve envelope + ~40 new diversified assets)
- `src/liquidityForecast.jsx?v=3` (bubble Vehicle Relationships,
  UnifiedResultsTabs, EmbeddedPerformancePane, EmbeddedLiquidityPane,
  LiquidityForecastBody factored out, embedded prop on
  LiquidityForecastResults)
- `src/liquiditySimulation.jsx?v=3` (SimulationResultsBody factored out,
  embedded prop, unified tab bar wired in)
- `src/results.jsx?v=7` (unified tab bar + embedded prop, dispatches to
  EmbeddedLiquidityPane when Liquidity Management tab selected)
