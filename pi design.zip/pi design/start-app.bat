@echo off
cd /d "%~dp0"
echo Avviando Predictive Intelligence...
start http://localhost:8080
python -m http.server 8080 --directory project
pause
