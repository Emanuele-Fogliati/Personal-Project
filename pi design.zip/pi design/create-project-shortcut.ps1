$ProjectPath = 'C:\Users\emanu\Downloads\pi design'
$ShortcutPath = Join-Path $ProjectPath 'Predictive Intelligence.lnk'
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = 'C:\Users\emanu\Downloads\pi design\start-app.bat'
$Shortcut.WorkingDirectory = 'C:\Users\emanu\Downloads\pi design'
$Shortcut.Save()
Write-Host "Shortcut creato nella cartella del progetto"
